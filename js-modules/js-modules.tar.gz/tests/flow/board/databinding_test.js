import {FlowBoard} from 'flow-board';
import {DataBindingPlugin} from 'flow-board-data-binding';

var databinding = new DataBindingPlugin();
databinding.setDefaultAreaName("areaA");

var flowBoard = new FlowBoard('#flowBoardTest', { multiselect: true });


const backlog = { id: "BACKLOG", name: "Backlog", group: "backlog", areas: [ 
        { name: "areaA", classNames: [ "prioA" ] },
        { name: "areaB", classNames: [ "prioB" ] },
        { name: "areaC", classNames: [ "prioC" ] },
    ],
    onEnter: function(task, column, areaName) {
        console.log("Entering column", column.id, "/", areaName, ":", task);
    },
    onLeave: function(task, column, areaName) {
        console.log("Leaving column", column.id, "/", areaName, ":", task);
    }    
}

flowBoard.addColumn(backlog);

flowBoard.addColumn({ id: "SPRINT_1", name: "Sprint 1", group: "sprint", areas: [ 
    { name: "areaA", classNames: [ "fastlane" ], header: "Fastlane" },
    { name: "areaB", classNames: [], header: "S1 TODO" },
    { name: "areaC", classNames: [] }
] })

flowBoard.addColumn({ id: "SPRINT_2", name: "Sprint 2", group: "sprint", areas: [ 
    { name: "areaA", classNames: [ "fastlane" ] },
    { name: "areaB", classNames: [] },
    { name: "areaC", classNames: [] }
] })

flowBoard.addColumn({ id: "SPRINT_3", name: "Sprint 3", group: "sprint", areas: [ 
    { name: "areaA", classNames: [ "fastlane" ] },
    { name: "areaB", classNames: [] },
    { name: "areaC", classNames: [] }
] })

databinding.configure({ id: "BACKLOG", condition: { labels: "BACKLOG" }, autobinding: true });
databinding.configure({ id: "SPRINT_1", condition: { labels: "SPRINT_1" }, autobinding: true });
databinding.configure({ id: "SPRINT_2", condition: { labels: "SPRINT_2" }, autobinding: true });
databinding.configure({ id: "SPRINT_3", condition: { labels: "SPRINT_3" }, autobinding: true });
 
flowBoard.addPlugin(databinding);

flowBoard.addSynchronizedArea(".sprint .fastlane")
flowBoard.addSynchronizedArea(".sprint .areaB")

let tasks = [
    { header: "TEST-0001", text: "Ich bin ein Task", classNames: [], labels: [ "BACKLOG" ] },
    { header: "TEST-0002", text: "Ich bin ein Task", classNames: [], labels: [ "BACKLOG" ] },
    { header: "TEST-0003", text: "Ich bin ein Task", classNames: [], labels: [ "BACKLOG" ] },
    { header: "TEST-0004", text: "Ich bin ein Task", classNames: [], labels: [ "BACKLOG" ] },
    { header: "TEST-0005", text: "Ich bin ein Task", classNames: [], labels: [ "SPRINT_1" ] },
    { header: "TEST-0006", text: "Ich bin ein Task", classNames: [], labels: [ "SPRINT_1" ] },
    { header: "TEST-0007", text: "Ich bin ein Task", classNames: [], labels: [ "SPRINT_1" ] },
    { header: "TEST-0008", text: "Ich bin ein Task", classNames: [], labels: [ "SPRINT_3" ] },
    { header: "TEST-0009", text: "Ich bin ein Task", classNames: [], labels: [ "SPRINT_3" ] }
];
const ids = Array.from({ length: 91 }, (value, index) => (index + 10).toString().padStart(3, '0'));
ids.forEach(id => {
    tasks.push({ header: "TEST-0" + id, text: "Ich bin ein Task", classNames: [], labels: [ "BACKLOG" ] });
})

databinding.bind(tasks);

// flowBoard.setCompleteDragAndDropPreview(true);

flowBoard.onTaskMoved(function(data) {
    console.log("dropped", data);
})

flowBoard.onRender(function(board) {
    console.log("onRender", board );
    board.columns.forEach(column => {
        let tasks = board.findTasks(taskColumn => taskColumn.id == column.id);
        const columnElement = board.getColumnElement(column.id);
        columnElement.querySelector('.header .subtitle').textContent = tasks.length
    })
})

flowBoard.render()

console.log("sprintTasks", flowBoard.findTasks(column => column.group == "sprint"))
console.log("backlogTasks", flowBoard.findTasks(column => column.group == "backlog"))

/*
window.setTimeout(function() {
    let task8 = flowBoard.findTasks().find(task => task.id == "TEST-0008");
    console.log("task8", task8);
    task8.header = "TEST-0008"
    
    flowBoard.refreshTasks([ task8 ]);
}, 2000);
*/