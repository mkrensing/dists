import {FlowBoard} from 'flow-board';

function enterColumn() {
    return {
        action: function(task, column, areaName) {
            return function(task) {
                return new Promise((resolve, reject) => {
                    window.setTimeout(() => {
                        console.log("enterColumn done");
                        resolve(task)
                    }, 1500);
                })
            }
        },
        description: function(task, column, areaName) {
            return `[${task.content.header}] Enter column ${column.name}`
        }
    }
}

function leaveColumn() {
    return {
        action: function(task, column, areaName) {
            return function(task) {
                return new Promise((resolve, reject) => {
                    window.setTimeout(() => { 
                        console.log("leaveColumn done");
                        resolve(task)
                    }, 500);
                })
            }
        },
        description: function(task, column, areaName) {
            return `[${task.content.header}] Leaving column ${column.name}`
        }
    }
}

function enterArea() {
    return {
        action: function(task, column, areaName) {
            return function(task) {
                return new Promise((resolve, reject) => {
                    window.setTimeout(() => {
                        console.log("enterArea done");
                        resolve(task)
                    }, 1500);
                })
            }
        },
        description: function(task, column, areaName) {
            return `[${task.content.header}] Enter Area ${areaName}`
        }
    }
}

function leaveArea() {
    return {
        action: function(task, column, areaName) {
            return function(task) {
                return new Promise((resolve, reject) => {
                    window.setTimeout(() => { 
                        console.log("leaveArea done");
                        resolve(task)
                    }, 500);
                })
            }
        },
        description: function(task, column, areaName) {
            return `[${task.content.header}] Leaving Area ${areaName}`
        }
    }
}


function raiseError(errorText) {
    return {
        action: function(task, column, areaName) {
            return function(task) {
                return new Promise((resolve, reject) => {
                    window.setTimeout(() => { 
                        reject(errorText)
                    }, 500);
                })
            }
        },
        description: function(task, column, areaName) {
            return `[${task.content.header}] will fail ${column.name}`
        }
    }
}

var flowBoard = new FlowBoard('#flowBoardTest', { notifications: true });

flowBoard.addColumn({ id: "BACKLOG", name: "Backlog", group: "backlog", areas: [ 
    { name: "areaA", classNames: [ "prioA" ] },
    { name: "areaB", classNames: [ "prioB" ] },
    { name: "areaC", classNames: [ "prioC" ] },
] })

flowBoard.addColumn({ id: "SPRINT_1", name: "Sprint 1", group: "sprint", areas: [ 
    { name: "areaA", classNames: [ "fastlane" ], header: "Fastlane" },
    { name: "areaB", classNames: [], header: "S1 TODO" },
    { name: "areaC", classNames: [] }
] })

flowBoard.addColumn({ id: "SPRINT_2", name: "Sprint 2", group: "sprint", areas: [ 
    { name: "areaA", classNames: [ "fastlane" ] },
    { name: "areaB", classNames: [] },
    { name: "areaC", classNames: [] }
] })

flowBoard.addColumn({ id: "SPRINT_3", name: "Sprint 3", group: "sprint", areas: [ 
    { name: "areaA", classNames: [ "fastlane" ] },
    { name: "areaB", classNames: [] },
    { name: "areaC", classNames: [] },
],
    onEnterColumn: raiseError("Entering Sprint 3 is not allowed!")
 })



flowBoard.onEnterColumn(enterColumn());
flowBoard.onLeaveColumn(leaveColumn())
flowBoard.onEnterArea(enterArea());
flowBoard.onLeaveArea(leaveArea())

flowBoard.addSynchronizedArea(".sprint .fastlane")
flowBoard.addSynchronizedArea(".sprint .areaB")

flowBoard.addTask({ columnId: "BACKLOG", areaName: "areaA" } , { header: "TEST-0001", text: "Ich bin ein Task", classNames: [] })
flowBoard.addTask({ columnId: "BACKLOG", areaName: "areaA" } , { header: "TEST-0002", text: "Ich bin ein Task", classNames: [] })
flowBoard.addTask({ columnId: "BACKLOG", areaName: "areaA" } , { header: "TEST-0003", text: "Ich bin ein Task", classNames: [] })
flowBoard.addTask({ columnId: "BACKLOG", areaName: "areaA" } , { header: "TEST-0004", text: "Ich bin ein Task", classNames: [] })

flowBoard.addTask({ columnId: "SPRINT_1", areaName: "areaB" } , { header: "TEST-0005", text: "Ich bin ein Task", classNames: [] })
flowBoard.addTask({ columnId: "SPRINT_2", areaName: "areaB" }, { header: "TEST-0006", text: "Ich bin ein Task", classNames: [] })
flowBoard.addTask({ columnId: "SPRINT_3", areaName: "areaB" }, { header: "TEST-0007", text: "Ich bin ein Task", classNames: [] })
flowBoard.addTask({ columnId: "SPRINT_3", areaName: "areaB" }, { header: "", text: "Ich bin ein Task", classNames: [] })
flowBoard.addTask({ columnId: "SPRINT_3", areaName: "areaB" }, { header: "TEST-0009", text: "Ich bin ein Task", classNames: [] })


const ids = Array.from({ length: 91 }, (value, index) => (index + 10).toString().padStart(3, '0'));
ids.forEach(id => {
    flowBoard.addTask({ columnId: "BACKLOG", areaName: "areaA" } , { header: "TEST-0" + id, text: "Ich bin ein Task", classNames: [] })
})

flowBoard.onTaskMoved(function(data) {
    console.log("dropped", data);
})

flowBoard.onRender(function(board) {
    console.log("onRender", board );
    board.columns.forEach(column => {
        let tasks = board.findTasks(taskColumn => taskColumn.id == column.id);
        const columnElement = board.getColumnElement(column.id);
        columnElement.querySelector('.header .subtitle').textContent = tasks.length
    })
})

flowBoard.render()

console.log("sprintTasks", flowBoard.findTasks(column => column.group == "sprint"))
console.log("backlogTasks", flowBoard.findTasks(column => column.group == "backlog"))

