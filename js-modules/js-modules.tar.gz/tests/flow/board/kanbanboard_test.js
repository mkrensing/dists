import {KanbanBoard} from 'kanban-board';


function changeStatus(bindingContext) {
    return {
        transition: function(task, column, areaName) {
            const targetStatusName = bindingContext(column, areaName)?.condition?.status
            if(task.content.status != targetStatusName) {
                return function(task) {
                    return new Promise((resolve, reject) =>  {
                        window.setTimeout(() => {
                            task.content.status = targetStatusName;
                            resolve(task);
                        }, 500)
                    });
                };
            }
        },
        description: function(task, column, areaName) {
            const targetStatusName = bindingContext(column, areaName)?.condition?.status
            return "[" + task.content.header + "] Change status to " + targetStatusName;
        }
    }
}

function setUser(bindingContext) {
    return {
        transition: function(task, column, areaName) {
            const targetUsername = bindingContext(column, areaName)?.condition?.user?.value
            console.log("setUser to ", targetUsername);
            if(task.content.user != targetUsername) {
                return function(task) {
                    return new Promise((resolve, reject) =>  {
                        window.setTimeout(() => {
                            task.content.user = targetUsername;
                            resolve(task);
                        }, 500)
                    });
                };
            }
        },
        description: function(task, column, areaName) {
            return "[" + task.content.header + "] Assign to user " + column.tag?.binding?.condition?.user.description
        }
    }
}

function addLabels(bindingContext) {
    return {
        transition: function(task, column, areaName) {
            const labels =  (bindingContext(column, areaName)?.condition?.labels || []);
            console.log("addLabels", labels, column.tag.binding)
            const promiseCallbacks = labels.map(label => {
                return addLabel(label).transition(task, column, areaName)
            });
            return promiseCallbacks;
        },
        description: function(task, column, areaName) {
            const labels = (bindingContext(column, areaName)?.condition?.labels || []);
            const descriptions =  labels.map(label => {
                return addLabel(label).description(task, column, areaName)
            });
            return descriptions
        }   
    }
}

function addLabel(label) {
    return {
        transition: function(task, column, areaName) {
            task.content.labels = task.content.labels || []
            if(! task.content.labels.includes(label)) {
                return function(task) {
                    return new Promise((resolve, reject) =>  {
                        window.setTimeout(() => {
                            task.content.labels.push(label);
                            resolve(task);
                        }, 500)                        
                    });
                };
            }
        },
        description: function(task, column, areaName) {
            return "[" + task.content.header + "] Set label " + label;
        }
    }
}

function removeLabels(bindingContext) {
    return {
        transition: function(task, column, areaName) {
            const labels = (bindingContext(column, areaName)?.condition?.labels || []);
            const promiseCallbacks = labels.map(label => {
                return removeLabel(label).transition(task, column, areaName)
            });
            return promiseCallbacks;
        },
        description: function(task, column, areaName) {
            const labels = (bindingContext(column, areaName)?.condition?.labels || []);
            const descriptions =  labels.map(label => {
                return removeLabel(label).description(task, column, areaName)
            });
            return descriptions
        }   
    }
}

function removeLabel(label) {
    return {
        transition: function(task, column, areaName) {
            task.content.labels = task.content.labels || []
            if(task.content.labels.includes(label)) {
                return function(task) {
                    return new Promise((resolve, reject) =>  {
                        window.setTimeout(() => {
                            task.content.labels = task.content.labels.filter(existingLabel => existingLabel != label);
                            resolve(task);
                        }, 500)                           
                    });
                };
            }
        },
        description: function(task, column, areaName) {
            return "[" + task.content.header + "] Remove label " + label;
        }
    }
}

function isAssignedToUser(username) {
    return {
        condition: function(user, issue) {
            return user == username;
        },
        description: username,
        value: username
    }
}

function isNotAssigned() {
    return {
        condition:  function(user, issue) {
            return (user || "") == "";
        },
        description: "(not assigned)",
        value: ""
    }
}

function Berliner() {
    return {
        transition: {
            enter: { 
                transition: function(task, column, areaName) {
                    return function(task) {
                        return new Promise((resolve, reject) =>  {
                            window.setTimeout(() => {
                                console.log("set location to Berlin!!!")
                                task.location = "Berlin"
                                resolve(task);
                            }, 500)                        
                        });
                    }
                }, 
                description: function(task, column, areaName) {
                    return "[" + task.content.header + "] Set Location to Berlin"
                }
            },
        },
        condition: function(property, task) {
            return task?.location == "Berlin";
        },
        description: "Check for Berliner"
    }
}

var kanbanBoard = new KanbanBoard('#kanbanBoardTest', { dragDrop: { completeDragAndDropPreview: false }});

kanbanBoard.addColumn({ id: "BACKLOG", name: "Backlog", group: "backlog", areas: [ 
    { name: "default", classNames: [ "prioA" ] },
    { name: "areaB", classNames: [ "prioB" ] },
    { name: "areaC", classNames: [ "prioC" ] },
    ],
    onEnter: function(task, column, areaName) {
        console.log("Entering column", column.id, "/", areaName, ":", task);
    },
    onLeave: function(task, column, areaName) {
        console.log("Leaving column", column.id, "/", areaName, ":", task);
    }    
});

kanbanBoard.addColumn({ id: "SPRINT_1", name: "Sprint 1", group: "sprint", areas: [ 
    { name: "default", classNames: [ "fastlane" ], header: "Fastlane" },
    { name: "areaB", classNames: [], header: "S1 TODO" },
    { name: "areaC", classNames: [] }
], tag: { wipLimit: 5 } })

kanbanBoard.addColumn({ id: "SPRINT_2", name: "Sprint 2", group: "sprint", areas: [ 
    { name: "default", classNames: [ "fastlane" ] },
    { name: "areaB", classNames: [] },
    { name: "areaC", classNames: [] }
] })

kanbanBoard.addColumn({ id: "SPRINT_3", name: "Sprint 3", group: "sprint", areas: [ 
    { name: "default", classNames: [ "fastlane" ] },
    { name: "areaB", classNames: [] },
    { name: "areaC", classNames: [] }
] })

kanbanBoard.addColumnBinding({ id: "BACKLOG", condition: { labels: [ "BACKLOG" ], status: "To Do", user: isAssignedToUser("Foobar") }, autobinding: true });
kanbanBoard.addColumnBinding({ id: "SPRINT_1", condition: { labels: [ "SPRINT_1" ], status: "In Progress", user: isNotAssigned() }, autobinding: true });
kanbanBoard.addColumnBinding({ id: "SPRINT_2", condition: { labels: [ "SPRINT_2" ], status: "In Progress",}, autobinding: true });
kanbanBoard.addColumnBinding({ id: "SPRINT_3", condition: { labels: [ "SPRINT_3" ], status: "In Progress", "location": Berliner() }, autobinding: true });

kanbanBoard.addAreaBinding({ id: "areaB", condition: { labels: [ "AREA_B" ]} })

let autobindingMap = {
    labels: { enter: addLabels, leave: removeLabels },
    status: { enter: changeStatus },
    user: { enter: setUser }
}

kanbanBoard.autoBindingConditionsToTransitions(autobindingMap);

kanbanBoard.onTransitionErrors((error) => {
    console.error("onTransitionError", error);
});

kanbanBoard.addSynchronizedArea(".sprint .fastlane")
kanbanBoard.addSynchronizedArea(".sprint .areaB")

let tasks = [
    { header: "TEST-0001", text: "Ich bin ein Task", classNames: [], labels: [ "BACKLOG" ], status: "To Do", user: "Foobar" },
    { header: "TEST-0002", text: "Ich bin ein Task", classNames: [], labels: [ "BACKLOG", "AREA_B" ], status: "To Do", user: "Foobar"},
    { header: "TEST-0003", text: "Ich bin ein Task", classNames: [], labels: [ "BACKLOG" ], status: "To Do", user: "Foobar"},
    { header: "TEST-0004", text: "Ich bin ein Task", classNames: [], labels: [ "BACKLOG" ], status: "To Do", user: "Foobar" },
    { header: "TEST-0005", text: "Ich bin ein Task", classNames: [], labels: [ "SPRINT_1", "AREA_B" ], status: "In Progress", },
    { header: "TEST-0006", text: "Ich bin ein Task", classNames: [], labels: [ "SPRINT_1" ], status: "In Progress", },
    { header: "TEST-0007", text: "Ich bin ein Task", classNames: [], labels: [ "SPRINT_1" ], status: "In Progress", },
    { header: "TEST-0008", text: "Ich bin ein Task", classNames: [], labels: [ "SPRINT_2", "AREA_B" ], status: "In Progress", },
    { header: "TEST-0009", text: "Ich bin ein Berliner", classNames: [], labels: [ "SPRINT_3" ], status: "In Progress", location: "Berlin" }
];

const ids = Array.from({ length: 91 }, (value, index) => (index + 10).toString().padStart(3, '0'));
ids.forEach(id => {
    tasks.push({ header: "TEST-0" + id, text: "Ich bin ein Task", classNames: [], labels: [ "BACKLOG" ], status: "To Do", user: "Foobar" });
})

kanbanBoard.onTaskMoved(function(data) {
    console.log("task moved", data);
})

kanbanBoard.render(tasks)

console.log("sprintTasks", kanbanBoard.findTasks(column => column.group == "sprint"))
console.log("backlogTasks", kanbanBoard.findTasks(column => column.group == "backlog"))

const moveTaskButton = document.getElementById('moveTask');
moveTaskButton.addEventListener('click', () => {
    
    const task = kanbanBoard.findTasks().find(task => task.content.header == "TEST-0006");
    const referenceTask = kanbanBoard.findTasks().find(task => task.content.header == "TEST-0003");
    console.log("task", task);

    kanbanBoard.moveTask({ columnId: "BACKLOG", areaName: "default", nextTaskId: referenceTask.id }, task);
});