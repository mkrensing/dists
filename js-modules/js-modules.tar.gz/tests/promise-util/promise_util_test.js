import { sequenceChain } from 'promise-util'

const issue = {
    key: "TEST-1234",
    status: "To Do",
    labels: [],
    assignee: null
}

function changeStatus(targetStatus) {
    return function(issue) {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({ ...issue, status: targetStatus });
            }, 100);
        });
    }
}

function addLabel(label) {
    return function(issue) {
        assert(issue.status == "In Progress");
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({ ...issue, labels: issue.labels.concat([label]) });
            }, 100);
        });
    }
}

function setAssignee(assignee) {
    return function(issue) {
        assert(issue.labels.includes("TEST"));
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({ ...issue, assignee: assignee });
            }, 100);
        });
    }
}

let changes = [ changeStatus("In Progress"), addLabel("TEST"), setAssignee("Hans") ]

sequenceChain(changes, issue).then(completedIssue => {
    
    assert(completedIssue.status == "In Progress");
    assert(completedIssue.labels.includes("TEST"));
    assert(completedIssue.assignee == "Hans");
    console.log("sequence completed", completedIssue);
})

function assert(condition, message) {
    if (!condition) {
        throw new Error(message || "Assertion failed");
    }
}