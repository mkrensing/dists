const p1 = new Promise((resolve, reject) => {
    setTimeout(() => resolve("one"), 100);
  });
  const p2 = new Promise((resolve, reject) => {
    setTimeout(() => resolve("two"), 200);
  });
  const p3 = new Promise((resolve, reject) => {
    setTimeout(() => resolve("three"), 300);
  });
  const p4 = new Promise((resolve, reject) => {
    setTimeout(() => resolve("four"), 400);
  });
  const p5 = new Promise((resolve, reject) => {
    setTimeout(() => resolve("five"), 500);
  });
  


function parallel(promises) {

    return new Promise((resolve, reject) => {

        Promise.allSettled(promises).then((results) => {
            let rejected = results.filter(result => result.status === "rejected").map(result => result.reason);
            if(rejected.length > 0) {
                reject(rejected)
            } else {
                let fullfilled = results.map(result => result.value);
                resolve(fullfilled);
            }
        });
    });

}

  // Using .catch:
  parallel([p1, p2, p3, p4, p5])
    .then((values) => {
      console.log(values);
    })
    .catch((error) => {
      console.error("rejected", error);
    });
  