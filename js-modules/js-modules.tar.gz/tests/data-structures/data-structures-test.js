import {default as datastructures} from 'data-structures'

let values = [
    { id: 1, name: "Men -- Marker" },
    { id: 2, name: "Hans" },
    { id: 3, name: "Peter" },
    { id: 4, name: "Krik" },
    { id: 5, name: "Claus" },
    { id: 6, name: "Women -- Marker" },
    { id: 7, name: "Sandra" },
    { id: 8, name: "Childs -- Marker" }
]

let sliceIndexes = [
    { name: "Men", index: 0 },
    { name: "Women", index: 5 },
    { name: "Childs", index: 7 }    
]

let results = datastructures.sliceArray(values, sliceIndexes);
console.log(results)

results = datastructures.sliceArray(values, sliceIndexes, { removeSeparatorItem: true });
console.log(results)

results = datastructures.sliceArray(values, sliceIndexes, { removeSeparatorItem: false });
console.log(results)