import {default as jira} from 'jira';
import {default as rest} from 'rest'

const jiraToken = "info@krensing.com:::ATATT3xFfGF0AU5ka8z4GiF7EXR4aEcTzvygHPQUXVzp0kjrrV9l-ycGLRTsbNCxaYGHdWg1eBaqqDnhtUNMcZunPF_C0prNw7VIKzLnzTXnL8jamjL4Z_WZIHX3xO2j8Tj7u__UJugq0VeN1ose7CWz9n6DZgsM3Jt4v7M0AHOgqx1a-zrX8IU=509964F3"
const restClient = new rest.RestClient();

restClient.getJson("http://localhost:8888/rest/jira/login", { token: jiraToken }).then(result => {

    const updater = new jira.IssueUpdater("http://localhost:8888", { Authorization: result.auth_id });
    
    const issue = {
        key: "JT-3",
        projectId: "JT",
        status: "To Do",
        labels: []
    }
    
    /*
    updater.update(issue, { "status": "In Progress"}).then(result => {
        console.log("status changed", result);
    
    }).catch(error => {
        console.error("error during status change", error);
    })

    updater.update(issue, { labels: [{ add: "TEST_LABEL_1" }, { add: "TEST_LABEL_2" }]}).then(result => {
        console.log("labels", result);
    
        updater.update(issue, { labels: [{ remove: "TEST_LABEL_2" } ]}).then(result => {
            console.log("labels", result);
        
        }).catch(error => {
            console.error("error during set labels", error);
        })   

    }).catch(error => {
        console.error("error during set labels", error);
    })    


    updater.update(issue, { "assignee": "Testuser"}).then(result => {
        console.log("assignee changed", result);
    
    }).catch(error => {
        console.error("error during assignee change", error);
    })    
    */

    updater.update(issue, { "assignee": ""}).then(result => {
        console.log("assignee changed", result);
    
    }).catch(error => {
        console.error("error during assignee change", error);
    })      

}).catch(error => {
    console.log("error during auth", error);
})
