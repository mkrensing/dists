import {default as rest} from 'rest'

export class IssueUpdater {

    constructor(baseUrl, headers) {
        this.baseUrl = baseUrl || "";
        this.headers = headers || {};
        this.specialUpdateFunctions = {
            status: this.changeStatus,
            assignee: this.changeAssignee,
        }
        this.aliasToFieldname = {};
        this.fieldNameToAlias = {};
    }

    setFieldMapping(fieldMappings) {
        this.aliasToFieldname = {};
        this.fieldNameToAlias = {};
        fieldMappings.forEach(mapping => {
            const [alias, name] = mapping.split("|");
            if(name) {
                this.aliasToFieldname[alias] = name;
                this.fieldNameToAlias[name] = alias;
            }
        });
    }

    /*
    update(issue, changes) {
        var promises = [];

        for(let propertyName in changes) {
            if(this.specialUpdateFunctions[propertyName]) {
                promises.push(this.specialUpdateFunctions[propertyName].call(this, issue, changes[propertyName]));
                delete changes[propertyName];
            } 
        }

        if(Object.keys(changes).length > 0) {
            promises.push(this.changeFields(issue, changes))
        }

        return Promise.all(promises);
    }
*/

    changeStatus(issue, targetStatusName) {

        const _this=this;
        return new Promise((resolve, reject) => {
            const restClient = new rest.RestClient();
            restClient.getJson(_this.baseUrl + "/rest/jira/update/status/{projectId}/{issueKey}/from/{currentStatus}/to/{targetStatus}", { 
                issueKey: issue.key, 
                projectId: issue.projectId, 
                currentStatus: issue.status, 
                targetStatus: targetStatusName 
             }, this.headers).then(result => {
                issue.status = targetStatusName
                resolve(issue);

            }).catch(reject);   
        });        
    }

    changeAssignee(issue, username) {
        const _this=this;
        return new Promise((resolve, reject) => {
            const restClient = new rest.RestClient();
            restClient.getJson(_this.baseUrl + "/rest/jira/update/assignee/{issueKey}/{username}", { 
                issueKey: issue.key, 
                username: username
             }, this.headers).then(result => {
                issue.assignee = { assignee: username }
                resolve(issue);

            }).catch(reject);   
        });  
    }

    changeFields(issue, fieldChanges) {

        const fieldChangesResolved = this.rreplaceAliasesInFieldChanges(fieldChanges);
        return new Promise((resolve, reject) => {
            const restClient = new rest.RestClient();
            restClient.postJson(this.baseUrl +"/rest/jira/update/{issueKey}", { issueKey: issue.key }, fieldChangesResolved, this.headers ).then(result => {
                for(let propertyName in fieldChangesResolved) {
                    issue[this.fieldNameToAlias[propertyName] || propertyName] = result[propertyName];
                }
                resolve(issue);

            }).catch(reject);   
        });
    }

    rreplaceAliasesInFieldChanges(fieldChanges) {
        const resolved = {};
        for(let fieldName in fieldChanges) {
            resolved[this.aliasToFieldname[fieldName] || fieldName] = fieldChanges[fieldName];
        }
        return resolved;
    }
}