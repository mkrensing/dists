export function withoutDuplicates(issues, keyExtractorCallback) {

    var keyIndex = {};
    var filtered = [];

    issues.forEach(issue => {
        var key = keyExtractorCallback(issue);
        if(! keyIndex[key]) {
            filtered.push(issue);
        }
        keyIndex[key] = key;
    });

    return filtered;
}

export function listToObject(values, initialValueCallback) {
    var result={};
    initialValueCallback = initialValueCallback || function() { return null };
    values.forEach(value => {
        result[value] = initialValueCallback();
    });
    return result;
}

export function sliceArray(array, sliceIndexes, options) {
    let arraysByName = {};

    sliceIndexes.forEach((sliceInfo, i) => {
        // Start index for the current slice
        let startIndex = sliceInfo.index;
        if (options?.removeSeparatorItem) {
            startIndex++;
        }

        // Determine the end index: next slice's start index or the end of the array
        let endIndex = (i + 1 < sliceIndexes.length) ? sliceIndexes[i + 1].index - 1 : array.length - 1;

        // Add the sliced portion of the array
        arraysByName[sliceInfo.name] = array.slice(startIndex, endIndex + 1);
    });

    return arraysByName;
}