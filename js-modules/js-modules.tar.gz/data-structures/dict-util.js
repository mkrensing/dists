export function createIndex(arrayOfObjects, options) {
    var index={};
    arrayOfObjects.forEach(object => {
        for(let key in object) {
            if(options?.uniqueValues) {
                index[key] = object[key];
            } else {
                index[key] = index[key] || [];
                index[key].push(object[key]);
            }

        }
    });
    
    return index;
}