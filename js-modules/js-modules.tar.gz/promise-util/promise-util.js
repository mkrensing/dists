export function sequence(promiseCallbacks) {
    return promiseCallbacks.reduce((accumulator, currentPromiseCallback) => {
        return accumulator.then(results => {
            return currentPromiseCallback().then(result => {
                return [...results, result];
            });
        });
    }, Promise.resolve([]));
}

export function sequenceChain(promiseCallbacks, initalArgument) {
    return promiseCallbacks.reduce((accumulator, currentPromiseCallback) => {
        return accumulator.then(results => {
            const promise = currentPromiseCallback(results);
            if(! promise) {
                // throw new Error("The callback did not return a promise: " + currentPromiseCallback);
                return results
            }
            return promise.then(result => {
                return result;
            });
        });
    }, Promise.resolve(initalArgument));
}