export function sequence(promiseCallbacks) {
    return promiseCallbacks.reduce((accumulator, currentPromiseCallback) => {
        return accumulator.then(results => {
            return currentPromiseCallback().then(result => {
                return [...results, result];
            });
        });
    }, Promise.resolve([]));
}

export function sequenceChain(promiseCallbacks, initalArgument) {
    return promiseCallbacks.reduce((accumulator, currentPromiseCallback) => {
        return accumulator.then(result => {
            const promise = currentPromiseCallback(result);
            if(! promise) {
                // throw new Error("The callback did not return a promise: " + currentPromiseCallback);
                return result
            }
            return promise.then(result => {
                return result;
            });
        });
    }, Promise.resolve(initalArgument));
}

export function parallel(promises) {

    return new Promise((resolve, reject) => {

        Promise.allSettled(promises).then((results) => {
            let rejected = results.filter(result => result.status === "rejected").map(result => result.reason);
            if(rejected.length > 0) {
                reject(rejected)
            } else {
                let fullfilled = results.map(result => result.value);
                resolve(fullfilled);
            }
        });
    });

}
