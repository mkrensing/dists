export class Actions {

    constructor(targetElementSelector) {
        this.pendingActions = [];
        this.timeoutID = null;
        this.errorExists = false;  // Tracks if any task has an error

        // Append HTML structure to target element
        const targetElement = document.querySelector(targetElementSelector);
        if(! targetElement) {
            throw new Error("Element not found for selector:" + targetElementSelector);
        }
        targetElement.innerHTML = `
            <div id="task-overlay" class="overlay">
                <button id="close-btn" class="close-btn">&times;</button>
                <ul id="task-list"></ul>
            </div>

            <div id="error-overlay" class="error-overlay">
                <div class="error-message-box">
                    <p id="error-message"></p>
                    <button id="error-ok-btn" class="ok-btn">OK</button>
                </div>
            </div>
        `;

        // Close button functionality
        document.getElementById('close-btn').addEventListener('click', () => {
            this.hideOverlay();
        });

        // Error OK button functionality
        document.getElementById('error-ok-btn').addEventListener('click', () => {
            this.hideErrorOverlay();
        });

        this.hideOverlay();
        this.hideErrorOverlay();
        this.errorMessageConverter = function(error) { return "" + error };
    }

    setErrorMessageConverter(errorMessageConverter) {
        this.errorMessageConverter = errorMessageConverter;
    }

    // Method to show the overlay
    show() {
        this.updateTaskList();
        this.showOverlay();

        // Only close automatically if no error exists and all tasks are completed
        if (this.timeoutID) {
            clearTimeout(this.timeoutID);
        }
        if (!this.errorExists && this.pendingActions.every(action => action.completed)) {
            this.timeoutID = setTimeout(() => {
                this.hideOverlay();
            }, 1500);
        }

        this.removeCompletedTasksIfOverflow();
    }

    createTaskPromise(callback, description) {

        if(! description) {
            throw new Error("Missing description argument. description is null");
        }

        if(! callback) {
            throw new Error("Missing callback argument. callback is null for task " + description);
        }

        const _this=this;
        return function(task) {

            return new Promise((resolve, reject) => {
                const promise = callback(task);
                if(promise) {
                    const taskId = _this.addTask({ description: description });
                    promise.then(result => {
                        _this.completeTask(taskId);
                        resolve(result);
                    }).catch(error => {
                        console.log("Error during action execution", error);
                        _this.completeTask(taskId, _this.errorMessageConverter(error));
                        reject(error);
                    })
                } else {
                    console.log("PromiseFactory return null instead of promise", description);
                    resolve(task);
                }

            });
        }
    }

    // Method to add a task
    addTask(config) {
        config.id = config.id || generateUniqueId();
        this.pendingActions.push({ id: config.id, description: config.description, completed: false, error: false, errorMessage: '' });
        this.show();

        return config.id;
    }

    // Method to complete a task
    completeTask(taskId, errorMessage) {
        const task = this.pendingActions.find(action => action.id === taskId);
        if (task) {
            task.completed = true;

            if (errorMessage) {
                task.errorMessage = errorMessage;
                task.error = true;

                this.errorExists = true;
                this.showCloseButton();  // Show Close button when an error occurs
            }
        }
        this.show();
    }

    // Private method to update the task list in the DOM
    updateTaskList() {
        const taskList = document.getElementById('task-list');
        taskList.innerHTML = '';  // Clear current task list

        [ ...this.pendingActions ].reverse().forEach(action => {
            const listItem = document.createElement('li');

            // Create icon column (first column)
            const icon = document.createElement('span');
            icon.classList.add('icon');
            if (action.error) {
                icon.textContent = '⚠';
                icon.classList.add('error');
                icon.addEventListener('click', () => {
                    this.showErrorOverlay(action.errorMessage);
                });
            } else if (action.completed) {
                icon.textContent = '✔';
                icon.classList.add('checkmark');
            } else {
                icon.textContent = '⚙';
                icon.classList.add('gear');
            }

            // Create task description (second column)
            const description = document.createElement('span');
            description.textContent = action.description;
            description.classList.add('task-status');

            // Append icon and description to the list item
            listItem.appendChild(icon);
            listItem.appendChild(description);

            taskList.appendChild(listItem);
        });
    }

    // Private method to show the overlay
    showOverlay() {
        const overlay = document.getElementById('task-overlay');
        overlay.style.display = 'block';
    }

    // Private method to hide the overlay
    hideOverlay() {
        const overlay = document.getElementById('task-overlay');
        overlay.style.display = 'none';
        this.errorExists = false;
        this.hideCloseButton();
    }

    // Show Close button
    showCloseButton() {
        const closeButton = document.getElementById('close-btn');
        closeButton.style.display = 'block';
    }

    hideCloseButton() {
        const closeButton = document.getElementById('close-btn');
        closeButton.style.display = 'none';
    }

    // Show error overlay
    showErrorOverlay(errorMessage) {
        const errorOverlay = document.getElementById('error-overlay');
        const errorMessageElement = document.getElementById('error-message');
        errorMessageElement.textContent = `Error: ${errorMessage}`;
        errorOverlay.style.display = 'flex';
    }

    // Hide error overlay
    hideErrorOverlay() {
        const errorOverlay = document.getElementById('error-overlay');
        errorOverlay.style.display = 'none';
    }

    // Remove completed tasks if number of tasks exceeds threshold
    removeCompletedTasksIfOverflow() {
        const threshold = 5;
        if (this.pendingActions.length > threshold) {
            this.pendingActions = this.pendingActions.filter(action => !action.completed || action.error);
            setTimeout(() => {
                this.updateTaskList();
            }, 1500);
        }
    }

    clear() {
        if(! this.errorExists) {
            this.pendingActions = [];
        }
    }
}

function generateUniqueId() {
    return `id-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}