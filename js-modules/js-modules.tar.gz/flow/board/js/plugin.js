export class Plugin {

    constructor() {
        this._targetElement = "";
        this.pluginHtml = "";
        this.eventHandlers = {};
    }

    get targetElement() {
        return this._targetElement;
    }

    set targetElement(aTargetElement) {
        this._targetElement = aTargetElement;
    }

    get html() {
        return this.pluginHtml;
    }

    enable() {

    }

    repaintTasks(taskElements) {

    }

    onEvent(eventName, callback) {
        this.eventHandlers[eventName] = this.eventHandlers[eventName] || [];
        this.eventHandlers[eventName].push(callback);
    }

    triggerEvent(eventName, ...args) {
        (this.eventHandlers[eventName] || []).forEach(callback => {
            callback(...args);
        })
    }    
}