import { sequenceChain } from 'promise-util';
import { NotificationCenter } from './plugins/notifications.js';


export class Column {

    constructor(column)  {
        this.config = {
            ...column,
            tag: column.tag || {}
        }
        this.enterColumnCallbacks = [];
        this.leaveColumnCallbacks = [];
        this.enterAreaCallbacks = [];
        this.leaveAreaCallbacks = [];        
        if(column.onEnterColumn) {
            this.onEnterColumn(column.onEnterColumn);
        }
        if(column.onLeaveColumn) {
            this.onLeaveColumn(column.onLeaveColumn);
        }
        if(column.onEnterArea) {
            this.onEnterArea(column.onEnterArea);
        }
        if(column.onLeaveArea) {
            this.onLeaveArea(column.onLeaveArea);
        }        
    }

    onEnterColumn(callbacks) {

        if(! Array.isArray(callbacks)) {
            callbacks = [ callbacks ];
        }

        this.enterColumnCallbacks = this.enterColumnCallbacks.concat(callbacks)
    }

    onLeaveColumn(callbacks) {

        if(! Array.isArray(callbacks)) {
            callbacks = [ callbacks ];
        }

        this.leaveColumnCallbacks = this.leaveColumnCallbacks.concat(callbacks)
    }

    onEnterArea(callbacks) {

        if(! Array.isArray(callbacks)) {
            callbacks = [ callbacks ];
        }

        this.enterAreaCallbacks = this.enterAreaCallbacks.concat(callbacks)
    }

    onLeaveArea(callbacks) {

        if(! Array.isArray(callbacks)) {
            callbacks = [ callbacks ];
        }

        this.leaveAreaCallbacks = this.leaveAreaCallbacks.concat(callbacks)
    }


    enterColumn(task, areaName) {
        // console.log("Task moves from", task.originalPosition.columnId, "to", this.config.id)
        return this.scheduleCallbacks(this.enterColumnCallbacks, task, areaName)
    }

    leaveColumn(task, areaName) {
        // console.log("Task leaves from", this.config.id, "to", task.position.columnId)
        return this.scheduleCallbacks(this.leaveColumnCallbacks, task, areaName)
    }

    enterArea(task, areaName) {
        // console.log("Task moves from area", task.originalPosition.areaName, "to area", areaName)
        return this.scheduleCallbacks(this.enterAreaCallbacks, task, areaName)
    }

    leaveArea(task, areaName) {
        console.log("Task leaves area", areaName, this.leaveAreaCallbacks)
        return this.scheduleCallbacks(this.leaveAreaCallbacks, task, areaName)
    }    


    scheduleCallbacks(callbacks, task, areaName) {
        const column=this;
        let promisesFactories = callbacks.flatMap(action => {
            if(isCallback(action)) {
                return action(task, column, areaName);
            } else if(action.transition && action.description) {
                // console.log("Action found", action.description(task, column, areaName), action);
                let callbacks = action.transition(task, column, areaName);
                let descriptions = action.description(task, column, areaName) || "<Missing Description>";
                if(! callbacks) {
                    return null;
                }
                
                if(! Array.isArray(callbacks)) {
                    callbacks = [ callbacks ];
                }
                if(! Array.isArray(descriptions)) {
                    descriptions = [ descriptions ];
                }
                
                if(callbacks.length != descriptions.length) {
                    throw Error("Mismatch in callback and description configuration: " + callbacks + ", " + descriptions)
                }
                
                return callbacks.flatMap((callback, index) => {
                    if(! callback) {
                        return [];
                    }
                    return NotificationCenter.createProxy(callback, descriptions[index]);
                });
                
            } else {
                throw new Error("Illegal object: " + action)
            }
        }).filter(result => isCallback(result));

        return sequenceChain(promisesFactories, task).catch(error => {
            return new Promise((resolve, reject) => {
                reject({ error: error, task: task });
            });
        });

    }

    get id() {
        return this.config.id;
    }

    get name() {
        return this.config.name;
    }
    
    get group() {
        return this.config.group;
    }     

    get areas() {
        return this.config.areas;
    }       

    get tag() {
        return this.config.tag;
    }

    set tag(tag) {
        this.config.tag = tag;
    }
}

function isCallback(value) {
    return !!value && (typeof value === 'function');
}