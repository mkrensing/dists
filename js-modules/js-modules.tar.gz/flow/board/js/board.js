import { sequenceChain, sequence } from 'promise-util';
import { Actions } from './actions.js';
export { Actions }

class Column {

    constructor(column, actionsUpdater)  {
        this.config = {
            id: column.id,
            name: column.name,
            group: column.group,
            areas: column.areas,
            tag: column.tag || {}
        }
        this.enterCallbacks = [];
        this.leaveCallbacks = [];
        if(column.onEnter) {
            this.onEnter(column.onEnter);
        }
        if(column.onLeave) {
            this.onLeave(column.onLeave);
        }
        this.actionsUpdater = actionsUpdater;
    }

    onEnter(callback) {
        this.enterCallbacks.push(callback)
    }

    onLeave(callback) {
        this.leaveCallbacks.push(callback)
    }

    enter(task, areaName) {
        const column=this;
        let enterPromisesFactories = this.enterCallbacks.map(action => {
            if(isCallback(action)) {
                return action(task, column, areaName);
            } else if(action.action && action.description) {
                let callback = action.action(task, column, areaName);
                let description = action.description(task, column, areaName);
                if(! callback) {
                    console.log("Skip action", description);
                    return null;
                }
                console.log("Schedule action", description);
                return column.actionsUpdater.createTaskPromise(callback, description);
            } else {
                throw new Error("Illegal object: " + action)
            }

        }).filter(result => isCallback(result));

        return sequenceChain(enterPromisesFactories, task);
    }

    leave(task, areaName) {
        const column=this;
        let leavePromisesFactories = this.leaveCallbacks.map(action => {
            if(isCallback(action)) {
                return action(task, column, areaName);
            } else if(action.action && action.description) {
                console.log("Action found", action.description(task, column, areaName));
                return column.actionsUpdater.createTaskPromise(action.action(task, column, areaName), action.description(task, column, areaName));
            } else {
                throw new Error("Illegal object: " + action)
            }
        }).filter(result => isCallback(result));

        return sequenceChain(leavePromisesFactories, task);
    }

    get id() {
        return this.config.id;
    }

    get name() {
        return this.config.name;
    }
    
    get group() {
        return this.config.group;
    }     

    get areas() {
        return this.config.areas;
    }       

    get tag() {
        return this.config.tag;
    }

    set tag(tag) {
        this.config.tag = tag;
    }
}

function isCallback(value) {
    return !!value && (typeof value === 'function');
}

export class FlowBoard {

    constructor(targetSelector) {
        this.targetSelector = targetSelector;
        this.targetElement = document.querySelector(targetSelector);
        this.columns = [];
        this.dropCallbacks = [];
        this.renderedCallbacks = [];
        this.zoomCallbacks = [];
        this.tasks = [];
        this.taskIndex = {};
        this.synchronizedAreaSelectors = [];
        this.columnTemplate = this.getDefaultColumnTemplate;
        this.taskTemplate = this.getDefaultTaskTemplate;

        this.selectedTasks = [];
        this.shiftPressed = false;
        this.completeDragAndDropPreview = false;
        this.actionsUpdater = null;
    }

    enableActionsUpdater(actionsUpdater) {
        this.actionsUpdater = actionsUpdater;
    }

    setCompleteDragAndDropPreview(completeDragAndDropPreview) {
        this.completeDragAndDropPreview = completeDragAndDropPreview;
    }

    setColumnTemplate(columnTemplateCallback) {
        this.columnTemplate = columnTemplateCallback;
    }

    setTaskTemplate(taskTemplateCallback) {
        this.taskTemplate = taskTemplateCallback;
    }

    getColumnById(columnId) {

        return this.columns.find(column => column.id == columnId);
    }

    addColumns(columns) {
        const _this=this;
        columns.forEach(column => {
            _this.addColumn(column)
        });
    }

    addColumn(column) {
        this.columns.push(new Column({
            id: column.id,
            name: column.name,
            group: column.group,
            areas: column.areas,
            tag: column.tag || {},
            onEnter: column.onEnter,
            onLeave: column.onLeave
        }, this.actionsUpdater));
    }


    addTask(position, task) {
        position = position || { columnId: "mycolumn", areaName: "areaA" } && {}
        task = task || { id: "mytask-id", ...task } && {}

        task.id = task.id || generateUniqueId();
        task.position = position

        this.taskIndex[task.id] = task;
        this.tasks.push(task);
    }

    updateTask(updatedTask) {

        this.taskIndex[updatedTask.id] = updatedTask;
        const taskIndex = this.tasks.findIndex(task => task.id == updatedTask.id);
        if(taskIndex !== -1) {
            this.tasks[taskIndex] = updatedTask;
        } else {
            console.log("No Task found with id", updatedTask.id);
        }
    }

    findTasks(columnFilter) {

        const _this=this;
        columnFilter = columnFilter || function(column) { return true };
        return this.columns.filter(column => columnFilter(column)).flatMap(column => {
            return this.tasks.filter(task => task.position.columnId == column.id)
        });
    }

    addSynchronizedArea(areaSelector) {
        this.synchronizedAreaSelectors.push(areaSelector);
    }

    onDrop(callback) {
        this.dropCallbacks.push(callback);
    }

    onRender(callback) {
        this.renderedCallbacks.push(callback);
    }

    onZoom(callback) {
        this.zoomCallbacks.push(callback);
    }

    onEnter(callback, columnFilter) {
        columnFilter = columnFilter || function(column) { return true };
        this.columns.filter(columnFilter).forEach(column => {
            column.onEnter(callback);
        });
    }

    onLeave(callback, columnFilter) {
        columnFilter = columnFilter || function(column) { return true };
        this.columns.filter(columnFilter).forEach(column => {
            column.onLeave(callback);
        });
    }    

    onTransition(transitionConfig, columnFilter) {

        if(! transitionConfig.id) {
            throw new Error("Missing id property for columnId. Args: " + transitionConfig);
        }

        if(transitionConfig.enter) {
            this.onEnter(transitionConfig.enter,  column => column.id == transitionConfig.id)
        }
        
        if(transitionConfig.leave) {
            this.onLeave(transitionConfig.leave,  column => column.id == transitionConfig.id)
        }
    }    

    render() {
        this.renderBoard();
        this.renderTasks();
        this.enableDragAndDrop();
        this.synchronizeAreas();
        this.onZoom(() => {
            this.synchronizeAreas();
        });
        this.enableZoomDetection();
        this.triggerOnRenderEvents("init");
    }


    renderBoard() {
        this.targetElement.innerHTML = this.getBoardTemplate(this.columns);
    }

    renderTasks() {
        const _this=this;
        this.findTasks().forEach(task => {
            _this.renderTask(task);
        });
    }

    renderTask(task) {
        this.targetElement.querySelector(`.flowBoard .columns #${task.position.columnId} .area.${task.position.areaName} `).insertAdjacentHTML('beforeend', this.taskTemplate(task));
    }

    repaintTasks(tasks) {
        tasks = tasks || this.findTasks();
    
        // Array mit Task-Elementen erstellen
        const taskElements = tasks
            .map(task => ({ task: task, element: document.getElementById(task.id) }))
            .filter(({ task, element }) => {
                if (element) {
                    element.outerHTML = this.taskTemplate(task);
                    return true;
                } else {
                    console.error("Task not found on board", task);
                    return false;
                }
            }).map(({ task, element }) => document.getElementById(task.id));
        
        this.enableDragAndDropForTasks(taskElements);
    }

    synchronizeAreas() {
        
        let _this=this;
        this.synchronizedAreaSelectors.forEach(areaSelector => {
            
            const areas = _this.targetElement.querySelectorAll(areaSelector);
            _this.synchronizeElements(areas);
        });
    }

    synchronizeElements(nodeListElements) {

        const elements = [...nodeListElements ];

        // remove the max height from all areas
        elements.forEach(element => {
            element.style.height = "auto";
        });

        // Determine the max height
        let maxHeight = elements.reduce((max, lane) => {
            return Math.max(max, lane.scrollHeight);
        }, 0);

        // Set the max height to all fast-lane areas
        elements.forEach(lane => {
            lane.style.height = `${maxHeight}px`;
        });
    }

    triggerOnRenderEvents(eventName) {
        this.renderedCallbacks.forEach(callback => callback(this, eventName));
    }

    enableDragAndDrop() {
        this.enableShiftKeyDetection();
        this.enableDragAndDropForBoard();
        this.enableDragAndDropForTasks();
    }

    enableShiftKeyDetection() {
        
        const _this=this;
        // Listen for shift key press and release
        document.addEventListener("keydown", (e) => {
            if (e.key === "Shift") _this.shiftPressed = true;
        });
    
        document.addEventListener("keyup", (e) => {
            if (e.key === "Shift") _this.shiftPressed = false;
        });        
    }

    enableZoomDetection() {
        let lastDevicePixelRatio = window.devicePixelRatio;
        let _this=this;
        window.addEventListener('resize', function() {

            if (window.devicePixelRatio !== lastDevicePixelRatio) {
                lastDevicePixelRatio = window.devicePixelRatio;
                _this.zoomCallbacks.forEach(callback => callback())
            }
        });        
    }

    enableDragAndDropForBoard() {

        const _this=this;
        const droppables = document.querySelectorAll(".area");

        let isDragging = false;
        let scrollThreshold = 150;  // Bereich, in dem das Scrollen beginnt
        let maxScrollSpeed = 200;   // Maximale Scrollgeschwindigkeit
        let minScrollSpeed = 50;    // Minimale Scrollgeschwindigkeit
        let scrollInterval = null;  // Speichert den Timer für das kontinuierliche Scrollen
        
        document.addEventListener('dragover', function(event) {
            if (isDragging) {
                let viewportHeight = window.innerHeight;
        
                // Berechne die Scrollgeschwindigkeit basierend auf der Nähe zum oberen Rand
                if (event.clientY < scrollThreshold) {
                    let overlapTop = scrollThreshold - event.clientY;
                    let speed = calculateScrollSpeed(overlapTop);
                    startScrolling(-speed);  // Scroll nach oben
                }
        
                // Berechne die Scrollgeschwindigkeit basierend auf der Nähe zum unteren Rand
                if (event.clientY > viewportHeight - scrollThreshold) {
                    let overlapBottom = event.clientY - (viewportHeight - scrollThreshold);
                    let speed = calculateScrollSpeed(overlapBottom);
                    startScrolling(speed);  // Scroll nach unten
                }
        
                // Stoppe das Scrollen, wenn sich die Maus nicht mehr im Scrollbereich befindet
                if (event.clientY >= scrollThreshold && event.clientY <= viewportHeight - scrollThreshold) {
                    stopScrolling();
                }
            }
        });
        
        document.addEventListener('dragstart', function() {
            isDragging = true;
        });
        
        document.addEventListener('dragend', function() {
            isDragging = false;
            stopScrolling();
        });
        
        function calculateScrollSpeed(overlap) {
            let percentage = overlap / scrollThreshold;
            return Math.min(maxScrollSpeed, minScrollSpeed + percentage * (maxScrollSpeed - minScrollSpeed));
        }
        

        function startScrolling(speed) {

            if (scrollInterval) {
                stopScrolling();
            }
        
            scrollInterval = setInterval(function() {
                window.scrollBy(0, speed);
            }, 50); 
        }
        

        function stopScrolling() {
            if (scrollInterval) {
                clearInterval(scrollInterval);
                scrollInterval = null;
            }
        }

        droppables.forEach((zone) => {
            zone.addEventListener("dragover", (event) => {
                event.preventDefault();

                const bottomTask = insertAboveTask(zone, event.clientY);
                if(! bottomTask) {
                    _this.selectedTasks.forEach((curTask) => {
                        curTask.classList.add("drag-preview");
                        zone.appendChild(curTask);
                    });                    

                } else {
                    _this.selectedTasks.slice().reverse().reduce((lastTask, curTask) => {
                        curTask.classList.add("drag-preview");
                        zone.insertBefore(curTask, lastTask);
                        return curTask; // Update lastTask for the next iteration
                    }, bottomTask);
                }
            });
        });

        const insertAboveTask = (zone, mouseY) => {
            const els = zone.querySelectorAll(".task:not(.is-dragging)");
    
            let closestTask = null;
            let closestOffset = Number.NEGATIVE_INFINITY;
    
            els.forEach((task) => {
                const { top } = task.getBoundingClientRect();
                const offset = mouseY - top;
    
                if (offset < 0 && offset > closestOffset) {
                    closestOffset = offset;
                    closestTask = task;
                }
            });
    
            return closestTask;
        };

    }

    withoutEventListener(originalElement) {

        const clonedElement = originalElement.cloneNode(true);
        originalElement.parentNode.replaceChild(clonedElement, originalElement);
        return clonedElement;
    }

    enableDragAndDropForTasks(taskElements) {

        const draggables = taskElements || this.targetElement.querySelectorAll(".task");
    
        draggables.forEach((originalTask) => {
            const task = this.withoutEventListener(originalTask);
    
            // Click handler to toggle selection when Shift is pressed
            task.addEventListener("click", (e) => {
                if (this.shiftPressed) {
                    e.preventDefault(); 
                    task.classList.toggle("is-selected");
    
                    if (task.classList.contains("is-selected")) {
                        this.selectedTasks.push(task);
                    } else {
                        this.selectedTasks = this.selectedTasks.filter(t => t !== task);
                    }
                }
            });
    
            task.addEventListener("dragstart", (event) => {
                if (!task.classList.contains("is-selected")) {
                    // If the task is not selected, make it the only selected task
                    this.selectedTasks.forEach((t) => t.classList.remove("is-selected"));
                    this.selectedTasks = [];
                    task.classList.add("is-selected");
                    this.selectedTasks.push(task);
                }
    
                task.classList.add("is-dragging");
                this.setDragPreview(event)
            });
    
            task.addEventListener("dragend", () => {

                const firstDraggedTask = this.selectedTasks.at(0);
                const previousTask = this.findPreviousTask();
                const nextTask = this.findNextTask();
                const column = this.findClosestColumn();
                const areaName = this.findClosestAreaName();

                this.selectedTasks.forEach(taskElement => {
                    taskElement.classList.remove("is-selected");
                    taskElement.classList.remove("is-dragging");
                    taskElement.classList.remove("drag-preview");
                });

                const droppedTasks = this.selectedTasks.map(taskElement => {

                    const task = this.taskIndex[taskElement.id];
                    
                    task.originalPosition = task.position;
                    task.position = { columnId: column.id, areaName: areaName };
                    
                    return task;

                });
    
                this.selectedTasks = [];
                this.synchronizeAreas();
                this.triggerOnRenderEvents("dragend");

                const actions = droppedTasks.filter(task => {
                    return task.originalPosition.columnId != task.position.columnId || task.originalPosition.areaName != task.position.areaName
                }).map(task => {
                    const originalColumn = this.getColumnById(task.originalPosition.columnId);
                    const targetColumn = this.getColumnById(task.position.columnId);

                    const leaveAndEnter = [
                        () => originalColumn.leave(task, task.originalPosition.areaName),
                        () => targetColumn.enter(task, task.position.areaName)
                    ]

                    return leaveAndEnter;
                });

                Promise.all(actions.map(leaveAndEnter => {
                    return sequence(leaveAndEnter)
                })).then(() => {

                    if(this.actionsUpdater) {
                        this.actionsUpdater.clear();
                    }
                    const updatedTasks = droppedTasks.map(task => {
                        return this.taskIndex[task.id];
                    });

                    this.dropCallbacks.forEach(dropCallback => {
                        dropCallback({ previousTask: previousTask, nextTask: nextTask,column: column, areaName: areaName, tasks: updatedTasks });
                    });                    
                }).catch((errors) => {
                    console.log("Erros during leave/enter", errors);
                })

            });
        });
   
    }

    setDragPreview(event) {
        if(this.completeDragAndDropPreview) {
            this.setCompleteDragPreview(event);
        } else {
            this.setSummaryDragPreview(event);
        }
    }

    setSummaryDragPreview(event) {
        const dragPreview = document.createElement("div");
        const dragPreviewHtml = this.selectedTasks.map(task => task.outerHTML).join("");
        dragPreview.innerHTML = dragPreviewHtml;

        event.dataTransfer.setData('text/html', dragPreview.outerHTML);
    }

    setCompleteDragPreview(event) {
        const dragPreview = document.createElement("div");
        dragPreview.style.position = "absolute";
        dragPreview.style.top = "-9999px";  // Hide the preview element offscreen
        dragPreview.style.zIndex = "-1";    // Prevent it from interfering with the document
    
        const dragPreviewHtml = this.selectedTasks.map(task => task.outerHTML).join("");
        dragPreview.innerHTML = dragPreviewHtml;
        document.body.appendChild(dragPreview);  // Add the preview element to the document
    
        event.dataTransfer.setDragImage(dragPreview, 0, 0);  
    }


    getColumnElement(columnId) {
        return this.targetElement.querySelector('.columns .column#' + columnId);
    }

    getBoardTemplate(columns) {
        const _this=this;
        const columnDivs = columns.map(column => _this.columnTemplate(column)).join('\n');
    
        return `
    <div class="flowBoard">
        <div class="columns">
        ${columnDivs}
        </div>
    </div>
    `
    }
   
    
    getDefaultColumnTemplate(column) {

        const areaDivs = column.areas.map(area => {
            return `<div class="area ${area.name} ${(area.classNames || []).join(" ")}" >
                <span class="header" >${area.header || ""}</span>
            </div>`
        }).join('\n');

        return `
            <div class="column ${column.group || ""}" id="${column.id}">
            <div class="header" >
                <div class="title">${column.name}</div>
                <div class="subtitle"></div>
            </div>
            ${areaDivs}
            </div>`
    }

    getDefaultTaskTemplate(task) {
        return `
        <div class="task ${(task.classNames || []).join(" ")}" draggable="true" id="${task.id}" >
            <div class="header">${task.header}</div>
            <div class="text" >${task.text}</div>
        </div>`
    }

    findClosestColumn() {
        const columnElement = this.selectedTasks.at(0).closest('.column');
        return this.columns.find(column => column.id == columnElement.id);
    }

    findClosestAreaName() {
        const areaElement = this.selectedTasks.at(0).closest('.area');
        return [...areaElement.classList].filter(className => className != "area")[0];
    }

    findPreviousTask() {

        const previousTaskElement = findPreviousTaskElement(this.selectedTasks.at(0));
        if (! previousTaskElement) {
            return null;
        }

        return this.taskIndex[previousTaskElement.id];
    }
    
    findNextTask() {

        const nextTaskElement = findNextTaskElement(this.selectedTasks.at(-1));
        if (! nextTaskElement) {
            return null;
        }

        return this.taskIndex[nextTaskElement.id];
    }

}



function generateUniqueId() {
    return `id-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}



function findPreviousTaskElement(element) {

    let previousTask = element.previousElementSibling;

    while (previousTask) {
        if (previousTask.classList.contains('task')) {
            return previousTask;
        }
        previousTask = previousTask.previousElementSibling;
    }

    let previousArea = element.closest('.area').previousElementSibling;

    while (previousArea) {
        if (previousArea.classList.contains('area')) {
            let lastTaskInArea = previousArea.querySelector('.task:last-of-type');
            if (lastTaskInArea) {
                return lastTaskInArea;
            }
        }
        previousArea = previousArea.previousElementSibling;
    }

    return null;
}

function findNextTaskElement(element) {
    let nextTask = element.nextElementSibling;

    while (nextTask) {
        if (nextTask.classList.contains('task')) {
            return nextTask;
        }
        nextTask = nextTask.nextElementSibling;
    }

    let nextArea = element.closest('.area').nextElementSibling;

    while (nextArea) {
        if (nextArea.classList.contains('area')) {
            let firstTaskInArea = nextArea.querySelector('.task:first-of-type');
            if (firstTaskInArea) {
                return firstTaskInArea;
            }
        }
        nextArea = nextArea.nextElementSibling;
    }

    return null;
}
