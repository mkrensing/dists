import { Plugin } from '../plugin.js'

export class ScrollingPlugin extends Plugin {

    constructor() {
        super();

    }

    enable() {
        enableScrolling();
    }
}


function enableScrolling() {

    let isDragging = false;
    let scrollThreshold = 150;  // Bereich, in dem das Scrollen beginnt
    let maxScrollSpeed = 200;   // Maximale Scrollgeschwindigkeit
    let minScrollSpeed = 50;    // Minimale Scrollgeschwindigkeit
    let scrollInterval = null;  // Speichert den Timer für das kontinuierliche Scrollen

    document.addEventListener('dragstart', () => {
        isDragging = true;
    });

    document.addEventListener('dragend', () => {
        isDragging = false;
    });


    document.addEventListener('dragover', (event) => {
        if (isDragging) {
            let viewportHeight = window.innerHeight;
            let viewportWidth = window.innerWidth;

            // Vertikales Scrollen
            if (event.clientY < scrollThreshold) {
                let overlapTop = scrollThreshold - event.clientY;
                let speed = calculateScrollSpeed(overlapTop);
                startScrolling(0, -speed);  // Scroll nach oben
            }

            if (event.clientY > viewportHeight - scrollThreshold) {
                let overlapBottom = event.clientY - (viewportHeight - scrollThreshold);
                let speed = calculateScrollSpeed(overlapBottom);
                startScrolling(0, speed);  // Scroll nach unten
            }

            // Horizontales Scrollen
            if (event.clientX < scrollThreshold) {
                let overlapLeft = scrollThreshold - event.clientX;
                let speed = calculateScrollSpeed(overlapLeft);
                startScrolling(-speed, 0);  // Scroll nach links
            }

            if (event.clientX > viewportWidth - scrollThreshold) {
                let overlapRight = event.clientX - (viewportWidth - scrollThreshold);
                let speed = calculateScrollSpeed(overlapRight);
                startScrolling(speed, 0);  // Scroll nach rechts
            }

            // Stoppe das Scrollen, wenn sich die Maus nicht mehr im Scrollbereich befindet
            if (event.clientY >= scrollThreshold && event.clientY <= viewportHeight - scrollThreshold &&
                event.clientX >= scrollThreshold && event.clientX <= viewportWidth - scrollThreshold) {
                stopScrolling();
            }
        }
    });

    document.addEventListener('dragend', () => {
        stopScrolling();
    });

    function calculateScrollSpeed(overlap) {
        let percentage = overlap / scrollThreshold;
        return Math.min(maxScrollSpeed, minScrollSpeed + percentage * (maxScrollSpeed - minScrollSpeed));
    }
    
    function startScrolling(horizontalSpeed, verticalSpeed) {
    
        if (scrollInterval) {
            stopScrolling();
        }
    
        scrollInterval = setInterval(() => {
            window.scrollBy(horizontalSpeed, verticalSpeed);
        }, 50);
    }
    
    function stopScrolling() {
        if (scrollInterval) {
            clearInterval(scrollInterval);
            scrollInterval = null;
        }
    }        

}



