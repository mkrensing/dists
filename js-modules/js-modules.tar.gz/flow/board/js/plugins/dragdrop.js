import { Plugin } from '../plugin.js'

export class DragAndDropPlugin extends Plugin {

    constructor(config) {
        super();
        // TODO: replace this my querySelector ('is-selected')
        this.selectedTasks = [];
        this.completeDragAndDropPreview = config.completeDragAndDropPreview;
    }

    enable() {
        enableDragAndDropForBoard(this);
        const allTasks = this.targetElement.querySelectorAll(".task")
        enableDragAndDropForTasks(allTasks, this)
    }

    repaintTasks(taskElements) {
        enableDragAndDropForTasks(taskElements, this);
    }
}

function enableDragAndDropForBoard(context) {

    
    let isDragging = false;
    const areas = document.querySelectorAll(".area");

    document.addEventListener('dragstart', function() {
        isDragging = true;
    });

    document.addEventListener('dragend', function() {
        isDragging = false;
    });


    areas.forEach((area) => {
        area.addEventListener("dragover", (event) => {
            event.preventDefault();

            const bottomTask = insertAboveTask(area, event.clientY);
            if(! bottomTask) {
                context.selectedTasks.forEach((curTask) => {
                    curTask.classList.add("drag-preview");
                    area.appendChild(curTask);
                });                    

            } else {
                context.selectedTasks.slice().reverse().reduce((lastTask, curTask) => {
                    curTask.classList.add("drag-preview");
                    area.insertBefore(curTask, lastTask);
                    return curTask;
                }, bottomTask);
            }
        });
    });

    const insertAboveTask = (area, mouseY) => {
        const els = area.querySelectorAll(".task:not(.is-dragging)");

        let closestTask = null;
        let closestOffset = Number.NEGATIVE_INFINITY;

        els.forEach((task) => {
            const { top } = task.getBoundingClientRect();
            const offset = mouseY - top;

            if (offset < 0 && offset > closestOffset) {
                closestOffset = offset;
                closestTask = task;
            }
        });

        return closestTask;
    };

}

function enableDragAndDropForTasks(taskElements, context) {

    let shiftPressed = false;
        
    // Listen for shift key press and release
    document.addEventListener("keydown", (e) => {
        if (e.key === "Shift") shiftPressed = true;
    });

    document.addEventListener("keyup", (e) => {
        if (e.key === "Shift") shiftPressed = false;
    });        


    const draggables = taskElements;

    draggables.forEach((originalTask) => {
        const task = withoutEventListener(originalTask);

        // Click handler to toggle selection when Shift is pressed
        task.addEventListener("click", (e) => {
            if (shiftPressed) {
                e.preventDefault(); 
                task.classList.toggle("is-selected");

                if (task.classList.contains("is-selected")) {
                    context.selectedTasks.push(task);
                } else {
                    context.selectedTasks = context.selectedTasks.filter(t => t !== task);
                }
            }
        });

        task.addEventListener("mouseup", (e) => {

            context.selectedTasks = [...document.querySelectorAll(".task.is-selected")];
        });


        task.addEventListener("dragstart", (event) => {
            if (!task.classList.contains("is-selected")) {
                // If the task is not selected, make it the only selected task
                context.selectedTasks.forEach((t) => t.classList.remove("is-selected"));
                context.selectedTasks = [];
                task.classList.add("is-selected");
                // context.selectedTasks.push(task);
            }

            context.selectedTasks = [...document.querySelectorAll(".task.is-selected")];

            task.classList.add("is-dragging");
            setDragPreview(event, context.selectedTasks, context.completeDragAndDropPreview || false)
        });

        task.addEventListener("dragend", () => {
            
            if(context.selectedTasks.length == 0) {
                console.log("Nothing selected but dropped???")
            }

            if(context.selectedTasks.length > 0) {
                const firstDraggedTask = context.selectedTasks.at(0);
                const lastDraggedTask = context.selectedTasks.at(-1);
                const previousTaskElement = findPreviousTaskElement(firstDraggedTask);
                const nextTaskElement = findNextTaskElement(lastDraggedTask);
                const columnId = findClosestColumnId(firstDraggedTask);
                const areaName = findClosestAreaName(firstDraggedTask);
    
                context.selectedTasks.forEach(taskElement => {
                    taskElement.classList.remove("is-selected");
                    taskElement.classList.remove("is-dragging");
                    taskElement.classList.remove("drag-preview");
                });
    
                
                context.triggerEvent("taskMoved", { taskElements: context.selectedTasks, previousTaskElement, nextTaskElement, columnId, areaName });
                context.selectedTasks = [];
                [...document.querySelectorAll(".task.is-selected")].forEach((t) => t.classList.remove("is-selected"));
            }

        });
    });
}    

function withoutEventListener(originalElement) {

    const clonedElement = originalElement.cloneNode(true);
    originalElement.parentNode.replaceChild(clonedElement, originalElement);
    return clonedElement;
}

function findClosestColumnId(element) {
    const columnElement = element.closest('.column');
    return columnElement.id;
}

function findClosestAreaName(element) {
    const areaElement = element.closest('.area');
    return [...areaElement.classList].filter(className => className != "area")[0];
}


function findPreviousTaskElement(element) {

    let previousTask = element.previousElementSibling;

    while (previousTask) {
        if (previousTask.classList.contains('task')) {
            return previousTask;
        }
        previousTask = previousTask.previousElementSibling;
    }

    let previousArea = element.closest('.area').previousElementSibling;

    while (previousArea) {
        if (previousArea.classList.contains('area')) {
            let lastTaskInArea = previousArea.querySelector('.task:last-of-type');
            if (lastTaskInArea) {
                return lastTaskInArea;
            }
        }
        previousArea = previousArea.previousElementSibling;
    }

    return null;
}



function findNextTaskElement(element) {
    let nextTask = element.nextElementSibling;

    while (nextTask) {
        if (nextTask.classList.contains('task')) {
            return nextTask;
        }
        nextTask = nextTask.nextElementSibling;
    }

    let nextArea = element.closest('.area').nextElementSibling;

    while (nextArea) {
        if (nextArea.classList.contains('area')) {
            let firstTaskInArea = nextArea.querySelector('.task:first-of-type');
            if (firstTaskInArea) {
                return firstTaskInArea;
            }
        }
        nextArea = nextArea.nextElementSibling;
    }

    return null;
}

function setDragPreview(event, selectedTasks, completeDragAndDropPreview = false) {

    if(completeDragAndDropPreview) {
        setCompleteDragPreview(event, selectedTasks);
    } else {
        setSummaryDragPreview(event, selectedTasks);
    }
}

function createDragPreviewElement(previewElements) {

    const existingDragPreview = document.getElementById("dragPreview");
    if(existingDragPreview) {
        return existingDragPreview;
    }

    const dragPreview = document.createElement("div");
    dragPreview.id = "dragPreview";
    dragPreview.style.position = "absolute";
    dragPreview.style.top = "-9999px";
    dragPreview.style.zIndex = "-1";
    dragPreview.innerHTML = previewElements.map(element => element.outerHTML).join("");

    document.body.appendChild(dragPreview);  

    return dragPreview;
}

function setSummaryDragPreview(event, selectedTasks) {

    const dragPreview = createDragPreviewElement([ selectedTasks[0] ]);
    
    if(selectedTasks.length > 1) {
        dragPreview.insertAdjacentHTML('beforeend', "<div class='drag-and-drop-count' >+" + (selectedTasks.length - 1) + "</div>");
    }
        
    event.dataTransfer.setDragImage(dragPreview, 0, 0);      
}

function setCompleteDragPreview(event, selectedTasks) {

    const dragPreivew = createDragPreviewElement(selectedTasks);
    event.dataTransfer.setDragImage(dragPreview, 0, 0);  
}
