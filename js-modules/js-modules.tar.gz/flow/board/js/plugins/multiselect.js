import { Plugin } from '../plugin.js'

export class MultiSelectPlugin extends Plugin {

    constructor() {
        super();

    }

    get html() {
        return "<div id='lasso' ></div>"
    }

    enable() {
        enableMultiSelect();
    }
}

function enableMultiSelect() {

    let lasso = document.getElementById('lasso');
    let isDraggingLasso = false;
    let lassoStartX = 0;
    let lassoStartY = 0;


    // Lasso ziehen nur außerhalb von Tasks
    document.addEventListener('mousedown', (event) => {

        // Überprüfe, ob der Klick auf einem Task war
        if (!event.target.closest('.task')) {
            isDraggingLasso = true;
            lassoStartX = event.pageX;
            lassoStartY = event.pageY;
            lasso.style.left = lassoStartX + 'px';
            lasso.style.top = lassoStartY + 'px';
            lasso.style.width = '0px';
            lasso.style.height = '0px';
            lasso.style.display = 'block';

            // Verhindert die Standard-Textauswahl während des Lasso-Vorgangs
            event.preventDefault();
        }
    });

    document.addEventListener('mousemove', (event) => {
        if (isDraggingLasso) {
            let currentX = event.pageX;
            let currentY = event.pageY;

            // Berechne die Breite und Höhe des Lasso-Rechtecks
            let width = Math.abs(currentX - lassoStartX);
            let height = Math.abs(currentY - lassoStartY );

            // Setze die Position und Größe des Lassos
            lasso.style.width = width + 'px';
            lasso.style.height = height + 'px';
            lasso.style.left = Math.min(currentX, lassoStartX) + 'px';
            lasso.style.top = Math.min(currentY, lassoStartY) + 'px';

            const taskElements = document.querySelectorAll(".task");
            // Überprüfe die Überschneidung mit den Tasks
            taskElements.forEach(task => {
                if (isOverlapping(lasso, task)) {
                    task.classList.add('is-selected');
                } else {
                    task.classList.remove('is-selected');
                }
            });
        }
    });

    document.addEventListener('mouseup', () => {
        if (isDraggingLasso) {
            isDraggingLasso = false;
            lasso.style.display = 'none';
        }
    });

    function isOverlapping(lasso, task) {
        const lassoRect = lasso.getBoundingClientRect();
        const taskRect = task.getBoundingClientRect();

        return !(lassoRect.right < taskRect.left ||
                 lassoRect.left > taskRect.right ||
                 lassoRect.bottom < taskRect.top ||
                 lassoRect.top > taskRect.bottom);
    }

}

