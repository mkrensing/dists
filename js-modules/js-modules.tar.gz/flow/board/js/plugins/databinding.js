import { Plugin } from '../plugin.js'

export class DataBindingPlugin extends Plugin {

    constructor() {
        super();
        this.columnConfigs = [];
        this.areaConfigs = [];
        this.defaultAreaName = "default";
    }

    setDefaultAreaName(defaultAreaName) {
        this.defaultAreaName = defaultAreaName
    }

    enable() {
        
    }

    configureColumn(config) {
        this.columnConfigs.push(config);
    }

    configureArea(config) {
        this.areaConfigs.push(config);
    }

    getColumnConfigs() {
        return this.columnConfigs;
    }

    getAreaConfigs() {
        return this.areaConfigs;
    }

    bind(tasks) {
        let tasksPerColumn = createTasksPerColumn(this.columnConfigs, tasks);

        // add issues as tasks
        this.columnConfigs.forEach(columnConfig => {

            const columnTasks = tasksPerColumn[columnConfig.id] || [];
            let columnFilters = createColumnFilter(columnConfig.condition || {});
            columnTasks.forEach(task => {
                verifyTaskStateForColumn(task, columnFilters);
                const missingProperties = getNotMatchingColumnFilters(task, columnFilters);
                if(missingProperties.length > 0) {
                    console.log("Task ", task, " has illegal state. Missing", missingProperties);
                }
                
                const areaName = this.findAreaForTask(task)
                this.triggerEvent("taskCreated", { columnId: columnConfig.id, areaName: areaName }, task);
            });
        });
    }

    findAreaForTask(task) {
        const areaName = this.areaConfigs.find(areaConfig => {
            const areaFilters = createColumnFilter(areaConfig.condition || {});
            return areaFilters && isFilteredByColumnFilter(task, areaFilters)
        })?.id;

        return areaName || this.defaultAreaName;
    }
    
}

function createTasksPerColumn(columns, tasks) {

    let tasksPerColumn = {};

    tasks.forEach((task, index) => {

        let column = findColumnForTask(columns, task);
        if(column) {
            tasksPerColumn[column.id] = (tasksPerColumn[column.id] || []);
            tasksPerColumn[column.id].push(task);
        }
    });

    return tasksPerColumn;
}


function findColumnForTask(columns, task) {

    const columnsWithIndex = columns.map((column, index) => ({ ...column, index: index}));

    //console.log("findColumnForIssue", task);

    const matchingColumns = columnsWithIndex.filter(column => column.condition).map(column => {
        let columnFilters = createColumnFilter(column.condition);
        return { ...column, matches: getMatchingColumnFilters(task, columnFilters).length, notMatches: getNotMatchingColumnFilters(task, columnFilters) }
    }).filter(column => {
        return column.matches > 0 && column.notMatches == 0
    });

    const bestMatchCount = matchingColumns.reduce((acc, column) => Math.max(acc, column.matches), 0);
    const bestMachingColumns = matchingColumns.filter(column => column.matches == bestMatchCount);

    //console.log("findColumnForIssue.matchingColumns", issue.key, matchingColumns);
    //console.log("findColumnForIssue.bestMachingColumns", issue.key, bestMatchCount, bestMachingColumns);

    if(bestMachingColumns.length == 0) {
        console.log("No matching column found for task", task);
        return null;
    }

    if(bestMachingColumns.length == 1) {
        return bestMachingColumns[0];
    }

    let directlyAssignedColumn = bestMachingColumns.find(column => isDirectlyAssignedToColumn(task, column));
    //console.log("directlyAssignedColumn", issue.key, directlyAssignedColumn, issue);
    if(directlyAssignedColumn) {
        return directlyAssignedColumn;
    }

    const autobindingColumns = bestMachingColumns.filter(column => column.autobinding);
    if(autobindingColumns.length == 0) {
        console.log("No matching column found for task", task);
        return null;
    }

    //console.log("findColumnForIssue.autobindingColumns", issue.key, autobindingColumns);

    return autobindingColumns.at(-1);
}


function verifyTaskStateForColumn(task, columnFilters) {

    let legalState = (columnFilters.length == 0 || isFilteredByColumnFilter(task, columnFilters));
    if(! legalState) {
        console.log("Issue in illegal state", task, columnFilters);
    }
    let updateRequired = (task.legalState != legalState);
    task.legalState = legalState;
    task.illegalState = !legalState;

    return updateRequired;
}


function createColumnFilter(filterConfiguration) {

    return Object.keys(filterConfiguration).map(key => {
        return { "name": key, "value": filterConfiguration[key] }
    });
}

function isDirectlyAssignedToColumn(issue, column) {
    return (issue.columnAssigment?.newPosition?.columnId || "") == column.id
}


function isFilteredByColumnFilter(taskContent, columnFilters) {
    return columnFilters.length > 0 && columnFilters.every(columnFilter => matchesFilter(taskContent, columnFilter));
}

function getMatchingColumnFilters(taskContent, columnFilters) {
    return columnFilters.filter(columnFilter => matchesFilter(taskContent, columnFilter));
}

function getNotMatchingColumnFilters(taskContent, columnFilters) {
    return columnFilters.filter(columnFilter => !matchesFilter(taskContent, columnFilter));
}

function matchesFilter(taskContent, columnFilter) {
    let taskValue = taskContent[columnFilter.name] || "";

    // Extrahiert den Aktionswert, falls vorhanden
    if (columnFilter.value.condition && columnFilter.value.description) {
        columnFilter.value = columnFilter.value.condition;
    }

    if (typeof columnFilter.value === 'function') {
        return columnFilter.value(taskValue, taskContent, columnFilter);
    } else if (Array.isArray(columnFilter.value)) {
        return columnFilter.value.some(value => valueMatches(value, taskValue));
    } else {
        return valueMatches(columnFilter.value, taskValue);
    }
}


function valueMatches(columnFilterValue, issueValue) {
    if (Array.isArray(issueValue)) {
        return issueValue.some(value => value == columnFilterValue);
    } else {
        return issueValue == columnFilterValue;
    }
}
