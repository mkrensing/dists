import { Plugin } from '../plugin.js'

export class ZoomPlugin extends Plugin {

    constructor() {
        super();

    }

    enable() {
        enableZoomDetection(this);
    }
}


function enableZoomDetection(context) {
    let lastDevicePixelRatio = window.devicePixelRatio;
    window.addEventListener('resize', function() {

        if (window.devicePixelRatio !== lastDevicePixelRatio) {
            lastDevicePixelRatio = window.devicePixelRatio;
            context.triggerEvent('zoomed');
        }
    });        
}