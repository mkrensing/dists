import { Plugin } from '../plugin.js'

class NotificationCenter {

    constructor() {
        if (NotificationCenter.instance) {
            return NotificationCenter.instance;
        }

        this.notifications = [];
        this.pendingActions = [];
        this.timeoutID = null;
        this.errorExists = false;  // Tracks if any notification has an message
        this.errorMessageConverter = function(message) { return message };
        NotificationCenter.instance = this;
        this.enabled = false;
    }

    enable() {

        // Close button functionality
        document.getElementById('notification-close-button').addEventListener('click', () => {
            this.hideNotifications();
        });

        // Error OK button functionality
        document.getElementById('messagebox-ok-button').addEventListener('click', () => {
            this.hideMessagebox();
        });

        this.hideNotifications();
        this.hideMessagebox();
        this.enabled = true;
    }

    setErrorMessageConverter(errorMessageConverter) {
        this.errorMessageConverter = errorMessageConverter;
    }

    // Method to show the overlay
    show() {
        if(! this.enabled) {
            // console.log("Notifications are disabled. Please enable the NotificationPlugin");
            return
        }

        this.updateNotificationList();
        this.showNotifications();

        // Only close automatically if no message exists and all notifications are completed
        if (this.timeoutID) {
            clearTimeout(this.timeoutID);
        }
        if (!this.errorExists && this.pendingActions.every(action => action.completed)) {
            this.timeoutID = setTimeout(() => {
                this.hideNotifications();
            }, 1500);
        }

        this.removeCompletedNotificationsIfOverflow();
    }


    createProxy(callback, description) {

        if(! description) {
            throw new Error("Missing description argument. description is null");
        }

        if(! callback) {
            throw new Error("Missing callback argument. callback is null for task " + description);
        }

        return (...args) => {

            return new Promise((resolve, reject) => {
                const promise = callback(...args);
                if(promise) {
                    const notificationId = this.addNotification({ description: description });
                    promise.then(result => {
                        this.completeNotification(notificationId);
                        resolve(result);
                    }).catch(error => {
                        this.completeNotification(notificationId, this.errorMessageConverter(error));
                        reject(error);
                    })
                } else {
                    console.log("PromiseFactory return null instead of promise", description);
                    resolve(...args);
                }

            });
        }
    }

 

    // Method to add a notification
    addNotification(config) {
        config.id = config.id || generateUniqueId();
        this.pendingActions.push({ id: config.id, description: config.description, completed: false, message: false, errorMessage: '' });
        this.show();

        return config.id;
    }

    // Method to complete a notification
    completeNotification(notificationId, errorMessage) {
        const notification = this.pendingActions.find(action => action.id === notificationId);
        if (notification) {
            notification.completed = true;

            if (errorMessage) {
                notification.errorMessage = errorMessage;
                notification.message = true;

                this.errorExists = true;
                this.showCloseButton();  // Show Close button when an message occurs
            }
        }
        this.show();
    }

    // Private method to update the notification list in the DOM
    updateNotificationList() {
        
        const notificationList = document.getElementById('notification-list');
        notificationList.innerHTML = '';  // Clear current notification list

        [ ...this.pendingActions ].reverse().forEach(action => {
            const listItem = document.createElement('li');

            // Create icon column (first column)
            const icon = document.createElement('span');
            icon.classList.add('icon');
            if (action.message) {
                icon.textContent = '⚠';
                icon.classList.add('error');
                icon.addEventListener('click', () => {
                    this.showMessagebox(action.errorMessage);
                });
            } else if (action.completed) {
                icon.textContent = '✔';
                icon.classList.add('checkmark');
            } else {
                icon.textContent = '⚙';
                icon.classList.add('gear');
            }

            // Create notification description (second column)
            const description = document.createElement('span');
            description.textContent = action.description;
            description.classList.add('notification-status');

            // Append icon and description to the list item
            listItem.appendChild(icon);
            listItem.appendChild(description);

            notificationList.appendChild(listItem);
        });
    }

    // Private method to show the overlay
    showNotifications() {
        const overlay = document.getElementById('notification-overlay');
        overlay.style.display = 'block';
    }

    // Private method to hide the overlay
    hideNotifications() {
        const overlay = document.getElementById('notification-overlay');
        overlay.style.display = 'none';
        this.errorExists = false;
        this.hideCloseButton();
    }

    // Show Close button
    showCloseButton() {
        const closeButton = document.getElementById('notification-close-button');
        closeButton.style.display = 'block';
    }

    hideCloseButton() {
        const closeButton = document.getElementById('notification-close-button');
        closeButton.style.display = 'none';
    }

    // Show message overlay
    showMessagebox(message) {
        const messageboxOverlay = document.getElementById('messagebox-overlay');
        const messageboxMessageElement = document.getElementById('messagebox-message');
        messageboxMessageElement.textContent = message
        messageboxOverlay.style.display = 'flex';
    }

    // Hide message overlay
    hideMessagebox() {
        const messageOverlay = document.getElementById('messagebox-overlay');
        messageOverlay.style.display = 'none';
    }

    // Remove completed notifications if number of notifications exceeds threshold
    removeCompletedNotificationsIfOverflow() {
        const threshold = 5;
        if (this.pendingActions.length > threshold) {
            this.pendingActions = this.pendingActions.filter(action => !action.completed || action.message);
            setTimeout(() => {
                this.updateNotificationList();
            }, 1500);
        }
    }

    clear() {
        if(! this.errorExists) {
            this.pendingActions = [];
        }
    }
}

function generateUniqueId() {
    return `id-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

const notificationCenter = new NotificationCenter();
// Object.freeze(notificationCenter);
export { notificationCenter as NotificationCenter };


export class NotificationPlugin extends Plugin {

    constructor() {
        super();
    }

    get html() {
        return `
            <div id="notification-plugin" >
                <div id="notification-overlay" class="notification-overlay">
                    <button id="notification-close-button" class="close-btn">&times;</button>
                    <ul id="notification-list"></ul>
                </div>

                <div id="messagebox-overlay" class="messagebox-overlay">
                    <div class="messagebox">
                        <p id="messagebox-message"></p>
                        <button id="messagebox-ok-button" class="ok-btn">OK</button>
                    </div>
                </div>
            </div>
        `
    }

    enable() {
        notificationCenter.enable();
    }
}


