import {addLabel, removeLabel, setAssignee, changeStatus, addFixVersion } from './transitions.js'

export function createBindingMap(bindingContext) {
    return {
        labels: { enter: addLabels, leave: removeLabels },
        status: { enter: resolveBindingContext(changeStatus, "status") },
        assignee: { enter: resolveBindingContext(setAssignee, (rule => rule?.assignee?.value)) },
        fixVersions: { enter: addFixVersion },
    }
}

function resolveBindingContext(callback, fieldNameOrLookupFieldCallback) {

    return function(bindingContext) {

        function lookupFieldValue(column, areaName) {
            if(typeof fieldNameOrLookupFieldCallback == "function") {
                const bindingCondition = bindingContext(column, areaName)?.condition || {};
                return fieldNameOrLookupFieldCallback(bindingCondition)
            }
            return bindingContext(column, areaName)?.condition[fieldNameOrLookupFieldCallback]
        }
    
        return {
            transition: function(task, column, areaName) {
                const fieldValue = lookupFieldValue(column, areaName)
                return callback(fieldValue).transition(task, column, areaName);
            },
            description: function(task, column, areaName) {
                const fieldValue = lookupFieldValue(column, areaName)
                return callback(fieldValue).description(task, column, areaName);
            }
        }
    }

}

function addLabels(bindingContext) {
    return {
        transition: function(task, column, areaName) {
            const labels = bindingContext(column, areaName)?.condition?.labels || []
            const promiseCallbacks = labels.map(label => {
                return addLabel(label).transition(task, column, areaName)
            });
            return promiseCallbacks;
        },
        description: function(task, column, areaName) {
            const labels = bindingContext(column, areaName)?.condition?.labels || []
            const descriptions = labels.map(label => {
                return addLabel(label).description(task, column, areaName)
            });
            return descriptions
        }
    }
}

function removeLabels(bindingContext) {
    return {
        transition: function(task, column, areaName) {
            const labels = bindingContext(column, areaName)?.condition?.labels || []
            const promiseCallbacks = labels.map(label => {
                return removeLabel(label).transition(task, column, areaName)
            });
            return promiseCallbacks;
        },
        description: function(task, column, areaName) {
            const labels = bindingContext(column, areaName)?.condition?.labels || []
            const descriptions =  labels.map(label => {
                return removeLabel(label).description(task, column, areaName)
            });
            return descriptions
        }
    }
}

function addFixVersions(bindingContext) {
    return {
        transition: function(task, column, areaName) {
            const versions = bindingContext(column, areaName)?.condition?.fixVersions || []
            const promiseCallbacks = versions.map(version => {
                return addFixVersion(version).transition(task, column, areaName)
            });
            return promiseCallbacks;
        },
        description: function(task, column, areaName) {
            const versions = bindingContext(column, areaName)?.condition?.labels || []
            const descriptions =  versions.map(version => {
                return addFixVersion(version).description(task, column, areaName)
            });
            return descriptions
        }
    }
}