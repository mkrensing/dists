import {default as jira} from 'jira'

const issueUpdater = new jira.IssueUpdater();
issueUpdater.setFieldMapping([ "rank|customfield_10005", "project", "assignee", "status", "summary", "labels|customfield_10036", "fixVersions" ] )

export function setFieldMapping(fieldMappings) {
    issueUpdater.setFieldMapping(fieldMappings);
}

export function changeStatus(targetStatusName) {

    return {
        transition: function(task, column, areaName) {
            if(task.content.status != targetStatusName) {
                return function(task) {
                    const issue = task.content;
                    return new Promise((resolve, reject) => {
                        issueUpdater.changeStatus({ projectId: issue.project.key, ...issue} , targetStatusName).then(updatedIssue => {
                            setStatusId(updatedIssue)
                            resolve({ ...task, content: updatedIssue });
                        }).catch(reject)
                    });
                }
            }
        },
        description: function(task, column, areaName) {
            return `[${task.content.key}] Set status to ${targetStatusName}`
        }
    }
}

function setStatusId(issue) {
    issue.status_id = (issue.status || "").replaceAll(" ", "_").toUpperCase()
}


export function addLabel(labelOrCallbackArgument) {

    const labelOrCallback = ensureCallback(labelOrCallbackArgument);

    return {
        transition: function(task, column, areaName) {
            const label = labelOrCallback(task, column, areaName)
            return function(task) {
                const issue = task.content;
                return new Promise((resolve, reject) => {
                    issueUpdater.changeFields(issue, { labels: [{ add: label }]}).then(updatedIssue => {
                        resolve({ ...task, content: updatedIssue });
                    }).catch(reject);
                });
            }
        },
        description: function(task, column, areaName) {
            const label = labelOrCallback(task, column, areaName)
            return `[${task.content.key}] Add label ${label}`
        }
    }
}

export function addFixVersion(versionOrCallbackArgument) {

    const versionOrCallback = ensureCallback(versionOrCallbackArgument);

    return {
        transition: function(task, column, areaName) {
            const version = versionOrCallback(task, column, areaName)
            return function(task) {
                const issue = task.content;
                return new Promise((resolve, reject) => {
                    issueUpdater.changeFields(issue, { fixVersions: [{ add: version }]}).then(updatedIssue => {
                        resolve({ ...task, content: updatedIssue });
                    }).catch(reject);
                });
            }
        },
        description: function(task, column, areaName) {
            const version = labelOrCallback(task, column, areaName)
            return `[${task.content.key}] Add FixVersion ${version}`
        }
    }
}

function ensureCallback(argumentOrCallback) {

    if(typeof argumentOrCallback != "function") {
        return function(task, column, areaName) { return argumentOrCallback }
    }

    return argumentOrCallback;
}

export function removeLabel(labelOrCallbackArgument) {

    const labelOrCallback = ensureCallback(labelOrCallbackArgument);

    return {
        transition: function(task, column, areaName) {
            const label = labelOrCallback(task, column, areaName)
            console.log("label after lookup", label)
            return function(task) {
                const issue = task.content;
                return new Promise((resolve, reject) => {
                    issueUpdater.changeFields(issue, { labels: [{ remove: label }]}).then(updatedIssue => {
                        resolve({ ...task, content: updatedIssue });
                    }).catch(reject);
                });
            }
        },
        description: function(task, column, areaName) {
            const label = labelOrCallback(task, column, areaName)
            return `[${task.content.key}] Remove label ${label}`
        }
    }
}

export function setAssignee(username) {

    return {
        transition: function(task, column, areaName) {
            return function(task) {
                const issue = task.content;
                return new Promise((resolve, reject) => {
                    issueUpdater.changeAssignee(issue, username).then(updatedIssue => {
                        resolve({ ...task, content: updatedIssue });
                    }).catch(reject);
                });
            }
        },
        description: function(task, column, areaName) {
            return `[${task.content.key}] Assign task to ${username}`
        }
    }
}

export function removeAssignee(username) {

    return {
        transition: function(task, column, areaName) {
            return function(task) {
                const issue = task.content;
                if(! username || issue?.assignee?.assignee == username) {
                    return new Promise((resolve, reject) => {
                        issueUpdater.changeAssignee(issue, "").then(updatedIssue => {
                            resolve({ ...task, content: updatedIssue });
                        }).catch(reject);
                    });
                }
            }
        },
        description: function(task, column, areaName) {
            return `[${task.content.key}] Remove assignee ${(username || "")}`
        }
    }
}

