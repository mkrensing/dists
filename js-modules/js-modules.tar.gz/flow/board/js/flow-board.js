import { Column } from './column.js';

import { NotificationPlugin } from './plugins/notifications.js';
import { ZoomPlugin } from './plugins/zoom.js';
import { DragAndDropPlugin } from './plugins/dragdrop.js';
import { ScrollingPlugin } from './plugins/scroll.js';
import { MultiSelectPlugin } from './plugins/multiselect.js';

import { sequence, parallel } from 'promise-util';

export class FlowBoard {

    constructor(targetSelector, config) {
        this.targetSelector = targetSelector;
        this.targetElement = document.querySelector(targetSelector);
        this.columns = [];
        this.areasIndex = {};
        this.taskMovedCallbacks = [];
        this.renderedCallbacks = [];
        this.zoomCallbacks = [];
        this.transitionErrorCallbacks = [];
        this.tasks = [];
        this.taskIndex = {};
        this.synchronizedAreaSelectors = [];
        this.beforeRenderingCallbacks = [];
        this.columnTemplate = this.getDefaultColumnTemplate;
        this.taskTemplate = this.getDefaultTaskTemplate;

        this.shiftPressed = false;
        this.completeDragAndDropPreview = false;
        this.actionsUpdater = null;

        config = this.mergeConfig(config || {}, { multiselect: true, scrolling: true, zoom: true, dragDrop: true, notifications: true })
        this.plugins = [];
        this.loadPlugins(config);
    }

    mergeConfig(config, defaultConfig) {
        for(let key in defaultConfig) {
            if(config[key] == undefined) {
                config[key] = defaultConfig[key]
            }
        }
        return config;
    }

    loadPlugins(config) {

        if(config.multiselect) {
            this.addPlugin(new MultiSelectPlugin())
        }

        if(config.scrolling) {
            this.addPlugin(new ScrollingPlugin())
        }        

        if(config.zoom) {
            this.addPlugin(new ZoomPlugin())
        }

        if(config.dragDrop) {
            this.addPlugin(new DragAndDropPlugin(config.dragDrop))
        }

        if(config.notifications) {
            this.addPlugin(new NotificationPlugin())
        }

    }

    addPlugin(plugin) {

        plugin.onEvent("taskCreated", (position, taskContent) => {
            this.addTask(position, taskContent);
        });

        plugin.onEvent("zoomed", () => {
            this.synchronizeAreas();
            this.zoomCallbacks.forEach(callback => {
                callback();
            })
        })

        plugin.onEvent("taskMoved", ({ taskElements, previousTaskElement, nextTaskElement ,columnId, areaName }) => {
            
            const movedTasksBeforeActions = taskElements.map(taskElement => {

                const task = this.taskIndex[taskElement.id];
                
                task.originalPosition = { ...task.position };
                task.position = { columnId: columnId, areaName: areaName };
                
                return task;
            });    


            this.triggerLeaveAndEnterActions(movedTasksBeforeActions).then(results => {

                // console.log("triggerLeaveAndEnterActions fine :-)", results);

            }).catch(errors => {
                
                this.transitionErrorCallbacks.forEach(callback => callback(errors));

            }).then(() => {
                
                const movedTasks = taskElements.map(taskElement => this.taskIndex[taskElement.id]);
    
                
                const previousTask = previousTaskElement ? this.getTaskById(previousTaskElement.id) : null;
                const nextTask = nextTaskElement ? this.getTaskById(nextTaskElement.id) : null;
                const column = this.getColumnById(columnId);

                this.taskMovedCallbacks.forEach(taskMovedCallback => {
                    taskMovedCallback({ previousTask: previousTask, nextTask: nextTask, column: column, areaName: areaName, tasks: movedTasks });
                });
            })

            this.synchronizeAreas();
            this.triggerOnRenderEvents("taskMoved");

        })        

        this.plugins.push(plugin);
    }

    setColumnTemplate(columnTemplateCallback) {
        this.columnTemplate = columnTemplateCallback;
    }

    setTaskTemplate(taskTemplateCallback) {
        this.taskTemplate = taskTemplateCallback;
    }

    getColumnById(columnId) {
        return this.columns.find(column => column.id == columnId);
    }

    addColumns(columns) {
        columns.forEach(column => {
            this.addColumn(column)
        });
    }

    addColumn(columnConfig) {
        this.columns.push(new Column(columnConfig));
    }


    addTask(position, taskContent) {
        position = position || { columnId: "mycolumn", areaName: "areaA" } && {}

        const task = { id: generateUniqueId(), position: position, content: taskContent };

        this.taskIndex[task.id] = task;
        this.tasks.push(task);
    }

    moveTask(position, task) {
        position = position || { columnId: "mycolumn", areaName: "areaA", index: 5, nextTaskId: "next-task-id", previousTaskid: "previous-task-id" } && {}
        task.position = position

        this.updateTask(task);
        this.removeTask(task);
        this.renderTask(task);
        this.repaintTasks([ task ]);
    }

    updateTask(updatedTask) {


        if(! updatedTask.id) {
            throw new Error("Missing task.id");
        }
        if(! this.taskIndex[updatedTask.id]) {
            console.error("updateTask: Task not found", updatedTask);
            throw new Error("Task not found on board. Missing task with id: " + updatedTask.id);
        }

        this.taskIndex[updatedTask.id] = updatedTask;
        const taskIndex = this.tasks.findIndex(task => task.id == updatedTask.id);
        if(taskIndex !== -1) {
            this.tasks[taskIndex] = updatedTask;
        } else {
            console.log("No Task found with id", updatedTask.id);
        }
    }

    findTasks(columnFilter) {

        columnFilter = columnFilter || function(column) { return true };
        return this.columns.filter(column => columnFilter(column)).flatMap(column => {
            return this.tasks.filter(task => task.position.columnId == column.id)
        });
    }

    getTaskById(taskId) {
        return this.taskIndex[taskId];
    }

    addSynchronizedArea(areaSelector) {
        this.synchronizedAreaSelectors.push(areaSelector);
    }

    addBeforeRendering(callback) {
        this.beforeRenderingCallbacks.push(callback);
    }

    onTaskMoved(callback) {
        this.taskMovedCallbacks.push(callback);
    }

    onRender(callback) {
        this.renderedCallbacks.push(callback);
    }

    onEnterColumn(callback, columnFilter) {
        columnFilter = columnFilter || function(column) { return true };
        this.columns.filter(columnFilter).forEach(column => {
            column.onEnterColumn(callback);
        });
    }

    onLeaveColumn(callback, columnFilter) {
        columnFilter = columnFilter || function(column) { return true };
        this.columns.filter(columnFilter).forEach(column => {
            column.onLeaveColumn(callback);
        });
    }    

    onEnterArea(callback) {
        this.columns.forEach(column => {
            column.onEnterArea(callback);
        });
    }

    onLeaveArea(callback) {
        this.columns.forEach(column => {
            column.onLeaveArea(callback);
        });
    }      

    onColumnTransition(transitionConfig) {

        if(! transitionConfig.id) {
            throw new Error("Missing id property for columnId. Args: " + transitionConfig);
        }

        if(transitionConfig.enter) {
            this.onEnterColumn(transitionConfig.enter,  column => column.id == transitionConfig.id)
        }
        
        if(transitionConfig.leave) {
            this.onLeaveColumn(transitionConfig.leave,  column => column.id == transitionConfig.id)
        }
    }    

    onAreaTransition(transitionConfig) {

        if(! transitionConfig.id) {
            throw new Error("Missing id property for areaId. Args: " + transitionConfig);
        }

        if(transitionConfig.enter) {
            this.onEnterArea(transitionConfig.enter)
        }
        
        if(transitionConfig.leave) {
            this.onLeaveArea(transitionConfig.leave)
        }
    }    


    onTransitionErrors(callback) {
        this.transitionErrorCallbacks.push(callback);
    }

    render() {
        this.renderBoard();
        this.renderTasks();
        this.enableAllPlugins();
        this.triggerBeforeRenderingCallbacks();
        this.synchronizeAreas();
        this.triggerOnRenderEvents("init");
    }


    renderBoard() {

        let html = this.getBoardTemplate(this.columns);
        this.plugins.forEach(plugin => {
            html += plugin.html;
        });

        this.targetElement.innerHTML = html;
    }

    renderTasks() {
        this.findTasks().forEach(task => {
            this.renderTask(task);
        });
    }

    enableAllPlugins() {
        this.plugins.forEach(plugin => {
            plugin.targetElement = this.targetElement;
            plugin.enable();
        })
    }

    removeTask(task) {
        const taskElement = document.getElementById(task.id);
        if(taskElement) {
            taskElement.remove();
        }
    }

    renderTask(task) {

        if(task.position.previousTaskId) {
            const previousTaskSelector = `.columns #${task.position.columnId} .area.${task.position.areaName} .task#${task.position.previousTaskId}`
            const previousTask = this.targetElement.querySelector(previousTaskSelector);
            if(! previousTask) {
                throw new Error(`Task not found with id ${task.position.previousTaskId} in column ${task.position.columnId} and area ${task.position.areaName} `);
            }
            this.insertTaskAfter(task, previousTask);
            return
        }

        if(task.position.nextTaskId) {
            const nextTaskSelector = `.columns #${task.position.columnId} .area.${task.position.areaName} .task#${task.position.nextTaskId}`
            const nextTask = this.targetElement.querySelector(nextTaskSelector);
            if(! nextTask) {
                throw new Error(`Task not found with id ${task.position.nextTaskId} in column ${task.position.columnId} and area ${task.position.areaName} `);
            }
            this.insertTaskBefore(task, nextTask);
            return
        }        

        if(task.position.index != undefined) {
            this.insertTaskAtPosition(task);
            return
        }

        this.insertTaskAtEnd(task);
    }

    insertTaskAtPosition(task) {

        const tasksElementsSelector = `.columns #${task.position.columnId} .area.${task.position.areaName} .task`
        const taskElements = this.targetElement.querySelectorAll(tasksElementsSelector)
        
        if(task.position.index < 0) {
            task.position.index = Math.max(0, taskElements.length + task.position.index);
        }

        if(taskElements.length == 0 || task.position.index <= 0) {
            this.insertTaskAtFirstPosition(task);
            return;
        } 

        if(task.position.index >= taskElements.length) {
            this.insertTaskAtEnd(task);
            return
        }

        this.insertTaskBefore(task, taskElements[task.position.index])
        
    }

    insertTaskAfter(task, referenceTaskElement) {
        referenceTaskElement.insertAdjacentHTML('afterend', this.taskTemplate(task));
    }


    insertTaskBefore(task, referenceTaskElement) {
        referenceTaskElement.insertAdjacentHTML('beforebegin', this.taskTemplate(task));
    }


    insertTaskAtFirstPosition(task) {

        const areaSelector = `.columns #${task.position.columnId} .area.${task.position.areaName} `
        const areaElement = this.targetElement.querySelector(areaSelector)
        if(! areaElement) {
            throw new Error(`No area-element found for column ${task.position.columnId} and area ${task.position.areaName}`);
        }
        areaElement.insertAdjacentHTML('afterbegin', this.taskTemplate(task));
    }

    insertTaskAtEnd(task) {

        const areaSelector = `.columns #${task.position.columnId} .area.${task.position.areaName} `
        const areaElement = this.targetElement.querySelector(areaSelector)
        if(! areaElement) {
            throw new Error(`No area-element found for column ${task.position.columnId} and area ${task.position.areaName}`);
        }
        areaElement.insertAdjacentHTML('beforeend', this.taskTemplate(task));
    }


    repaintTasks(tasks) {
        tasks = tasks || this.findTasks();
    
        // Array mit Task-Elementen erstellen
        const taskElements = tasks
            .map(task => ({ task: task, element: document.getElementById(task.id) }))
            .filter(({ task, element }) => {
                if (element) {
                    element.outerHTML = this.taskTemplate(task);
                    return true;
                } else {
                    console.error("Task not found on board", task);
                    return false;
                }
            }).map(({ task, element }) => document.getElementById(task.id));
        
        this.plugins.forEach(plugin => {
            plugin.repaintTasks(taskElements);
        })
    }

    synchronizeAreas() {
        
        this.synchronizedAreaSelectors.forEach(areaSelector => {
            
            const areas = this.targetElement.querySelectorAll(areaSelector);
            this.synchronizeElements(areas);
        });
    }

    synchronizeElements(nodeListElements) {

        const elements = [...nodeListElements ];

        // remove the max height from all areas
        elements.forEach(element => {
            element.style.height = "auto";
        });

        // Determine the max height
        let maxHeight = elements.reduce((max, lane) => {
            return Math.max(max, lane.scrollHeight);
        }, 0);

        // Set the max height to all fast-lane areas
        elements.forEach(lane => {
            lane.style.height = `${maxHeight}px`;
        });
    }

    triggerBeforeRenderingCallbacks() {
        this.beforeRenderingCallbacks.forEach(callback => {
            callback(this);
        });
    }

    triggerOnRenderEvents(eventName) {
        this.renderedCallbacks.forEach(callback => {
            callback(this, eventName);
        });
    }

    triggerLeaveAndEnterActions(droppedTasks) {

        const transitions = droppedTasks.filter(task => {
            return task.originalPosition.columnId != task.position.columnId || task.originalPosition.areaName != task.position.areaName
        }).map(task => {
            const originalColumn = this.getColumnById(task.originalPosition.columnId);
            const targetColumn = this.getColumnById(task.position.columnId);
            
            const transitions = [];
            if(task.originalPosition.columnId != task.position.columnId) {
                transitions.push(() => originalColumn.leaveColumn(task, task.originalPosition.areaName));
                transitions.push(() => targetColumn.enterColumn(task, task.position.areaName));
            }

            if(task.originalPosition.areaName != task.position.areaName) {
                console.log("changing area from ", task.originalPosition.areaName, "to", task.position.areaName)
                transitions.push(() => originalColumn.leaveArea(task, task.originalPosition.areaName));
                transitions.push(() => targetColumn.enterArea(task, task.position.areaName));
            }

            return transitions;
        });

        return parallel(transitions.map(leaveAndEnter => {
            return sequence(leaveAndEnter)
        }));
    }

    getColumnElement(columnId) {
        return this.targetElement.querySelector('.columns .column#' + columnId);
    }

    getBoardTemplate(columns) {
        const columnDivs = columns.map(column => this.columnTemplate(column)).join('\n');
    
        return `
    <div class="flowBoard">
        <div class="columns">
        ${columnDivs}
        </div>
    </div>
    `
    }
   
    
    getDefaultColumnTemplate(column) {

        const areaDivs = column.areas.map(area => {
            return `<div class="area ${area.name} ${(area.classNames || []).join(" ")}" >
                <span class="areaLabel" ></span>
                <span class="header" >${area.header || ""}</span>
            </div>`
        }).join('\n');

        return `
            <div class="column ${column.group || ""}" id="${column.id}">
            <div class="header" >
                <div class="title">${column.name}</div>
                <div class="subtitle"></div>
            </div>
            ${areaDivs}
            </div>`
    }

    getDefaultTaskTemplate(task) {
        return `
        <div class="task ${(task.content.classNames || []).join(" ")}" draggable="true" id="${task.id}" >
            <div class="header">${task.content.header}</div>
            <div class="text" >${task.content.text}</div>
        </div>`
    }
}

function generateUniqueId() {
    return `id-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}
