import { FlowBoard } from './flow-board.js';
import { NotificationCenter } from './plugins/notifications.js';
import { DataBindingPlugin } from './plugins/databinding.js';
export { NotificationCenter  }

export class KanbanBoard extends FlowBoard {

    constructor(targetElement, config) {
        super(targetElement, config);
        this.databinding = new DataBindingPlugin();
        this.addPlugin(this.databinding);
        NotificationCenter.setErrorMessageConverter((error) => {
            if(error.text) {
                try {
                    const errorResponse = JSON.parse(error.text);
                    return errorResponse.error || ("" + error.text);

                } catch(e) {
                    return "" + error.text;
                }
            }

            return "" + error;
        });

        this.onRender((board, command) => {
            if(command == "init") {
                this.setColumnConditionDescriptions()
                this.syncColumnConditionDescriptionHeight()
            }
        });
        this.onRender(() => {
            this.updateWIP.apply(this)
        });
    }

    addColumnBinding(columnBindingConfig) {
        this.databinding.configureColumn(columnBindingConfig);
    }

    addAreaBinding(areaBindingConfig) {
        this.databinding.configureArea(areaBindingConfig);
    }

    render(tasks) {
        this.attachBindingConfigurations();
        this.databinding.bind(tasks || []);
        super.render();
    }

    attachBindingConfigurations() {
        this.attachColumnBindingConfigurationToColumns();
        this.attachAreaBindingConfigurationToColumns();
    }

    attachColumnBindingConfigurationToColumns() {
        const bindingConfigurations = this.databinding.getColumnConfigs();
        this.columns.forEach(column => {
            const bindingConfiguration = bindingConfigurations.find(columnConfig => columnConfig.id == column.id);
            if(bindingConfiguration) {
                column.tag.binding = column.tag.binding || {}
                column.tag.binding.column = bindingConfiguration;
            }
        });
    }

    attachAreaBindingConfigurationToColumns() {
        const bindingConfigurations = this.databinding.getAreaConfigs();
        this.columns.forEach(column => {
            column.tag.binding = column.tag.binding || {}
            column.tag.binding.areas = {}
            column.areas.forEach(area => {
                column.tag.binding.areas[area.name] = bindingConfigurations.find(areaConfig => areaConfig.id == area.name) || {};
            });
            
        });
    }


    autoBindingConditionsToTransitions(autobindingMap) {
        this.autoBindingColumnConditionsToTransitions(autobindingMap || {});
        this.autoBindingAreaConditionsToTransitions(autobindingMap || {});
    }

    autoBindingColumnConditionsToTransitions(autobindingMap) {
        const columnBindings = this.databinding.getColumnConfigs();
    
        columnBindings.forEach(columnConfig => {
            const columId = columnConfig.id;
            const conditions = columnConfig.condition;
            for(let propertyName in conditions) {
                if(autobindingMap[propertyName]) {
                    this.onColumnTransition({ id: columId, ...transformAutoBindingMap(autobindingMap[propertyName], columnBindingContext()) })
    
                } else {
                    const condition = conditions[propertyName];
                    if(condition.transition) {
                        this.onColumnTransition({ id: columId, ...condition.transition })
                    } else {
                        console.log("Column: Autobinding not found for propertyName ", propertyName, "and condition", condition);
                    }
                }
            }
        })
    }

    autoBindingAreaConditionsToTransitions(autobindingMap) {
        const areaBindings = this.databinding.getAreaConfigs();

        areaBindings.forEach(areaConfig => {
            const areaId = areaConfig.id;
            const conditions = areaConfig.condition;
            for(let propertyName in conditions) {
                if(autobindingMap[propertyName]) {
                    this.onAreaTransition({ id: areaId, ...transformAutoBindingMap(autobindingMap[propertyName], areaBindingContext()) })
    
                } else {
                    const condition = conditions[propertyName];
                    if(condition.transition) {
                        console.log("onAreaTransition", { id: areaId, ...condition.transition })
                        this.onAreaTransition({ id: areaId, ...condition.transition })
                    } else {
                        console.log("Area: Autobinding not found for propertyName ", propertyName, "and condition", condition);
                    }
                }
            }
        })
    }
        
    

    setColumnConditionDescriptions() {
        const columnConfigs = this.databinding.getColumnConfigs();
        columnConfigs.forEach(columConfig => {
            setColumnConditionDescription(this.targetElement, columConfig.id, convertConditionToColumnDescription(columConfig.condition));
        });
    }
    
    syncColumnConditionDescriptionHeight() {

        const conditionsSelector = ".columns .column .header .conditions";
        const allConditions = this.targetElement.querySelectorAll(conditionsSelector);
        this.synchronizeElements(allConditions);
    }

    updateWIP() {

        this.columns.forEach(column => {
            let tasks = this.findTasks(taskColumn => taskColumn.id == column.id);
    
            const wipLimit = column.tag?.wipLimit
            const text = wipLimit ? tasks.length + " / " + wipLimit : tasks.length;
            const limitReached = (wipLimit && tasks.length == wipLimit);
            const limitExceeded = (wipLimit && tasks.length > wipLimit);
    
            // update WIP
            const columnElement = this.getColumnElement(column.id);
            const subtitleElement = columnElement.querySelector('.header .subtitle');
            subtitleElement.textContent = text;
    
            if(limitReached) {
                subtitleElement.classList.add('limitReached')
            } else {
                subtitleElement.classList.remove('limitReached')
            }
    
            if(limitExceeded) {
                subtitleElement.classList.add('limitExceeded')
            } else {
                subtitleElement.classList.remove('limitExceeded')
            }
    
        })
    }    
    
}

function columnBindingContext() {
    return function(column, areaName) {
        return column.tag?.binding.column;
    }
}

function areaBindingContext() {
    return function(column, areaName) {
        return column.tag?.binding.areas[areaName];
    }
}


function transformAutoBindingMap(autoBindingConfigurationForProperty, bindingContext) {
    const transformedMap = {}

    if(autoBindingConfigurationForProperty.enter) {
        transformedMap.enter = autoBindingConfigurationForProperty.enter(bindingContext);
    }
    
    if(autoBindingConfigurationForProperty.leave) {
        transformedMap.leave = autoBindingConfigurationForProperty.leave(bindingContext);
    }

    return transformedMap
}


export function updateTask(flowBoard) {
    return function(task, column, areaName) {
        return function(task) {
            return new Promise((resolve, reject) => {
                flowBoard.updateTask(task);
                resolve(task);
            });
        }
    }
}

function convertConditionToColumnDescription(condition) {

    let conditionDescription = [];

    for(let conditionKey in condition) {
        const key = capitalizeFirstLetter(conditionKey);
        const value = convertConditionValue(condition[conditionKey])
        conditionDescription.push({ [key]: value });
    }

    conditionDescription.sort((a,b) => Object.keys(a)[0].localeCompare(Object.keys(b)[0]))

    return conditionDescription;
}

function convertConditionValue(value) {


    if(value.description) {
        return value.description
    }
    
    if(value instanceof Function) {
        return value.name;
    }

    return value;
}

function capitalizeFirstLetter(val) {
    return String(val).charAt(0).toUpperCase() + String(val).slice(1);
}

function setColumnConditionDescription(targetElement, columnId, conditions) {
    const selector = `.columns .column#${columnId} .header .subtitle`;
    const subtitleElement = targetElement.querySelector(selector);
    if(! subtitleElement) {
        throw new Error("Element not found for selector: " + selector);
    }

    const description = conditions.map(condition => {
        return { name: Object.keys(condition)[0], value: Object.values(condition)[0] }
    }).reduce((acc, condition) => {
        return acc + "\n" + `<span class='condition'><span class='name' >${condition.name}</span><span class='value' >${condition.value}</span></span>`
    }, "");

    subtitleElement.insertAdjacentHTML('afterend', `<div class='conditions' >${description}</div>`);
}

