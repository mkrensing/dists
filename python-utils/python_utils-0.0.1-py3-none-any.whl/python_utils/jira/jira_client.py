import csv
import logging

import requests
from requests import Session
from typing import Dict
from python_utils.timestamp import now
from jira import JIRA
from typing import List

from python_utils.jira.caches.filter_cache import FilterCache
from python_utils.jira.caches.project_cache import ProjectCache
from python_utils.jira.caches.query_cache import QueryCache, JiraPageResult
from python_utils.jira.caches.roadmap_cache import RoadmapCache

logger = logging.getLogger(__name__)


class JiraClientRequestException(Exception):

    def __init__(self, status_code: int, message: str):
        super().__init__(message)
        self.status_code = status_code
        self.message = message

    def get_status_code(self) -> int:
        return self.status_code



class JiraClient:

    def __init__(self, hostname: str, cache_directory: str, test_mode=False, max_result_size=700):
        self.hostname = hostname
        self.query_cache = QueryCache(cache_directory=cache_directory)
        self.project_cache = ProjectCache(filename=f"{cache_directory}/project_cache.json")
        self.roadmap_cache = RoadmapCache(filename=f"{cache_directory}/roadmap_cache.json")
        self.filter_cache = FilterCache(filename=f"{cache_directory}/filter_cache.json")
        self.test_mode = test_mode
        self.max_result_size = max_result_size

    def set_test_mode(self, test_mode: bool):
        self.test_mode = test_mode

    def paginate(self, jql: str, access_token: str, use_cache: bool, page_size=200, expand="changelog", cache_suffix="") -> (List[Dict], str):
        page_result = self.get_issues(jql=jql, access_token=access_token, use_cache=use_cache, start_at=0,
                                      page_size=page_size, cache_suffix=cache_suffix, expand=expand)
        issues = []
        issues.extend(page_result.get_issues())

        while page_result.has_next():
            page_result = self.get_issues(jql=jql, access_token=access_token, use_cache=use_cache,
                                          start_at=page_result.get_next_start_at(), expand=expand, page_size=page_size, cache_suffix=cache_suffix)
            issues.extend(page_result.get_issues())

        return issues, page_result.get_timestamp()

    def get_issues(self, jql: str, access_token: str, use_cache: bool, expand: str, page_size=200, start_at=0, cache_suffix="") -> JiraPageResult:

        cache_id = f"{jql}_{cache_suffix}"

        logger.debug(
            f"get_issues(jql={jql}, use_cache={use_cache}, expand={expand}, page_size={page_size}, start_at={start_at}")

        if use_cache:
            jira_page = self.query_cache.get_all_pages(cache_id, start_at)
            if jira_page:
                logger.info(
                    f"Return cached issues for {cache_id}: Total={jira_page.get_total()} / issues: {len(jira_page.get_issues())}")
                return jira_page

        if self.test_mode:
            logger.info(f"TEST_MODE active. Return empty result for jql {jql}")
            return JiraPageResult(start_at=0, total=0, timestamp=now(), issues=[])

        jira_page = self.search(jql, access_token, expand, page_size, start_at)

        logger.info(f"Add {cache_id} to cache: {len(jira_page.get_issues())} items")
        self.query_cache.add_page(cache_id, jira_page)

        return jira_page

    def get_unreleased_versions(self, project_id: str, access_token: str) -> List[Dict[str, str]]:
        versions = self.get_versions(project_id, access_token)
        unreleased_versions = []
        for version in versions:
            if not version["released"]:
                unreleased_versions.append(version)

        return unreleased_versions

    def get_versions(self, project_id: str, access_token: str) -> List[Dict[str, str]]:

        versions = self.project_cache.get_versions(project_id)
        if versions:
            logger.info(
                f"Return cached versions for {project_id}: {versions}")
            return versions

        jira = self.create_jira(access_token=access_token)
        versions = [version.raw for version in jira.project_versions(project=project_id)]

        logger.info(f"Add versions to cache: {len(versions)} items")
        self.project_cache.add_versions(project_id, versions)

        return versions

    def get_roadmap(self, project_id: str, plan_id: int, scenario_id: int, fix_version_filters: List[str], access_token: str, use_cache=True) -> (
    List[Dict[str, str]], str):

        roadmap = None
        if use_cache:
            roadmap = self.roadmap_cache.get_roadmap(project_id, plan_id, scenario_id)

        if not roadmap:
            roadmap = self.get_roadmap_from_jira_backend(plan_id, scenario_id, access_token)
            self.roadmap_cache.add_roadmap(project_id, plan_id, scenario_id, roadmap["issues"])

        unreleased_versions = self.get_unreleased_versions(project_id, access_token)
        version_ids = self.get_matching_version_ids(unreleased_versions, fix_version_filters)
        roadmap_issues = roadmap["issues"]
        if version_ids:
            roadmap_issues = filter(
                lambda issue: has_fix_versions(issue, version_ids),
                roadmap_issues)

        roadmap_issues = sorted(roadmap_issues, key=lambda issue: issue["values"]["lexoRank"])
        issues = []
        for index, roadmap_issue in enumerate(roadmap_issues):
            issues.append(convert_roadmap_issue_to_issue(project_id, roadmap_issue))

        return {"issues": issues, "timestamp": roadmap["timestamp"]}

    def rank_issues(self, position: str, reference_issue_key: str, issue_keys: List[str],access_token: str, rank_custom_field_id: int = 0):

        operation = "rankAfterIssue" if position == "after" else "rankBeforeIssue"
        data = { "issues": issue_keys,
                 operation: reference_issue_key
        }

        if rank_custom_field_id:
            data["rankCustomFieldId"] = rank_custom_field_id

        session = self.create_session(access_token=access_token)
        url = f"{self.hostname}/rest/agile/1.0/issue/rank"
        response = session.put(url, json=data, allow_redirects=False)
        response.raise_for_status()

        return { "status": "OK"}

    def change_roadmap_issue_rank(self, plan_id: int, scenario_id: int, anchor_issue_id: int, issue_ids: List[int], access_token: str, operation="AFTER"):

        data = {"operations": [{"anchor": f"{anchor_issue_id}", "itemKeys": issue_ids, "operationType": f"{operation}"}], "planId": int(plan_id),
                "scenarioId": int(scenario_id)}
        session = self.create_session(access_token=access_token)
        response = session.post(f"{self.hostname}/rest/jpo/1.0/issues/rank", json=data,  allow_redirects=False)
        response.raise_for_status()
        return {"status": response.json()}

    def get_roadmap_from_jira_backend(self, plan_id: int, scenario_id: int, access_token: str) -> Dict[str, str]:

        session = self.create_session(access_token=access_token)

        data = {"planId": int(plan_id), "scenarioId": int(scenario_id),
                "filter": {"includeCompleted": False, "performDependencyCompletion": False, "includeIssueLinks": True}}

        response = session.post(f"{self.hostname}/rest/jpo/1.0/backlog",json=data,allow_redirects=False)
        response.raise_for_status()

        roadmap = response.json()
        return {"issues": roadmap["issues"], "timestamp": now()}

    def search(self, jql: str, access_token: str, expand: str, page_size: int, start_at: int) -> JiraPageResult:
        jira = self.create_jira(access_token=access_token)
        result_set = jira.search_issues(jql, expand=expand, maxResults=page_size, startAt=start_at)
        issues = [issue.raw for issue in result_set]
        return JiraPageResult(start_at=result_set.startAt, total=result_set.total, timestamp=now(), issues=issues)

    def get_filter(self, filter_id: str, access_token: str, use_cache=False, only_current_fields=True) -> Dict[str, str]:

        filter_result = None
        if use_cache:
            filter_result = self.filter_cache.get_filter(filter_id)
            if filter_result:
                return filter_result

        fields = "current" if only_current_fields else "all"

        # URL für den CSV-Download
        url = f"{self.hostname}/sr/jira.issueviews:searchrequest-csv-{fields}-fields/{filter_id}/SearchRequest-{filter_id}.csv"

        session = self.create_session(access_token)
        response = session.get(url, allow_redirects=False)

        if response.status_code == 302 and "Location" in response.headers and response.headers["Location"].startswith("/jira/login.jsp"):
            raise JiraClientRequestException(status_code=403, message=f"Access denied for url {url}")

        if response.status_code != 200:
            raise JiraClientRequestException(status_code=response.status_code, message=response.text)

        csv_content = response.text
        json = csv_to_json(csv_content)

        self.filter_cache.add_filter(filter_id, json)

        return {"issues": json, "timestamp": now()}

    def get_sprints_for_project(self, project_id: str, name_filter: str, activated_date: str, access_token: str, force_reload=False) -> List[Dict[str, str]]:

        if not force_reload:
            sprints = self.project_cache.get_sprints(project_id, name_filter, activated_date)
            if sprints:
                return sprints

        sprint_ids = []
        sprints = []
        jira = self.create_jira(access_token=access_token)
        boards = self.get_boards_for_project(jira, project_id, name_filter)
        for board in boards:
            for sprint in [sprint.raw for sprint in jira.sprints(board_id=int(board["id"]))]:
                if "activatedDate" in sprint and sprint["activatedDate"] >= activated_date and sprint["id"] not in sprint_ids:
                    sprint_ids.append(sprint["id"])
                    sprints.append(sprint)

        self.project_cache.add_sprints(project_id, name_filter, activated_date, sprints)

        return sprints

    def get_boards_for_project(self, jira: JIRA, project_id: str, name_filter: str) -> List[Dict[str, str]]:
        boards = []
        for board in jira.boards(projectKeyOrID=project_id, type="scrum", maxResults=50):
            if name_filter in board.name:
                boards.append(board.raw)

        return sorted(boards, key=lambda board: board["id"], reverse=False)

    def get_issue(self, issue_key: str, access_token: str, expand="name", fields="*navigable,-comment,-watches", flat=True) -> Dict[str, str]:

        session = self.create_session(access_token)
        url = f"{self.hostname}/rest/api/2/issue/{issue_key}?expand={expand}&fields={fields}"
        print(f"url: {url}")
        response = session.get(url, allow_redirects=False)
        response.raise_for_status()

        issue=response.json()
        if flat:
            for field_name in issue["fields"]:
                issue[field_name] = issue["fields"][field_name]

            del issue["expand"]
            del issue["fields"]

        return issue

    def update(self, issue_key: str, changes: Dict, access_token: str):

        field_names = []
        for property_name in changes:
            field_names.append(property_name)

        session = self.create_session(access_token)
        print(f"update: {changes}")
        response = session.put(f"{self.hostname}/rest/api/2/issue/{issue_key}", json={ "update" : changes },  allow_redirects=False)
        print(response.text)
        response.raise_for_status()

        return self.get_issue(issue_key, access_token, fields=",".join(field_names))


    def change_status(self, project_id: str, issue_key: str, current_status_name: str, target_status_name: str, access_token: str):
        valid_transitions_for_status = self.project_cache.get_transitions(project_id=project_id, start_status_name=current_status_name)

        if not valid_transitions_for_status:
            valid_transitions_for_status = self.get_valid_transitions_for_status(issue_key, access_token)
            self.project_cache.add_transitions(project_id=project_id, start_status_name=current_status_name, transitions=valid_transitions_for_status)

        if target_status_name not in valid_transitions_for_status:
            self.project_cache.clear_transitions(project_id)
            raise JiraClientRequestException(status_code=400, message=f"No transition found for {issue_key} from status {current_status_name} to {target_status_name}")

        return self.set_transition(issue_key, valid_transitions_for_status[target_status_name]["id"], access_token)



    def get_valid_transitions_for_status(self, issue_key: str, access_token: str) -> Dict[str, Dict[str, str]]:
        session = self.create_session(access_token)
        response = session.get(f"{self.hostname}/rest/api/2/issue/{issue_key}/transitions")
        response.raise_for_status()
        valid_transitions_for_status = {}
        transitions_response=response.json()
        for transition in transitions_response["transitions"]:
            valid_transitions_for_status[transition["name"]] = { "id": transition["id"], "name": transition["name"]}

        return valid_transitions_for_status

    def set_transition(self, issue_key: str, target_transition_id: str, access_token: str):
        data = {
            "transition": {
                "id": target_transition_id
            }
        }
        session = self.create_session(access_token)
        response = session.post(f"{self.hostname}/rest/api/2/issue/{issue_key}/transitions", json=data)
        response.raise_for_status()

    def assign_issue(self, issue_key: str, username: str, access_token: str):
        session = self.create_session(access_token)
        account_id = None
        print(f"assign_issue: {username}")
        if username:
            account = self.get_account_for_username(username, access_token)
            print(f"account for {username}: {account}")
            if not account:
                raise Exception(f"User not found: {username}")
            account_id = account["accountId"]

        data={ "accountId": account_id }
        response = session.put(f"{self.hostname}/rest/api/3/issue/{issue_key}/assignee", json=data)
        response.raise_for_status()
        print(response.text)
        return { "message": "OK" }

    def get_account_for_username(self, username: str, access_token: str) -> Dict:
        session = self.create_session(access_token)
        data={ "accountId": "" }
        response = session.get(f"{self.hostname}/rest/api/2/user/search?query={username}")
        response.raise_for_status()
        users =  response.json()

        if len(users) == 0:
            return None

        if len(users) > 1:
            raise Exception(f"Multiple accounts found for {username}: {users}")

        return users[0]


    def close(self):
        if self.query_cache:
            self.query_cache.close()
        if self.project_cache:
            self.project_cache.close()

    def create_jira(self, access_token: str) -> JIRA:
        if ":::" in access_token:
            username_password = access_token.split(":::")
            return JIRA(self.hostname, basic_auth=(username_password[0], username_password[1]))
        else:
            return JIRA(self.hostname, token_auth=access_token)


    @staticmethod
    def create_session(access_token: str) -> Session:
        session = requests.Session()
        if ":::" in access_token:
            username_password = access_token.split(":::")
            session.headers = {
                "Accept": "application/json"
            }
            session.auth = (username_password[0], username_password[1])
        else:
            session.headers = {
            "Accept": "application/json",
            "Authorization": f"Bearer {access_token}"
        }

        return session

    @staticmethod
    def get_matching_version_ids(versions: List[Dict[str, str]], version_filters: List[str]) -> List[str]:
        version_ids: List[int] = []
        for version in versions:
            for version_filter in version_filters:
                if version["name"].startswith(version_filter):
                    version_ids.append(str(version["id"]))

        return version_ids


def has_fix_versions(issue: Dict, fix_versions_filters: List[str]) -> bool:
    if not "fixVersions" in issue["values"]:
        return False

    for fix_version_filter in fix_versions_filters:
        if fix_version_filter in issue["values"]["fixVersions"]:
            return True

    return False


def convert_roadmap_issue_to_issue(project_id: str, roadmap_issue: Dict) -> Dict:
    return {"key": f"{project_id}-{roadmap_issue['issueKey']}",
            "id": roadmap_issue["id"],
            "summary": roadmap_issue["values"]["summary"],
            "labels": roadmap_issue["values"]["labels"] if "labels" in roadmap_issue["values"] else [],
            "issuetype": roadmap_issue["values"]["type"],
            "status": roadmap_issue["values"]["status"]
            }


def csv_to_json(csv_content: str) -> List:
    # Initialize a result list for storing the dictionaries
    result = []
    # Use the csv.reader to handle quoted fields and commas within fields
    reader = csv.reader(csv_content.strip().split('\n'))
    # Extract headers from the first row
    headers = next(reader)

    # Iterate through each subsequent row
    for row in reader:
        obj = {}
        # Iterate through each column and create objects
        for header, value in zip(headers, row):
            key = header.strip()
            value = value.strip()
            if value:
                # If the key already exists, append the value to a list
                if key in obj:
                    if isinstance(obj[key], list):
                        obj[key].append(value)
                    else:
                        obj[key] = [obj[key], value]
                # Otherwise, add the normal key-value pair
                else:
                    obj[key] = value
        # Append the dictionary to the result list
        result.append(obj)

    return result
