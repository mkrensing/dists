from python_utils.jira.base.jira_server import JiraConnection
from python_utils.jira.base.user_context import JiraUserContext

from python_utils.jira.commands.search import JiraSearch
from python_utils.jira.commands.fast_search import JiraFastSearchClient
from python_utils.jira.commands.fields import JiraFields
from python_utils.jira.commands.project import JiraProject
from python_utils.jira.commands.issue import JiraIssueAPI
from python_utils.jira.commands.roadmap import JiraRoadmap
from python_utils.jira.commands.filter import JiraFilter

class JiraApi:

    def __init__(self, cache_directory: str):
        self.cache_directory = cache_directory

    def search(self, jira_server: JiraConnection, token: str, test_mode=False, use_cache=True) -> JiraSearch:
        return JiraSearch(jira_server=jira_server,
                          cache_directory=self.cache_directory,
                          user_context=JiraUserContext(token_or_provider=token, test_mode=test_mode, use_cache=use_cache))

    def search_with_context(self, jira_server: JiraConnection, user_context: JiraUserContext) -> JiraSearch:
        return JiraSearch(jira_server=jira_server,
                          cache_directory=self.cache_directory,
                          user_context=user_context)


    def fast_search(self, jira_server: JiraConnection, token: str) -> JiraFastSearchClient:
        return JiraFastSearchClient(jira_server=jira_server,
                                    cache_directory=self.cache_directory,
                                    user_context=JiraUserContext(token_or_provider=token, test_mode=False, use_cache=False))

    def fast_search_with_context(self, jira_server: JiraConnection, user_context: JiraUserContext) -> JiraFastSearchClient:
        return JiraFastSearchClient(jira_server=jira_server,
                          cache_directory=self.cache_directory,
                          user_context=user_context)

    def fields(self, jira_server: JiraConnection, token: str) -> JiraFields:
        return JiraFields(jira_server=jira_server,
                          user_context=JiraUserContext(token_or_provider=token, test_mode=False, use_cache=False))

    def project(self, jira_server: JiraConnection, token: str) -> JiraProject:
        return JiraProject(jira_server=jira_server,
                          cache_directory=self.cache_directory,
                          user_context=JiraUserContext(token_or_provider=token, test_mode=False, use_cache=False))

    def project_with_context(self, jira_server: JiraConnection, user_context: JiraUserContext) -> JiraProject:
        return JiraProject(jira_server=jira_server,
                          cache_directory=self.cache_directory,
                          user_context=user_context)

    def roadmap(self, jira_server: JiraConnection, token: str) -> JiraRoadmap:
        return JiraRoadmap(jira_server=jira_server,
                           cache_directory=self.cache_directory,
                           user_context=JiraUserContext(token_or_provider=token, test_mode=False, use_cache=False))

    def roadmap_with_context(self, jira_server: JiraConnection, user_context: JiraUserContext) -> JiraRoadmap:
        return JiraRoadmap(jira_server=jira_server,
                          cache_directory=self.cache_directory,
                          user_context=user_context)


    def filter(self, jira_server: JiraConnection, token: str) -> JiraFilter:
        return JiraFilter(jira_server=jira_server,
                           cache_directory=self.cache_directory,
                           user_context=JiraUserContext(token_or_provider=token, test_mode=False, use_cache=False))

    def filter_with_context(self, jira_server: JiraConnection, user_context: JiraUserContext) -> JiraFilter:
        return JiraFilter(jira_server=jira_server,
                          cache_directory=self.cache_directory,
                          user_context=user_context)

    def issue(self, jira_server: JiraConnection, token: str) -> JiraIssueAPI:
        return JiraIssueAPI(jira_server=jira_server,
                           cache_directory=self.cache_directory,
                           user_context=JiraUserContext(token_or_provider=token, test_mode=False, use_cache=False))

    def issue_with_context(self, jira_server: JiraConnection, user_context: JiraUserContext) -> JiraIssueAPI:
        return JiraIssueAPI(jira_server=jira_server,
                          cache_directory=self.cache_directory,
                          user_context=user_context)