from typing import Dict, List
from python_utils.jira.caches.distributed_cache import DistributedCache


class JiraPageResult:

    def __init__(self, start_at: int, total: int, timestamp: str, issues: List[Dict]):
        self.start_at = start_at
        self.total = total
        self.timestamp = timestamp
        self.issues = issues

    def get_start_at(self) -> int:
        return self.start_at

    def get_total(self) -> int:
        return self.total

    def get_issues(self) -> List[Dict]:
        return self.issues

    def get_next_start_at(self) -> int:
        return self.start_at + len(self.issues)

    def has_next(self) -> bool:
        return self.get_next_start_at() < self.total

    def get_timestamp(self) -> str:
        return self.timestamp

    def __dict__(self) -> Dict:
        return {"nextStartAt": self.get_next_start_at(), "hasNext": self.has_next(), "total": self.total, "timestamp": self.timestamp,
                "issues(count)": len(self.issues)}


class QueryCache:

    def __init__(self, cache_directory: str):
        self.cache = DistributedCache(cache_directory, "query")

    def get_all_pages(self, jql: str, start_at: int = 0) -> JiraPageResult:
        result = self.cache.get_object(key={"jql": {"comparator": "==", "value": jql},
                                            "startAt": {"comparator": ">=", "value": start_at, "optional": True}
                                            })
        if not result:
            return None
        issues = []
        total = 0
        timestamp = ""
        for page in result:
            issues.extend(page["issues"])
            total = max(total, page["total"])
            timestamp = max(timestamp, page["timestamp"])

        return JiraPageResult(start_at=start_at, total=total, timestamp=timestamp, issues=issues)

    def remove_all_pages(self, jql: str):
        self.cache.remove_object({ "jql": jql })

    def get_page(self, jql: str, start_at: int) -> None | JiraPageResult:
        result = self.cache.get_object(key={"jql": {"comparator": "==", "value": jql},
                                            "startAt": {"comparator": "==", "value": start_at, "optional": True}
                                            })
        if not result:
            return None
        if len(result) != 1:
            raise Exception(f"Found two matches for jql: {jql}")

        page = result[0]
        return JiraPageResult(start_at=start_at, total=page["total"], timestamp=page["timestamp"], issues=page["issues"])

    def add_page(self, jql, page: JiraPageResult):

        key= {
            "jql": {"comparator": "==", "value": jql},
            "startAt": {"comparator": "==", "value": page.get_start_at(), "optional": True}
        }
        self.cache.set_object(key=key, data={"total": page.get_total(), "timestamp": page.get_timestamp(), "issues": page.get_issues()})

    def clear(self):
        self.cache.clear()

    def close(self):
        self.cache.close()

