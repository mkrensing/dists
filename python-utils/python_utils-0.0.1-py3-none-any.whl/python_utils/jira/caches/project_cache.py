import os.path
from pathlib import Path
from typing import Dict
from tinydb import TinyDB, Query, where
from tinydb.middlewares import CachingMiddleware
from tinydb.storages import JSONStorage
from filelock import FileLock
from typing import List

from python_utils.jira.caches.base import AbstractCache

def current_timestamp() -> str:
    from time import strftime
    return strftime("%Y-%m-%d")

class TransitionsCache:

    def __init__(self, lock, db):
        self.lock = lock
        self.db = db

    def get_transitions(self, project_id: str, start_status_name: str) ->  Dict[str, List[Dict[str, str]]]:
        cached_queries = Query()
        with self.lock:
            result = self.db.search(
                (cached_queries.type == "transitions") & (cached_queries.project_id == project_id) & (cached_queries.status == start_status_name) & (
                            cached_queries.timestamp == current_timestamp()))

        if not result:
            return None

        return result[0]["transitions"]

    def add_transitions(self, project_id: str, start_status_name: str, transitions: Dict[str, List[Dict[str, str]]]):
        cached_queries = Query()
        with self.lock:
            self.db.upsert(
                document={"type": "transitions", "project_id": project_id, "status": start_status_name, "timestamp": current_timestamp(), "transitions": transitions},
                cond=(cached_queries.type == "transitions") & (cached_queries.project_id == project_id) & (cached_queries.status == start_status_name)
            )
            self.db.storage.flush()

    def clear_transitions(self, project_id: str):
        with self.lock:
            self.db.remove(where("project_id") == project_id)
            self.db.storage.flush()


class VersionsCache(AbstractCache):

    def __init__(self, lock, db):
        self.lock = lock
        self.db = db

    def get_item(self, key: str):
        return self.get_versions(project_id=key)

    def add_item(self, key: str, item):
        self.add_versions(project_id=key, versions=item)

    def get_versions(self, project_id: str) -> List[Dict[str, str]]:
        cached_queries = Query()
        with self.lock:
            result = self.db.search((cached_queries.type == "version") & (cached_queries.id == project_id) & (

                    cached_queries.timestamp == current_timestamp()))
        if not result:
            return None

        return result[0]["versions"]

    def add_versions(self, project_id: str, versions: List[Dict[str, str]]):
        cached_queries = Query()
        with self.lock:
            self.db.upsert({"type": "versions", "id": project_id, "timestamp": current_timestamp(), "versions": versions},
                           (cached_queries.type == "versions") & (cached_queries.id == project_id))
            self.db.storage.flush()

class SprintsCache:

    def __init__(self, lock, db):
        self.lock = lock
        self.db = db

    @staticmethod
    def create_sprint_record_id(project_id: str, name_filter: str, activated_date: str) -> str:
        return f"{project_id}_{name_filter}_{activated_date}"


    def get_sprints(self, project_id: str, name_filter: str, activated_date: str) -> List[Dict[str, str]]:
        cached_queries = Query()
        with self.lock:
            result = self.db.search(
                (cached_queries.type == "sprints") & (cached_queries.id == self.create_sprint_record_id(project_id, name_filter, activated_date)) & (
                            cached_queries.timestamp == current_timestamp()))
        if not result:
            return None

        return result[0]["sprints"]

    def add_sprints(self, project_id: str, name_filter: str, activated_date: str, sprints: List[Dict[str, str]]):
        cached_queries = Query()
        with self.lock:
            record_id = self.create_sprint_record_id(project_id, name_filter, activated_date)
            self.db.upsert({"type": "sprints", "id": record_id, "timestamp": current_timestamp(), "sprints": sprints},
                           (cached_queries.type == "sprints") & (cached_queries.id == record_id))
            self.db.storage.flush()


class ProjectCache:

    def __init__(self, filename: str):
        self.filename = filename
        print(os.path.abspath(self.filename))
        Path(self.filename).touch()
        self.lock = FileLock(f"{self.filename}.lock")
        self.db = TinyDB(self.filename, storage=CachingMiddleware(JSONStorage))

    def for_transitions(self) -> TransitionsCache:
        return TransitionsCache(self.lock, self.db)

    def for_versions(self) -> VersionsCache:
        return VersionsCache(self.lock, self.db)

    def for_sprints(self) -> SprintsCache:
        return SprintsCache(self.lock, self.db)

    def clear(self):
        with self.lock:
            self.db.truncate()

    def close(self):
        if self.db:
            self.db.close()