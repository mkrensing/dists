import functools
import inspect
from python_utils.timestamp import get_timebased_hash_based_on_seconds

cache_disabled = False

def disable_caching():
    global  cache_disabled
    cache_disabled = True
    print("Jira caching is disabled")

class AbstractCache:

    def get_item(self, key: str):
        pass

    def add_item(self, key: str, item):
        pass

class Arguments:

    def __init__(self, func, *args, **kwargs):
        # Use `inspect` to bind the provided args/kwargs to the function signature,
        # which allows us to extract the actual value of the specified parameters.
        sig = inspect.signature(func)
        self.bound_args = sig.bind(*args, **kwargs)
        self.bound_args.apply_defaults()

    def get_argument(self, name: str, default_value=None):
        return self.bound_args.arguments[name] if name in self.bound_args.arguments else default_value


def cached(cache_name: str, key_argument: str, result_key: str = None, enabled_argument: str = None, cache_interval_in_seconds: int = 0):

    def get_cache(target_self, cache_name: str) -> AbstractCache:
        return getattr(target_self, cache_name)

    """
    A decorator for caching on the instance level (using self.filter_cache).

    :param key: The name of the function parameter to be used as the cache key.
                For example, "filter_id".
    :param result_key: If provided, only the part result[result_key] will be
                       returned/stored. Otherwise, the entire result is used.
    """
    def decorator(func):

        @functools.wraps(func)
        def wrapper(*args, **kwargs):

            if cache_disabled:
                print("caching is disabled")
                return func(*args, **kwargs)

            # Since this is presumably an instance method, args[0] = self.
            self = args[0]

            arguments = Arguments(func, *args, **kwargs)

            # Extract the cache key from the function arguments.
            cache_key = arguments.get_argument(key_argument)
            if cache_interval_in_seconds:
                hash = get_timebased_hash_based_on_seconds(cache_interval_in_seconds)
                cache_key = f"{cache_key}&hash={hash}"

            cache_enabled = arguments.get_argument(enabled_argument, True)
            cache = get_cache(self, cache_name)

            print(f"cached. cache_key: {cache_key}, cache_enabled: {cache_enabled}")

            # 1) Check if there's already a cached value for this key
            cached_value = cache.get_item(cache_key)
            if cached_value is not None:
                print("return from cache!")
                # If 'result_key' is specified, return only that part
                return cached_value[result_key] if result_key else cached_value

            # 2) No cache hit => call the original function to fetch data
            result = func(*args, **kwargs)

            # 3) Store the result in the cache
            cache.add_item(cache_key, result)

            return result

        return wrapper
    return decorator
