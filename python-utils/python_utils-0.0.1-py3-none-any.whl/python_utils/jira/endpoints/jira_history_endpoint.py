import traceback

from flask import Blueprint, request
from typing import Dict, List
from python_utils.jira.jira_history import JiraHistory
from python_utils.flask.endpoint import response_json
from python_utils.env import inject_environment
from python_utils.jira.jira_security import token_required, get_access_token
from python_utils.jira.jira_api import JiraApi, JiraUserContext, JiraConnection

jira_history_endpoint = Blueprint('jira_history_endpoint', __name__, url_prefix='/rest/jira/history')

class JiraHistoryConfig:

    def __init__(self, jira_config: Dict):
        self.jira_config = jira_config

    def is_valid(self) -> bool:
        return "jql" in self.jira_config and \
            "useCache" in self.jira_config and \
            "pageSize" in self.jira_config and \
            "fields" in self.jira_config

    def get_jql(self):
        return self.jira_config["jql"]

    def is_use_cache(self) -> bool:
        return bool(self.jira_config["useCache"])

    def get_page_size(self) -> int:
        return self.jira_config["pageSize"]

    def get_fields(self) -> Dict[str, str]:
        return self.jira_config["fields"]


@inject_environment(
    { "CACHE_DIRECTORY": "" },
    required=True)
def create_jira_api(cache_directory: str) -> JiraApi:
    return JiraApi(cache_directory=cache_directory)

@inject_environment(
    { "TEST_MODE": "False"},
    required=True)
def create_user_context(test_mode: str) -> JiraUserContext:
    return JiraUserContext(token_or_provider=lambda : get_access_token(),
                           use_cache=False,
                           test_mode=test_mode.lower() in ["true", "1"])

@inject_environment(
    {"JIRA_HOSTNAME": "", "JIRA_VERIFY_SSL": "true" },
    required=True)
def create_jira_server(jira_hostname: str, jira_verify_ssl: str) -> JiraConnection:
    return JiraConnection(hostname=jira_hostname, verify_ssl=jira_verify_ssl.lower() in [ "1", "true" ])


jira_api = create_jira_api()

@jira_history_endpoint.route('/search/<int:start_at>', methods=["POST"])
@token_required()
def post_search_history(start_at: int):
    try:
        config = JiraHistoryConfig(request.json)
        if not config.is_valid():
            return response_json({"error": f"Invalid request body. Expected JiraHistoryConfig"}), 400

        jira_search_api = jira_api.search_with_context(create_jira_server(), create_user_context())
        jira_search_api.get_user_context().set_use_cache(config.is_use_cache())
        jira_page = jira_search_api.search(jql=config.get_jql(), fields=None, expand="changelog", start_at=start_at, page_size=config.get_page_size())
        issues = jira_page.get_issues()
        history_issues = convert_to_history_issues(issues, config.get_fields())

        return response_json({ "nextStartAt": jira_page.get_next_start_at(), "hasNext": jira_page.has_next(), "total": jira_page.get_total(), "timestamp": jira_page.get_timestamp(), "issues": history_issues })

    except Exception as e:
        print(e)
        print(traceback.format_exc())
        return response_json({"error": str(e)}), 400


def convert_to_history_issues(issues: List[Dict], issues_fields: Dict[str, str]) -> List[Dict]:
    return JiraHistory(issues_fields=issues_fields).get_histories(issues)
