from typing import List, Dict
from python_utils.jira.base.user_context import JiraUserContext, SessionProxy
from python_utils.jira.base.jira_server import JiraConnection

class JiraFields:

    def __init__(self, jira_server: JiraConnection, user_context: JiraUserContext):
        self.jira_server = jira_server
        self.user_context = user_context

    def create_session(self) -> SessionProxy:
        return self.user_context.create_session(self.jira_server)

    def get_custom_fields(self) -> List[Dict[str, str]]:
        session = self.create_session()
        response = session.get("/rest/api/2/field")

        all_fields = response.json()

        custom_fields = [field for field in all_fields if field.get("custom", False)]

        for field in custom_fields:
            field_id = field["id"]
            context_response = session.get( f"/rest/api/2/field/{field_id}/contexts")
            field["contexts"] = context_response.json().get("values", [])

        return custom_fields


    def get_field_context(self, field_id: str) -> List[Dict[str, str]]:
        session = self.user_context.create_session()
        context_response = session.get(f"/rest/api/2/app/field/{field_id}/context/configuration")
        context_response.raise_for_status()

        return context_response.json().get("values", [])
