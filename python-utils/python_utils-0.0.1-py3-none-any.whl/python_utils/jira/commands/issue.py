from typing import List, Dict
from python_utils.jira.base.jira_errors import JiraClientRequestException
from python_utils.jira.base.user_context import JiraUserContext, SessionProxy
from python_utils.jira.base.jira_server import JiraConnection

from python_utils.jira.caches.project_cache import ProjectCache

class JiraIssueAPI:

    def __init__(self, jira_server: JiraConnection, cache_directory: str, user_context: JiraUserContext):
        self.jira_server = jira_server
        self.user_context = user_context
        self.project_cache = ProjectCache(filename=f"{cache_directory}/project_cache.json")

    def create_session(self) -> SessionProxy:
        return self.user_context.create_session(self.jira_server)

    def rank_issues(self, position: str, reference_issue_key: str, issue_keys: List[str], rank_custom_field_id: int = 0):

        operation = "rankAfterIssue" if position == "after" else "rankBeforeIssue"
        data = { "issues": issue_keys,
                 operation: reference_issue_key
        }

        if rank_custom_field_id:
            data["rankCustomFieldId"] = rank_custom_field_id

        session = self.create_session()
        response = session.put("/rest/agile/1.0/issue/rank", data=data)

        return { "status": "OK"}


    def get_issue(self, issue_key: str, expand="name", fields="*navigable,-comment,-watches", flat=True) -> Dict[str, str]:

        session = self.create_session()
        response = session.get(f"/rest/api/2/issue/{issue_key}?expand={expand}&fields={fields}")

        issue=response.json()
        if flat:
            for field_name in issue["fields"]:
                issue[field_name] = issue["fields"][field_name]

            del issue["expand"]
            del issue["fields"]

        return issue

    def update(self, issue_key: str, changes: Dict):

        field_names = []
        for property_name in changes:
            field_names.append(property_name)

        session = self.create_session()
        response = session.put(f"/rest/api/2/issue/{issue_key}", data={ "update" : changes })

        return self.get_issue(issue_key, fields=",".join(field_names))


    def change_status(self, project_id: str, issue_key: str, current_status_name: str, target_status_name: str):
        valid_transitions_for_status = self.project_cache.get_transitions(project_id=project_id, start_status_name=current_status_name)

        if not valid_transitions_for_status:
            valid_transitions_for_status = self.get_valid_transitions_for_status(issue_key)
            self.project_cache.add_transitions(project_id=project_id, start_status_name=current_status_name, transitions=valid_transitions_for_status)

        if target_status_name not in valid_transitions_for_status:
            self.project_cache.clear_transitions(project_id)
            raise JiraClientRequestException(status_code=400, message=f"No transition found for {issue_key} from status {current_status_name} to {target_status_name}")

        return self.set_transition(issue_key, valid_transitions_for_status[target_status_name]["id"])


    def get_valid_transitions_for_status(self, issue_key: str) -> Dict[str, Dict[str, str]]:
        session = self.create_session()
        response = session.get(f"/rest/api/2/issue/{issue_key}/transitions")

        valid_transitions_for_status = {}
        transitions_response=response.json()
        for transition in transitions_response["transitions"]:
            valid_transitions_for_status[transition["name"]] = { "id": transition["id"], "name": transition["name"]}

        return valid_transitions_for_status

    def set_transition(self, issue_key: str, target_transition_id: str):
        data = {
            "transition": {
                "id": target_transition_id
            }
        }
        session = self.create_session()
        response = session.post(f"/rest/api/2/issue/{issue_key}/transitions", data=data)

    def assign_issue(self, issue_key: str, username: str):
        session = self.create_session()
        account_id = None

        if username:
            account = self.get_account_for_username(username)

            if not account:
                raise Exception(f"User not found: {username}")
            account_id = account["accountId"]

        data={ "accountId": account_id }
        response = session.put(f"/rest/api/3/issue/{issue_key}/assignee", data=data)

        return { "message": "OK" }

    def get_account_for_username(self, username: str) -> Dict:
        session = self.create_session()
        data={ "accountId": "" }
        response = session.get(f"/rest/api/2/user/search?query={username}")
        users =  response.json()

        if len(users) == 0:
            return None

        if len(users) > 1:
            raise Exception(f"Multiple accounts found for {username}: {users}")

        return users[0]