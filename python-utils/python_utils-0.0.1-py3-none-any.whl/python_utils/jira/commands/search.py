from os import access
from typing import List, Dict
import logging
from python_utils.jira.caches.query_cache import QueryCache
from python_utils.jira.base.user_context import JiraUserContext, SessionProxy
from python_utils.jira.base.jira_server import JiraConnection
from python_utils.timestamp import now

logger = logging.getLogger(__name__)

class JiraPageResult:

    def __init__(self, start_at: int, total: int, timestamp: str, issues: List[Dict]):
        self.start_at = start_at
        self.total = total
        self.timestamp = timestamp
        self.issues = issues

    def get_start_at(self) -> int:
        return self.start_at

    def get_total(self) -> int:
        return self.total

    def get_issues(self) -> List[Dict]:
        return self.issues

    def get_next_start_at(self) -> int:
        return self.start_at + len(self.issues)

    def has_next(self) -> bool:
        return self.get_next_start_at() < self.total

    def get_timestamp(self) -> str:
        return self.timestamp

    def __dict__(self) -> Dict:
        return {"nextStartAt": self.get_next_start_at(), "hasNext": self.has_next(), "total": self.total, "timestamp": self.timestamp,
                "issues(count)": len(self.issues)}


class JiraSearch:

    def __init__(self, jira_server: JiraConnection, cache_directory: str, user_context: JiraUserContext):
        self.jira_server = jira_server
        self.query_cache = QueryCache(cache_directory=cache_directory)
        self.user_context = user_context

    def get_user_context(self) -> JiraUserContext:
        return self.user_context

    def create_session(self) -> SessionProxy:
        return self.user_context.create_session(self.jira_server)

    def search_all(self, jql: str, fields=None, expand="changelog", page_size=200) -> (List[Dict], str):
        page_result = self.search(jql=jql,
                                      fields=fields,
                                      expand=expand,
                                      start_at=0,
                                      page_size=page_size)
        issues = []
        issues.extend(page_result.get_issues())

        while page_result.has_next():
            page_result = self.search(jql=jql,
                                          fields=fields,
                                          expand=expand,
                                          start_at=page_result.get_next_start_at(),
                                          page_size=page_size)

            issues.extend(page_result.get_issues())

        return issues, page_result.get_timestamp()

    def search(self, jql: str, fields: str, expand: str, page_size=200, start_at=0) -> JiraPageResult:

        cache_id = f"{jql}_{self.user_context.get_cache_suffix()}"

        logger.debug(
            f"get_issues(jql={jql}, expand={expand}, fields={fields}, page_size={page_size}, start_at={start_at}")

        if self.user_context.get_use_cache():
            jira_page = self.query_cache.get_all_pages(cache_id, start_at)
            if jira_page:
                logger.info(
                    f"Return cached issues for {cache_id}: Total={jira_page.get_total()} / issues: {len(jira_page.get_issues())}")
                return jira_page

        if self.user_context.get_test_mode():
            logger.info(f"TEST_MODE active. Return empty result for jql {jql}")
            return JiraPageResult(start_at=0, total=0, timestamp=now(), issues=[])

        jira_page = self.search_for_page_result(jql=jql,
                                                fields=fields,
                                                expand=expand,
                                                page_size=page_size,
                                                start_at=start_at)

        logger.info(f"Add {cache_id} to cache: {len(jira_page.get_issues())} items")
        self.query_cache.add_page(cache_id, jira_page)

        return jira_page

    def search_for_page_result(self, jql: str, fields: str, expand: str, page_size: int, start_at: int) -> JiraPageResult:
        session = self.create_session()
        result_set = session.get(url="/rest/api/2/search", params={ "jql": jql, "fields": fields, "expand": expand, "maxResults": page_size, "startAt": start_at})
        print(result_set)

        return JiraPageResult(start_at=result_set["startAt"], total=result_set["total"], timestamp=now(), issues=result_set["issues"])

