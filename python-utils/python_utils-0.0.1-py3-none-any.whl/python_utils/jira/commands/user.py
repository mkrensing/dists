from typing import List, Dict
from python_utils.jira.base.user_context import JiraUserContext, SessionProxy
from python_utils.jira.base.jira_server import JiraConnection
from python_utils.jira.caches.user_cache import UserCache

class JiraUserAPI:

    def __init__(self, jira_server: JiraConnection, cache_directory: str, user_context: JiraUserContext):
        self.jira_server = jira_server
        self.user_context = user_context
        self.user_cache = UserCache(filename=f"{cache_directory}/user_cache.json")

    def create_session(self) -> SessionProxy:
        return self.user_context.create_session(self.jira_server)

    def get_user(self, account_id: str):

        user = self.user_cache.get_user(account_id)
        if user:
            return user

        session = self.create_session()
        response = session.get(f"/rest/api/latest/user?accountId={account_id}")
        user = response.json()

        self.user_cache.add_user(account_id, user)

        return user

    def get_avatar_url(self, account_id: str, size="48x48") -> str:

        user = self.get_user(account_id)
        avatar_urls = user["avatarUrls"]
        if not size in avatar_urls:
            return None

        return avatar_urls[size]

    def get_users(self, account_ids: List[str]):

        users = []
        session = self.create_session()
        user_account_query = "&".join([ f"accountId={account_id}" for account_id in account_ids ])
        users_page = self.get_users_page(f"/rest/api/latest/user/bulk?{user_account_query}")
        while not users_page["isLast"]:
            users.extend(users_page["values"])
            users_page = self.get_users_page(users_page["nextPage"])

        users.extend(users_page["values"])
        return users

    def get_users_page(self, url: str):

        session = self.create_session()
        response = session.get(url)

        return response.json()