import logging
from typing import List, Dict
from python_utils.jira.base.user_context import JiraUserContext, SessionProxy
from python_utils.jira.base.jira_server import JiraConnection
from python_utils.jira.base.jira_pagination import paginate
from python_utils.jira.caches.project_cache import ProjectCache


logger = logging.getLogger(__name__)

class JiraProject:

    def __init__(self, jira_server: JiraConnection, cache_directory: str, user_context: JiraUserContext):
        self.jira_server = jira_server
        self.user_context = user_context
        self.project_cache = ProjectCache(filename=f"{cache_directory}/project_cache.json")

    def create_session(self) -> SessionProxy:
        return self.user_context.create_session(self.jira_server)

    def get_unreleased_versions(self, project_id: str) -> List[Dict[str, str]]:
        versions = self.get_versions(project_id)
        unreleased_versions = []
        for version in versions:
            if not version["released"]:
                unreleased_versions.append(version)

        return unreleased_versions

    def get_versions(self, project_id: str) -> List[Dict[str, str]]:

        versions = self.project_cache.get_versions(project_id)
        if versions:
            logger.info(
                f"Return cached versions for {project_id}: {versions}")
            return versions

        session = self.create_session()
        response = session.get(f"/rest/api/2/project/{project_id}/versions")
        versions = response.json()
        logger.info(f"Add versions to cache: {len(versions)} items")
        self.project_cache.add_versions(project_id, versions)

        return versions

    def get_sprints_for_project(self, project_id: str, name_filter: str, activated_date: str, force_reload=False) -> List[Dict[str, str]]:

        if not force_reload:
            sprints = self.project_cache.get_sprints(project_id, name_filter, activated_date)
            if sprints:
                return sprints

        sprint_ids = []
        sprints = []
        boards = self.get_boards_for_project(project_id, name_filter)
        for board in boards:
            board_sprints = self.get_sprints(board_id=int(board["id"]))
            for sprint in board_sprints:
                if "activatedDate" in sprint and sprint["activatedDate"] >= activated_date and sprint["id"] not in sprint_ids:
                    sprint_ids.append(sprint["id"])
                    sprints.append(sprint)

        self.project_cache.add_sprints(project_id, name_filter, activated_date, sprints)

        return sprints

    def get_sprints(self, board_id: int) -> List:
        session = self.create_session()

        def get_next_page(start_at: int, page_size: int) -> (Dict, int):
            page=session.get(f"/rest/agile/1.0/board/{board_id}/sprint", params={"startAt": start_at, "maxResults": page_size }).json()
            return page["values"], page["isLast"]

        return paginate(get_next_page, page_size=50)

    def get_boards_for_project(self, project_id: str, name_filter: str, board_type: str = "scrum") -> List[Dict[str, str]]:
        session = self.create_session()
        filtered_boards = []

        if board_type not in [ "scrum", "kanban"]:
            raise Exception("Invalid argument. Type must be 'scrum' or 'kanbans")

        def get_next_page(start_at: int, page_size: int) -> (Dict, int):
            page=session.get("/rest/agile/1.0/board", params={"projectKeyOrId": project_id, "name": name_filter, "type": board_type, "startAt": start_at, "maxResults": page_size }).json()
            return page["values"], page["total"]

        boards = paginate(get_next_page, page_size=50)
        for board in boards:
            if name_filter in board["name"]:
                filtered_boards.append(board)

        return sorted(filtered_boards, key=lambda board: board["id"], reverse=False)
