from python_utils.jira.base.jira_errors import JiraClientRequestException
import csv
from typing import Dict, List
from python_utils.timestamp import now

from python_utils.jira.base.user_context import JiraUserContext
from python_utils.jira.base.jira_server import JiraConnection
from python_utils.jira.caches.filter_cache import FilterCache

class JiraFilter:

    def __init__(self, jira_server: JiraConnection, cache_directory: str, user_context: JiraUserContext):
        self.jira_server = jira_server
        self.user_context = user_context
        self.filter_cache = FilterCache(filename=f"{cache_directory}/filter_cache.json")

    def get_filter(self, filter_id: str, only_current_fields=True) -> Dict[str, str]:

        filter_result = None
        if self.user_context.get_use_cache():
            filter_result = self.filter_cache.get_filter(filter_id)
            if filter_result:
                return filter_result

        fields = "current" if only_current_fields else "all"

        # URL für den CSV-Download
        url = f"{self.jira_server.get_hostname()}/sr/jira.issueviews:searchrequest-csv-{fields}-fields/{filter_id}/SearchRequest-{filter_id}.csv"

        session = self.user_context.create_session()
        response = session.get(url, allow_redirects=False)

        if response.status_code == 302 and "Location" in response.headers and response.headers["Location"].startswith("/jira/login.jsp"):
            raise JiraClientRequestException(status_code=403, message=f"Access denied for url {url}")

        if response.status_code != 200:
            raise JiraClientRequestException(status_code=response.status_code, message=response.text)

        csv_content = response.text
        json = csv_to_json(csv_content)

        self.filter_cache.add_filter(filter_id, json)

        return {"issues": json, "timestamp": now()}


def csv_to_json(csv_content: str) -> List:
    # Initialize a result list for storing the dictionaries
    result = []
    # Use the csv.reader to handle quoted fields and commas within fields
    reader = csv.reader(csv_content.strip().split('\n'))
    # Extract headers from the first row
    headers = next(reader)

    # Iterate through each subsequent row
    for row in reader:
        obj = {}
        # Iterate through each column and create objects
        for header, value in zip(headers, row):
            key = header.strip()
            value = value.strip()
            if value:
                # If the key already exists, append the value to a list
                if key in obj:
                    if isinstance(obj[key], list):
                        obj[key].append(value)
                    else:
                        obj[key] = [obj[key], value]
                # Otherwise, add the normal key-value pair
                else:
                    obj[key] = value
        # Append the dictionary to the result list
        result.append(obj)

    return result
