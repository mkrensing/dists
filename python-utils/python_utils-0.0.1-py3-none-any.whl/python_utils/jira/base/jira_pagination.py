from typing import Callable, Dict, List, Tuple

def paginate(callback: Callable[[int, int], Tuple[Dict, int | bool]], page_size=200) -> List:

    results = []
    start_at = 0
    while True:
        (page_result, total_records_or_last) = callback(start_at, page_size)

        start_at += page_size
        results.extend(page_result)

        if is_last_page(start_at, total_records_or_last):
            break

    return results


def is_last_page(start_at : int, total_records_or_last: int|bool) -> bool:
    if isinstance(total_records_or_last, bool):
        return total_records_or_last

    return start_at >= total_records_or_last