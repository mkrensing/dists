import requests
from requests import Session, Response
from typing import Dict, Callable
import time
import base64

from python_utils.jira.base.jira_server import JiraConnection

class SessionProxy:

    def __init__(self, jira_server: JiraConnection, token: str):
        self.jira_server = jira_server
        self.access_tokens = token.split(" ")
        self.current_token_index = 0

    @staticmethod
    def get_next_auth_header_value(access_token: str) -> str:
        if ":::" in access_token:
            username_password = access_token.split(":::")
            return f"Basic {base64.b64encode(f'{username_password[0]}:{username_password[1]}'.encode()).decode()}"
        else:
            return f"Bearer {access_token}"

    def get_next_headers(self):
        headers = {
            "Authorization": self.get_next_auth_header_value(self.access_tokens[self.current_token_index]),
            "Accept": "application/json",
            "Content-Type": "application/json",
            "X-Atlassian-Token": "no-email"
        }
        self.current_token_index = (self.current_token_index + 1) % len(self.access_tokens)
        return headers

    def get_wait_time(self) -> float:
        return round(1 + self.current_token_index / (len(self.access_tokens) / 2), 2)


    def put(self, url: str, data: Dict, params: Dict=None, ignore_error_satus_codes=False) -> Response:
        return self.__make_request(method="PUT",
                                   url=url,
                                   params=params,
                                   data=data,
                                   ignore_error_satus_codes=ignore_error_satus_codes)

    def post(self, url: str, data: Dict, params: Dict=None, ignore_error_satus_codes=False) -> Response:
        return self.__make_request(method="POST",
                                   url=url,
                                   params=params,
                                   data=data,
                                   ignore_error_satus_codes=ignore_error_satus_codes)

    def get(self, url: str, params: Dict=None, ignore_error_satus_codes=False) -> Response:
        return self.__make_request(method="GET",
                                   url=url,
                                   params=params,
                                   ignore_error_satus_codes=ignore_error_satus_codes)

    def delete(self, url: str, params: Dict=None, ignore_error_satus_codes=False) -> Response:
        return self.__make_request(method="DELETE",
                                   url=url,
                                   params=params,
                                   ignore_error_satus_codes=ignore_error_satus_codes)

    def __make_request(self, method, url, params=None, data=None, max_retries=10, ignore_error_satus_codes=False) -> Response:
        """
        Sends an HTTP request with retry logic for specific error scenarios.

        Args:
            method (str): HTTP method (e.g., 'GET', 'POST').
            url (str): The target URL for the request.
            params (dict, optional): URL parameters.
            data (dict, optional): JSON payload for the request.
            max_retries (int, optional): Maximum number of retry attempts.

        Returns:
            Response: The HTTP response object.

        Raises:
            Exception: If the request fails after max retries.
        """
        retry_count = 0

        # Ensure the URL is complete
        if not url.startswith("http"):
            url = f"{self.jira_server.get_hostname()}{url}"

        while retry_count < max_retries:
            headers = self.get_next_headers()
            try:

                response = requests.request(
                    method,
                    url,
                    headers=headers,
                    params=params,
                    json=data,
                    allow_redirects=False,
                    verify=self.jira_server.get_verify_ssl()
                )
                #print(f"[{method}] {url} with params {params} and headers {headers} =>[{response.status_code}] {response.text}")

            except requests.exceptions.RequestException as exception:
                print(f"Handle Exception: {exception}")
                self._handle_retry(retry_count, max_retries, exception)
                retry_count += 1
                continue

            # Handle specific status codes
            if response.status_code in [429, 401]:
                self._handle_retry(retry_count, max_retries, response.status_code)
                retry_count += 1
                continue

            # Raise exception for HTTP errors
            if not ignore_error_satus_codes:
                response.raise_for_status()

            return response



        raise Exception(f"Exceeded maximum retries ({max_retries}) for URL: {url}. Unable to complete the request.")

    def _handle_retry(self, retry_count, max_retries, error):
        """
        Handles retry logic and logs warnings.

        Args:
            retry_count (int): Current retry attempt count.
            max_retries (int): Maximum allowed retries.
            error (int or Exception): The error that triggered the retry.
        """
        wait_time = self.get_wait_time()
        if isinstance(error, int):
            # HTTP status code
            print(f"[{error}] Warning: Too many requests or unauthorized. Retrying in {wait_time} seconds... ({retry_count + 1}/{max_retries})")
        else:
            # General exception
            print(f"[{error}] Warning: Connection error. Retrying in {wait_time} seconds... ({retry_count + 1}/{max_retries})")
        time.sleep(wait_time)


class JiraUserContext:

    def __init__(self, token_or_provider: str | Callable[[], str], test_mode: bool, use_cache: bool, cache_suffix=""):
        self.token_or_provider = token_or_provider
        self.test_mode = test_mode
        self.use_cache = use_cache
        self.cache_suffix = cache_suffix

    def get_token(self) -> str:
        if callable(self.token_or_provider):
            return self.token_or_provider()

        return self.token_or_provider

    def get_test_mode(self) -> bool:
        return self.test_mode

    def set_test_mode(self, test_mode):
        self.test_mode = test_mode

    def set_use_cache(self, use_cache: bool):
        self.use_cache = use_cache

    def get_use_cache(self) -> bool:
        return self.use_cache

    def get_cache_suffix(self) -> str:
        return self.cache_suffix

    def set_cache_suffix(self, cache_suffix):
        self.cache_suffix = cache_suffix

    def create_session(self, jira_server: JiraConnection) -> SessionProxy:
        return SessionProxy(jira_server, self.get_token())
