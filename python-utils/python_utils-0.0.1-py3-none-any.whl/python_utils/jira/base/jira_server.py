class JiraConnection:

    def __init__(self, hostname: str, verify_ssl:bool):
        self.hostname = hostname
        self.verify_ssl = verify_ssl

    def get_hostname(self) -> str:
        return self.hostname

    def get_verify_ssl(self) -> bool:
        return self.verify_ssl
