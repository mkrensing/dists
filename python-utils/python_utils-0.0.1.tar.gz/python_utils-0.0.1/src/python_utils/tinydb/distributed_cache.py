from typing import Dict
import os
import hashlib
from python_utils.tinydb.generic_cache import GenericCache

class DistributedCache:

    def __init__(self, cache_directory: str, cache_name: str):
        self.cache_directory = cache_directory
        self.cache_name = cache_name
        self.target_directory = f"{self.cache_directory}/{self.cache_name}"
        os.makedirs(self.target_directory, exist_ok=True)
        self.cache_manager: Dict[str, GenericCache] = {}

    def get_object(self, key: Dict[str, Dict[str, str]]) -> None | Dict[str, str]:
        return self.lookup_cache(key).get_object(key)

    def set_object(self, key: Dict[str, Dict[str, str]], data: Dict[str, str]):
        return self.lookup_cache(key).set_object(key, data)

    def remove_object(self, key: Dict[str, Dict[str, str]]):
        return self.lookup_cache(key).remove_object(key)

    def lookup_cache(self, key: Dict[str, Dict[str, str]]) -> GenericCache:
        filename = self.get_filename(key)
        if filename not in self.cache_manager:
            self.cache_manager[filename] = GenericCache(filename=filename)

        return self.cache_manager[filename]

    def get_filename(self, key: Dict[str, Dict[str, str]]):
        return f"{self.target_directory}/{self.create_md5_hash(key)}.json"

    def clear(self):
        for cache in self.cache_manager.values():
            cache.clear()

    def close(self):
        for cache in self.cache_manager.values():
            cache.close()

    @staticmethod
    def create_md5_hash(key: Dict[str, Dict[str, str]]) -> str:
        # Erstelle ein md5-Objekt
        md5_hash = hashlib.md5()

        primary_key = [{"id": key_id, "value": value["value"] if "value" in value else value} for key_id, value in key.items() if
                       not isinstance(value, dict) or not value.get("optional", False)]
        primary_key = sorted(primary_key, key=lambda key: key["id"])
        primary_key_values = [key["value"] for key in primary_key]

        # Wandle den String in Bytes um und aktualisiere den Hash
        md5_hash.update(str(primary_key_values).encode('utf-8'))

        # Gib den Hex-String des Hashes zurück
        return md5_hash.hexdigest()
