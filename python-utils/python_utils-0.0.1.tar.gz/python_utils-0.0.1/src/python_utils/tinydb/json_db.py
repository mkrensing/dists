from pathlib import Path
from typing import List, Dict

from filelock import FileLock
from tinydb import TinyDB, Query
from tinydb.middlewares import CachingMiddleware
from tinydb.storages import JSONStorage
import os

class JsonFile:

    def __init__(self, filename: str):
        self.filename = filename
        Path(self.filename).touch()
        self.lock = FileLock(f"{self.filename}.lock")
        self.db = TinyDB(self.filename, storage=CachingMiddleware(JSONStorage))

    def get_data(self, record_id: str) -> List[Dict] | Dict:
        cached_queries = Query()
        result = self.db.search(cached_queries.id == record_id)
        if not result:
            return []
        if len(result) != 1:
            raise Exception(f"Found two matches for id: {id}")
        return result[0]["data"]

    def get_all(self) -> List[Dict] | List[List[Dict]]:
        return [ record["data"] for record in self.db.all() ]

    def set_data(self, record_id: str, data: List[Dict] | Dict) -> List[Dict] | Dict:
        cached_queries = Query()
        with self.lock:
            self.db.upsert({"id": record_id, "data": data }, cached_queries.id == record_id)
            self.db.storage.flush()
        return data

    def merge_data(self, record_id: str, data: Dict) -> Dict:
        cached_queries = Query()
        merged_data = deep_merge(self.get_data(record_id) or {}, data)
        with self.lock:
            self.db.upsert({"id": record_id, "data": merged_data }, cached_queries.id == record_id)
            self.db.storage.flush()
        return merged_data

    def append_data(self, record_id: str, data: List[Dict]) -> List[Dict]:
        cached_queries = Query()
        merged_data = self.get_data(record_id) + data
        with self.lock:
            self.db.upsert({"id": record_id, "data": merged_data }, cached_queries.id == record_id)
            self.db.storage.flush()

        return merged_data

    def delete_data(self, record_id: str):
        cached_queries = Query()
        with self.lock:
            self.db.upsert({"id": record_id, "data": [] }, cached_queries.id == record_id)
            self.db.storage.flush()

    def close(self):
        if self.db:
            with self.lock:
                self.db.close()


class JsonDB:

    def __init__(self, directory: str):
        self.directory = directory
        os.makedirs(self.directory, exist_ok=True)
        self.files = {}

    def get_filename(self, context: str) -> str:
        return os.path.join(f"{self.directory}", f"{context}_db.json")

    def get_json_file(self, context: str) -> JsonFile:
        if context not in self.files:
            self.files[context] = JsonFile(self.get_filename(context))
        return self.files[context]

    def get_data(self, context: str, record_id: str) -> Dict:
        return self.get_json_file(context).get_data(record_id)

    def set_data(self, context: str, record_id: str, data: List[Dict]) -> Dict:
        return self.get_json_file(context).set_data(record_id, data)

    def append_data(self, context: str, record_id: str, data: List[Dict]) -> List[Dict]:
        return self.get_json_file(context).append_data(record_id, data)

    def merge_data(self, context: str, record_id: str, data: Dict) -> Dict:
        return self.get_json_file(context).merge_data(record_id, data)

    def get_all(self, context: str) -> List[Dict] | List[List[Dict]]:
        return self.get_json_file(context).get_all()

    def delete_data(self, context: str, record_id: str):
        self.get_json_file(context).delete_data(record_id)


def deep_merge(dict1, dict2):
    merged = dict1.copy()  # Start with a copy of the first dict
    for key, value in dict2.items():
        if key in merged:
            if isinstance(merged[key], dict) and isinstance(value, dict):
                merged[key] = deep_merge(merged[key], value)
            elif isinstance(merged[key], list) and isinstance(value, list):
                merged[key] = merged[key] + value  # Lists werden kombiniert
            else:
                merged[key] = value  # Überschreibt den Wert
        else:
            merged[key] = value
    return merged
