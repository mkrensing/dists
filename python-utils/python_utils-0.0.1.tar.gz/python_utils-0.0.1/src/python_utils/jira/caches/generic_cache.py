from pathlib import Path
from typing import List, Dict
from tinydb import TinyDB, Query
from tinydb.middlewares import CachingMiddleware
from tinydb.storages import JSONStorage
from filelock import FileLock
from typing import List

class GenericCache:

    def __init__(self, filename: str):
        self.filename = filename
        Path(self.filename).touch()
        self.lock = FileLock(f"{self.filename}.lock")
        self.db = TinyDB(self.filename, storage=CachingMiddleware(JSONStorage))

    def get_object(self, key: Dict[str, Dict[str, str]]) -> None | List[Dict[str, str]]:
        result = self.db.search(self.build_query(key))
        if not result:
            return None

        return result

    def set_object(self, key: Dict[str, Dict[str, str]], data: Dict[str, str]):
        with self.lock:
            self.db.upsert({**data, **self.get_keys_and_values(key)}, self.build_query(key))
            self.db.storage.flush()

    def remove_object(self, key: Dict[str, str]):
        with self.lock:
            for document_id in self.db.remove(self.build_query(key)):
                print(f"Removed: {document_id}")
            self.db.storage.flush()

    def clear(self):
        with self.lock:
            self.db.truncate()

    def close(self):
        if self.db:
            self.db.close()

    @staticmethod
    def get_keys_and_values(key: Dict[str, Dict[str, str]]) -> Dict[str, str]:
        keys_and_values = {}
        for key_id in key:
            keys_and_values[key_id]= key[key_id]["value"] if "value" in key[key_id] else key[key_id]

        return keys_and_values

    @staticmethod
    def build_query(key: Dict[str, Dict[str, str]]):
        cached_queries = Query()
        query = None

        # Iteriere durch die Felder im Dictionary
        for field, condition in key.items():
            comparator = condition.get("comparator", "==") if isinstance(condition, dict) else "=="
            value = condition.get("value", condition) if isinstance(condition, dict) else condition

            # Erstelle dynamisch die Query
            if comparator == "==":
                new_condition = (getattr(cached_queries, field) == value)
            elif comparator == ">=":
                new_condition = (getattr(cached_queries, field) >= value)
            elif comparator == "<=":
                new_condition = (getattr(cached_queries, field) <= value)
            elif comparator == ">":
                new_condition = (getattr(cached_queries, field) > value)
            elif comparator == "<":
                new_condition = (getattr(cached_queries, field) < value)
            else:
                raise ValueError(f"Unsupported comparator: {comparator}")

            # Kombiniere die Bedingungen, falls mehrere vorhanden sind
            if query is None:
                query = new_condition
            else:
                query &= new_condition

        return query
