from pathlib import Path
from typing import Dict
from tinydb import TinyDB, Query
from tinydb.middlewares import CachingMiddleware
from tinydb.storages import JSONStorage
from filelock import FileLock
from typing import List


class RoadmapCache:

    def __init__(self, filename: str):
        self.filename = filename
        Path(self.filename).touch()
        self.lock = FileLock(f"{self.filename}.lock")
        self.db = TinyDB(self.filename, storage=CachingMiddleware(JSONStorage))

    @staticmethod
    def create_roadmap_id(project_id: str, plan_id: int, scenario_id: int) -> str:
        return f"{project_id}_{plan_id}_{scenario_id}"

    def get_roadmap(self, project_id: str, plan_id: int, scenario_id: int) -> Dict[str, str]:
        cached_queries = Query()
        with self.lock:
            result = self.db.search((cached_queries.id == self.create_roadmap_id(project_id, plan_id, scenario_id)) & (
                    cached_queries.timestamp == self.current_timestamp()))
            
        if not result:
            return None

        return {"issues": result[0]["roadmap"], "timestamp": result[0]["timestamp"]}

    def add_roadmap(self, project_id: str, plan_id: int, scenario_id: int, roadmap: List[Dict[str, str]]):
        cached_queries = Query()
        roadmap_id = self.create_roadmap_id(project_id, plan_id, scenario_id)
        with self.lock:
            self.db.upsert({"id": roadmap_id, "timestamp": self.current_timestamp(), "roadmap": roadmap}, (cached_queries.id == roadmap_id))
            self.db.storage.flush()

    @staticmethod
    def current_timestamp() -> str:
        from time import strftime
        return strftime("%Y-%m-%d")

    def clear(self):
        with self.lock:
            self.db.truncate()

    def close(self):
        if self.db:
            self.db.close()