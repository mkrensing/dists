from pathlib import Path
from typing import Dict
from tinydb import TinyDB, Query
from tinydb.middlewares import CachingMiddleware
from tinydb.storages import JSONStorage
from filelock import FileLock
from typing import List

from python_utils.jira.caches.base import AbstractCache


def current_timestamp() -> str:
    from time import strftime
    return strftime("%Y-%m-%d")

class RoadmapCache(AbstractCache):

    def __init__(self, filename: str):
        self.filename = filename
        Path(self.filename).touch()
        self.lock = FileLock(f"{self.filename}.lock")
        self.db = TinyDB(self.filename, storage=CachingMiddleware(JSONStorage))

    @staticmethod
    def create_roadmap_id(project_id: str, plan_id: int, scenario_id: int) -> str:
        return f"{project_id}_{plan_id}_{scenario_id}"

    def get_roadmap(self, project_id: str, plan_id: int, scenario_id: int) -> Dict[str, str]:
        cached_queries = Query()
        with self.lock:
            result = self.db.search((cached_queries.id == self.create_roadmap_id(project_id, plan_id, scenario_id)) & (
                    cached_queries.timestamp == current_timestamp()))

        if not result:
            return None

        return {"issues": result[0]["roadmap"], "timestamp": result[0]["timestamp"]}

    def get_item(self, key: str):
        cached_queries = Query()
        with self.lock:
            result = self.db.search((cached_queries.id == key) & (
                    cached_queries.timestamp == current_timestamp()))

        if not result:
            return None

        return result[0]["roadmap"]

    def add_roadmap(self, project_id: str, plan_id: int, scenario_id: int, roadmap: List[Dict[str, str]]):
        roadmap_id = self.create_roadmap_id(project_id, plan_id, scenario_id)
        self.add_item(key=roadmap_id, roadmap=roadmap)

    def add_item(self, key, roadmap):
        cached_queries = Query()
        with self.lock:
            self.db.upsert({"id": key, "timestamp": self.current_timestamp(), "roadmap": roadmap}, (cached_queries.id == key))
            self.db.storage.flush()

    def clear(self):
        with self.lock:
            self.db.truncate()

    def close(self):
        if self.db:
            self.db.close()