from pathlib import Path
from typing import Dict
from tinydb import TinyDB, Query, where
from tinydb.middlewares import CachingMiddleware
from tinydb.storages import JSONStorage
from filelock import FileLock
from typing import List
from python_utils.timestamp import get_timebased_hash

class UserCache:

    def __init__(self, filename: str):
        self.filename = filename
        Path(self.filename).touch()
        self.lock = FileLock(f"{self.filename}.lock")
        self.db = TinyDB(self.filename, storage=CachingMiddleware(JSONStorage))
        self.refresh_interval_in_minutes = 120

    @staticmethod
    def create_sprint_record_id(project_id: str, name_filter: str, activated_date: str) -> str:
        return f"{project_id}_{name_filter}_{activated_date}"

    def get_user(self, account_id: str) -> List[Dict[str, str]]:
        cached_queries = Query()
        with self.lock:
            result = self.db.search((cached_queries.type == "user") & (cached_queries.id == account_id) & (
                    cached_queries.hash == get_timebased_hash(self.refresh_interval_in_minutes)))
        if not result:
            return []

        return result[0]["user"]

    def add_user(self, account_id: str, user: Dict[str, str]):
        cached_queries = Query()
        with self.lock:
            self.db.upsert({"type": "user", "id": account_id, "hash": get_timebased_hash(self.refresh_interval_in_minutes), "user": user },
                           (cached_queries.type == "user") & (cached_queries.id == account_id))
            self.db.storage.flush()


    def clear(self):
        with self.lock:
            self.db.truncate()

    def close(self):
        if self.db:
            self.db.close()