from jira import JIRA
from python_utils.jira.base.jira_server import JiraConnection
from python_utils.jira.base.user_context import JiraUserContext

def create_jira(jira_server: JiraConnection, user_context: JiraUserContext) -> JIRA:
    access_token = user_context.get_token()

    if ":::" in access_token:
        username_password = access_token.split(":::")
        return JIRA(jira_server.get_hostname(), basic_auth=(username_password[0], username_password[1]),
                    options={"verify": jira_server.get_verify_ssl()})
    else:
        return JIRA(jira_server.get_hostname(), token_auth=access_token, options={"verify": jira_server.get_verify_ssl()})

