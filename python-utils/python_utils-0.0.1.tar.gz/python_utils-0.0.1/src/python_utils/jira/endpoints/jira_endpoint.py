import os
import traceback
from flask import Blueprint, request
from python_utils.jira.jira_api import JiraApi, JiraUserContext, JiraConnection
from python_utils.flask.endpoint import response_json, destroy_endpoint, init_endpoint, response_cookie
from python_utils.env import inject_environment
from python_utils.file import lookup_file, file_exists
from python_utils.jira.jira_security import token_required, get_access_token
from python_utils.jira.jira_security import read_tokens, write_tokens, register_token, logout, is_logged_in
from typing import Dict, List


jira_endpoint = Blueprint('jira_endpoint', __name__, url_prefix='/rest/jira')

class JiraSearchConfig:

    def __init__(self, jira_config: Dict):
        self.jira_config = jira_config

    def is_valid(self) -> bool:
        return "jql" in self.jira_config and \
            "useCache" in self.jira_config and \
            "pageSize" in self.jira_config

    def get_jql(self):
        return self.jira_config["jql"]

    def is_use_cache(self) -> bool:
        return bool(self.jira_config["useCache"])

    def get_page_size(self) -> int:
        return self.jira_config["pageSize"]


class JiraFastSearchConfig:

    def __init__(self, jira_config: Dict):
        self.jira_config = jira_config

    def is_valid(self) -> bool:
        return "jql" in self.jira_config and \
            "fields" in self.jira_config

    def get_jql(self):
        return self.jira_config["jql"]

    def get_fields(self) -> List[str]:
        return self.jira_config["fields"]

    def get_use_cache(self) -> bool:
        return bool(self.jira_config["useCache"]) if "useCache" in self.jira_config else False



@inject_environment(
    { "CACHE_DIRECTORY": "" },
    required=True)
def create_jira_api(cache_directory: str) -> JiraApi:
    return JiraApi(cache_directory=cache_directory)

@inject_environment(
    { "TEST_MODE": "False"},
    required=True)
def create_user_context(test_mode: str) -> JiraUserContext:
    return JiraUserContext(token_or_provider=lambda : get_access_token(),
                           use_cache=False,
                           test_mode=test_mode.lower() in ["true", "1"])

@inject_environment(
    {"JIRA_HOSTNAME": "" },
    required=True)
def create_jira_server(jira_hostname: str) -> JiraConnection:
    return JiraConnection(hostname=jira_hostname, verify_ssl=False)


jira_api = create_jira_api()

@jira_endpoint.route('/sprints/<project_id>/<name_filter>/<activated_date>', methods=["GET"])
@token_required()
def get_sprints_for_project(project_id: str, name_filter: str, activated_date: str):

    force_reload = (request.args["force_reload"] == "true") if "force_reload" in request.args else False
    project_api = jira_api.project_with_context(jira_server=create_jira_server(), user_context=create_user_context())
    sprints_for_project = project_api.get_sprints_for_project(project_id, name_filter, activated_date, force_reload=force_reload)

    return response_json(sprints_for_project)


@jira_endpoint.route('/search', methods=["POST"])
@token_required()
def post_search():
    try:
        config = JiraSearchConfig(request.json)
        expand = request.args.get("expand", "")

        print(f"search with config: {config.__dict__}")
        if not config.is_valid():
            return response_json({"error": f"Invalid request body. Expected JiraSearchConfig"}), 400

        jira_search_api = jira_api.search_with_context(jira_server=create_jira_server(), user_context=create_user_context())
        jira_search_api.get_user_context().set_use_cache(config.is_use_cache())
        (issues, timestamp) = jira_search_api.search_all(jql=config.get_jql(), expand=expand, page_size=config.get_page_size())
        return response_json({ "timestamp": timestamp, "issues": issues })

    except Exception as e:
        print(e)
        print(traceback.format_exc())
        return response_json({"error": str(e)}), 400


@jira_endpoint.route('/update/<issue_key>', methods=["POST"])
@token_required()
def update_issue(issue_key: str):
    try:
        changes = request.json
        jira_issue_api = jira_api.issue_with_context(jira_server=create_jira_server(), user_context=create_user_context())

        return response_json(jira_issue_api.update(issue_key, changes=changes))

    except Exception as e:
        print(e)
        print(traceback.format_exc())
        return response_json({"error": str(e)}), 400


@jira_endpoint.route('/update/status/<project_id>/<issue_key>/from/<current_status_name>/to/<target_status_name>', methods=["GET"])
@token_required()
def change_status(project_id:str, issue_key: str, current_status_name: str, target_status_name: str):
    try:
        jira_issue_api = jira_api.issue_with_context(jira_server=create_jira_server(), user_context=create_user_context())

        return response_json(jira_issue_api.change_status(project_id=project_id, issue_key=issue_key, current_status_name=current_status_name, target_status_name=target_status_name, access_token=get_access_token()))

    except Exception as e:
        print(e)
        print(traceback.format_exc())
        return response_json({"error": str(e)}), 400


@jira_endpoint.route('/update/assignee/<issue_key>/<username>', methods=["GET"])
@token_required()
def assign_issue(issue_key: str, username: str):
    try:
        jira_issue_api = jira_api.issue_with_context(jira_server=create_jira_server(), user_context=create_user_context())

        return response_json(jira_issue_api.assign_issue(issue_key=issue_key, username=username, access_token=get_access_token()))

    except Exception as e:
        print(e)
        print(traceback.format_exc())
        return response_json({"error": str(e)}), 400


@jira_endpoint.route('/update/assignee/<issue_key>/', methods=["GET"])
@token_required()
def unassign_issue(issue_key: str):
    try:
        jira_issue_api = jira_api.issue_with_context(jira_server=create_jira_server(), user_context=create_user_context())

        return response_json(jira_issue_api.assign_issue(issue_key=issue_key, username=None, access_token=get_access_token()))

    except Exception as e:
        print(e)
        print(traceback.format_exc())
        return response_json({"error": str(e)}), 400

@jira_endpoint.route('/filter/<filter_id>', methods=["GET"])
@token_required()
def get_filter(filter_id: str):
    try:
        use_cache = request.args.get("useCache", "false").lower() in [ "true", "1"]
        load_all_data = request.args.get("all", "false").lower() == "true"
        jira_filter_api = jira_api.filter_with_context(jira_server=create_jira_server(), user_context=create_user_context())
        jira_filter_api.get_user_context().set_use_cache(use_cache)

        filter_data = jira_filter_api.get_filter(filter_id=filter_id, only_current_fields=not load_all_data)
        return response_json(filter_data)

    except Exception as e:
        print(e)
        print(traceback.format_exc())
        return response_json({"error": str(e)}), 400


@jira_endpoint.route('/fastsearch', methods=["POST"])
@token_required()
def fast_search():

    config = JiraFastSearchConfig(request.json)

    if not config.is_valid():
        return response_json({"error": f"Invalid request body. Expected JiraFastSearchConfig"}), 400

    try:
        jira_fast_search_api = jira_api.fast_search_with_context(jira_server=create_jira_server(), user_context=create_user_context())
        jira_fast_search_api.get_user_context().set_use_cache(config.get_use_cache())

        fast_search_issues = jira_fast_search_api.search_fast(jql=config.get_jql(), fields=config.get_fields())

        return response_json(fast_search_issues)

    except Exception as e:
        print(e)
        print(traceback.format_exc())
        return response_json({"error": str(e)}), 400

@jira_endpoint.route('/rank/<position>/<reference_issue_key>/<issue_keys>', methods=["GET"])
@token_required()
def change_issue_rank(position: str, reference_issue_key: str, issue_keys: str):

    if position not in [ "after", "before" ]:
        return response_json({ "error": f"Unknown position: {position}"}), 400

    jira_issue_api = jira_api.issue_with_context(jira_server=create_jira_server(), user_context=create_user_context())

    issue_keys = [ issue_key.strip() for issue_key in issue_keys.split(",") ]
    rank_response = jira_issue_api.rank_issues(position, reference_issue_key, issue_keys)

    return response_json(rank_response)

@init_endpoint
@inject_environment({"TOKEN_FILENAME": lookup_file("storage/token.json")})
def init_security(filename: str):
    print(f"init_security: {filename}")
    if file_exists(filename):
        read_tokens(filename)
        os.remove(filename)


@destroy_endpoint
@inject_environment({"TOKEN_FILENAME": lookup_file("storage/token.json")})
def shutdown_endpoint(filename: str):
    if filename:
        write_tokens(filename)


@jira_endpoint.route("/login")
def get_login():
    token = request.args.get("token")
    auth_id = register_token(token)

    return response_cookie("auth_id", auth_id, {"message": "Token registered", "auth_id": auth_id })


@jira_endpoint.route("/logout")
def get_logout():
    if not is_logged_in():
        return response_json({"result": "SKIPPED"})

    logout()
    return response_json({"result": "OK"})
