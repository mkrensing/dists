import os
import traceback
from wsgiref.util import request_uri

from flask import Blueprint, request

from python_utils.jira.commands.roadmap import JiraRoadmap
from python_utils.jira.jira_api import JiraApi, JiraUserContext, JiraConnection
from python_utils.flask.endpoint import response_json, destroy_endpoint, init_endpoint, response_cookie
from python_utils.env import inject_environment
from python_utils.file import lookup_file, file_exists
from python_utils.jira.jira_security import token_required, get_access_token
from python_utils.jira.jira_security import read_tokens, write_tokens, register_token, logout, is_logged_in
from typing import Dict


jira_roadmap_endpoint = Blueprint('jira_roadmap_endpoint', __name__, url_prefix='/rest/jira')

@inject_environment(
    { "CACHE_DIRECTORY": "" },
    required=True)
def create_jira_api(cache_directory: str) -> JiraApi:
    return JiraApi(cache_directory=cache_directory)

@inject_environment(
    { "TEST_MODE": "False"},
    required=True)
def create_user_context(test_mode: str) -> JiraUserContext:
    return JiraUserContext(token_or_provider=lambda : get_access_token(),
                           use_cache=False,
                           test_mode=test_mode.lower() in ["true", "1"])

@inject_environment(
    {"JIRA_HOSTNAME": "" },
    required=True)
def create_jira_server(jira_hostname: str) -> JiraConnection:
    return JiraConnection(hostname=jira_hostname, verify_ssl=False)


jira_api = create_jira_api()

@jira_roadmap_endpoint.route('/roadmap/<project_id>/<plan_id>/<scenario_id>', methods=["GET"])
@token_required()
def get_roadmap(project_id: str, plan_id: str, scenario_id: str):

    use_cache = request.args.get("useCache", "false").lower() in ["true", "1"]
    versions_filters = request.args.getlist("fixVersions")
    jira_roadmap_api = jira_api.roadmap_with_context(create_jira_server(), create_user_context())
    jira_roadmap_api.get_user_context().set_use_cache(use_cache)
    roadmap = jira_roadmap_api.get_roadmap(project_id, plan_id=int(plan_id), scenario_id=int(scenario_id), fix_version_filters=versions_filters)

    return response_json(roadmap)


@jira_roadmap_endpoint.route('/roadmap/details/<project_id>/<component_id>/<issue_type>', methods=["GET"])
@token_required()
def get_issue_details(project_id: str, component_id: str, issue_type: str):

    use_cache = request.args.get("useCache", "false").lower() in ["true", "1"]
    versions_filters = request.args.getlist("fixVersions")

    jira_project_api = jira_api.project_with_context(create_jira_server(), create_user_context())
    jira_search_api = jira_api.search_with_context(create_jira_server(), create_user_context())

    jql = f"project= {project_id} AND resolution = unresolved AND component = {component_id} AND issuetype = {issue_type}"
    unreleased_versions = jira_project_api.get_unreleased_versions(project_id)
    version_ids = JiraRoadmap.get_matching_version_ids(unreleased_versions, versions_filters)

    if version_ids:
        jql = f"{jql} AND fixVersion in ({','.join(version_ids)})"

    jira_search_api.get_user_context().set_use_cache(use_cache)
    (issues, timestamp) = jira_search_api.search_all(jql=jql, expand="")

    return response_json({ "issues": issues, "timestamp": timestamp })

@jira_roadmap_endpoint.route('/roadmap/rank/<plan_id>/<scenario_id>/<anchor_issue_id>/<issue_ids>', methods=["GET"])
@token_required()
def change_roadmap_issue_rank(plan_id: str, scenario_id: str, anchor_issue_id: str, issue_ids: str):
    jira_roadmap_api = jira_api.roadmap_with_context(create_jira_server(), create_user_context())

    issue_ids = [ int(issue_id.strip()) for issue_id in issue_ids.split(",") ]
    status = jira_roadmap_api.change_roadmap_issue_rank(int(plan_id), int(scenario_id), int(anchor_issue_id), issue_ids)
    return response_json(status)