import logging
from typing import List, Dict
from python_utils.jira.base.user_context import JiraUserContext
from python_utils.jira.base.jira_server import JiraConnection
from python_utils.jira.base.jira_lib import create_jira, JIRA

from python_utils.jira.caches.project_cache import ProjectCache


logger = logging.getLogger(__name__)

class JiraProject:

    def __init__(self, jira_server: JiraConnection, cache_directory: str, user_context: JiraUserContext):
        self.jira_server = jira_server
        self.user_context = user_context
        self.project_cache = ProjectCache(filename=f"{cache_directory}/project_cache.json")

    def get_unreleased_versions(self, project_id: str) -> List[Dict[str, str]]:
        versions = self.get_versions(project_id)
        unreleased_versions = []
        for version in versions:
            if not version["released"]:
                unreleased_versions.append(version)

        return unreleased_versions

    def get_versions(self, project_id: str) -> List[Dict[str, str]]:

        versions = self.project_cache.get_versions(project_id)
        if versions:
            logger.info(
                f"Return cached versions for {project_id}: {versions}")
            return versions

        jira = create_jira(self.jira_server, self.user_context)
        versions = [version.raw for version in jira.project_versions(project=project_id)]

        logger.info(f"Add versions to cache: {len(versions)} items")
        self.project_cache.add_versions(project_id, versions)

        return versions

    def get_sprints_for_project(self, project_id: str, name_filter: str, activated_date: str, force_reload=False) -> List[Dict[str, str]]:

        if not force_reload:
            sprints = self.project_cache.get_sprints(project_id, name_filter, activated_date)
            if sprints:
                return sprints

        sprint_ids = []
        sprints = []
        jira = create_jira(self.jira_server, self.user_context)
        boards = self.get_boards_for_project(jira, project_id, name_filter)
        for board in boards:
            for sprint in [sprint.raw for sprint in jira.sprints(board_id=int(board["id"]))]:
                if "activatedDate" in sprint and sprint["activatedDate"] >= activated_date and sprint["id"] not in sprint_ids:
                    sprint_ids.append(sprint["id"])
                    sprints.append(sprint)

        self.project_cache.add_sprints(project_id, name_filter, activated_date, sprints)

        return sprints

    @staticmethod
    def get_boards_for_project(jira: JIRA, project_id: str, name_filter: str) -> List[Dict[str, str]]:
        boards = []
        for board in jira.boards(projectKeyOrID=project_id, type="scrum", maxResults=50):
            if name_filter in board.name:
                boards.append(board.raw)

        return sorted(boards, key=lambda board: board["id"], reverse=False)
