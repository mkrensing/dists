from typing import List, Dict
from python_utils.jira.base.user_context import JiraUserContext
from python_utils.jira.base.jira_server import JiraConnection

class JiraFields:

    def __init__(self, jira_server: JiraConnection, user_context: JiraUserContext):
        self.jira_server = jira_server
        self.user_context = user_context

    def get_custom_fields(self) -> List[Dict[str, str]]:
        fields_url = f"{self.jira_server.get_hostname()}/rest/api/2/field"
        session = self.user_context.create_session()
        response = session.get(fields_url)
        response.raise_for_status()

        all_fields = response.json()

        custom_fields = [field for field in all_fields if field.get("custom", False)]
        print(custom_fields)
        for field in custom_fields:
            field_id = field["id"]
            contexts_url = f"{self.jira_server.get_hostname()}/rest/api/2/field/{field_id}/contexts"
            context_response = session.get(contexts_url)
            context_response.raise_for_status()
            field["contexts"] = context_response.json().get("values", [])

        return custom_fields


    def get_field_context(self, field_id: str) -> List[Dict[str, str]]:
        session = self.user_context.create_session()

        contexts_url = f"{self.jira_server.get_hostname()}/rest/api/2/app/field/{field_id}/context/configuration"
        context_response = session.get(contexts_url)
        context_response.raise_for_status()

        return context_response.json().get("values", [])
