import csv
import logging

from pathlib import Path
from typing import List, Dict, Tuple
from python_utils.timestamp import now
from tinydb import TinyDB, Query
from tinydb.middlewares import CachingMiddleware
from tinydb.storages import JSONStorage

from python_utils.tinydb.json_db import JsonFile
from python_utils.jira.base.jira_server import JiraConnection
from python_utils.jira.base.user_context import JiraUserContext, SessionProxy

from filelock import FileLock

import hashlib
from typing import List



logger = logging.getLogger(__name__)


class FilterCache:

    def __init__(self, filename: str):
        self.filename = filename
        Path(self.filename).touch()
        self.lock = FileLock(f"{self.filename}.lock")
        self.db = TinyDB(self.filename, storage=CachingMiddleware(JSONStorage))

    @staticmethod
    def create_roadmap_id(project_id: str, plan_id: int, scenario_id: int) -> str:
        return f"{project_id}_{plan_id}_{scenario_id}"

    def get_filter(self, filter_id: str) -> Dict[str, str]:
        cached_queries = Query()
        result = self.db.search(cached_queries.id == filter_id)
        if not result:
            return None

        return {"issues": result[0]["issues"], "timestamp": result[0]["timestamp"]}

    def add_filter(self, filter_id: str, issues: List[Dict[str, str]]):
        cached_queries = Query()
        with self.lock:
            self.db.upsert({"id": filter_id, "timestamp": self.current_timestamp(), "issues": issues}, (cached_queries.id == filter_id))
            self.db.storage.flush()

    @staticmethod
    def current_timestamp() -> str:
        from time import strftime
        return strftime("%Y-%m-%d")

    def clear(self):
        with self.lock:
            self.db.truncate()

    def close(self):
        if self.db:
            self.db.close()

class FilterConfig:

    def __init__(self, config: dict):
        self.config = config
        self.key_mapping_index = self.create_key_maping_index(config)

    def get_filter_id(self) -> str:
        return self.config["id"]

    @staticmethod
    def create_key_maping_index(config: Dict) -> Dict:
        key_mapping_index={ "Issue key": "key", "Issue id": "id" }
        for column in config["columns"]:
            column_value = column["value"]
            mapping_value = config["mapping"][column_value] if column_value in config["mapping"] else column_value
            mapping_keys = [ column['label'], f"Custom field ({column['label']})" ]
            for mapping_key in mapping_keys:
                key_mapping_index[mapping_key] = mapping_value


        return key_mapping_index

    @staticmethod
    def create_hash(text: str) -> str:
        return hashlib.md5(text.encode()).hexdigest()

    @staticmethod
    def get_filter_config_id(jql: str, fields: List[str], access_token: str) -> str:

        sorted_fields = sorted(fields)
        combined_string = jql + "|" + ",".join(sorted_fields) + "|" + access_token

        return FilterConfig.create_hash(combined_string)

    def convert_key(self, key: str) -> str:
        return self.key_mapping_index[key] if key in self.key_mapping_index else key

    def __dict__(self):
        return self.config

    def __repr__(self):
        return self.__dict__()

    def __str__(self) -> str:
        return str(self.__dict__())

class FilterConfigProvider:

    def __init__(self, filename: str):
        self.config_file = JsonFile(filename)

    def get_filter_config(self, jql: str, fields: List[str], access_token: str) -> None | FilterConfig:
        filter_config_id = FilterConfig.get_filter_config_id(jql, fields, access_token)
        filter_config_raw = self.config_file.get_data(filter_config_id)
        return FilterConfig(filter_config_raw) if filter_config_raw else None

    def set_filter_config(self, jql: str, fields: List[str], access_token: str, filter_config: FilterConfig):
        filter_config_id = FilterConfig.get_filter_config_id(jql, fields, access_token)
        self.config_file.set_data(filter_config_id, filter_config.__dict__())

    def remove_filter_config(self, jql: str, fields: List[str], access_token: str):
        filter_config_id = FilterConfig.get_filter_config_id(jql, fields, access_token)
        self.config_file.delete_data(filter_config_id)


FILTER_NOT_FOUND_ERROR = "FILTER_NOT_FOUND_ERROR"
FILTER_ACCESS_DENIED = "FILTER_ACCESS_DENIED"
FILTER_UNKNOWN_ERROR = "FILTER_UNKNOWN_ERROR"

class JiraFastSearchClientRequestException(Exception):

    def __init__(self, error_id: str, status_code: int, message: str):
        super().__init__(message)
        self.error_id = error_id
        self.status_code = status_code
        self.message = message

    def get_status_code(self) -> int:
        return self.status_code

    def get_error_id(self) -> str:
        return self.error_id

class JiraFastSearchClient:

    def __init__(self, jira_server: JiraConnection, cache_directory: str, user_context: JiraUserContext):
        self.jira_server = jira_server
        self.filter_configuration = FilterConfigProvider(filename=f"{cache_directory}/filter_config.json")
        self.filter_cache = FilterCache(filename=f"{cache_directory}/filter_cache.json")
        self.user_context = user_context

    def create_session(self) -> SessionProxy:
        return self.user_context.create_session(self.jira_server)

    def search_fast(self, jql: str, fields: List[str]) -> List[Dict[str, str]]:
        access_token = self.user_context.get_token()
        filter_config = self.filter_configuration.get_filter_config(jql, fields, access_token)
        if not filter_config:
            filter_config = FilterConfig(self.create_filter(jql, fields, access_token))
            self.filter_configuration.set_filter_config(jql, fields, access_token, filter_config)

        try:
            filter_result = self.get_filter(filter_id=filter_config.get_filter_id(), use_cache=self.user_context.get_use_cache())
            return self.convert_issues(filter_result, filter_config)

        except JiraFastSearchClientRequestException as e:
            if e.get_error_id() == FILTER_NOT_FOUND_ERROR:
                self.filter_configuration.remove_filter_config(jql, fields, access_token)
                return self.search_fast(jql, fields)
            raise e

    @staticmethod
    def convert_issues(issues: List[Dict], filter_config: FilterConfig) -> List[Dict]:

        if not issues:
            return []

        converted_issues = []
        for issue in issues:
            converted_issue = {}
            for key in issue:
                converted_issue[filter_config.convert_key(key)] = issue[key]
            converted_issues.append(unflatten_structure(converted_issue))

        return converted_issues

    @staticmethod
    def lookup_field_mapping(fields: List[str]) -> Tuple[List[str], Dict[str, str]]:

        field_names = []
        alias_mapping = {}

        for field in fields:
            if "|" in field:
                values = field.split("|")
                alias = values[0]
                fieldname = values[1]
                field_names.append(fieldname)
                alias_mapping[fieldname] = alias
            else:
                field_names.append(field)

        return field_names, alias_mapping


    def create_filter(self, jql: str, fields: List[str], access_token: str):

        (fields, alias_mapping) = self.lookup_field_mapping(fields)
        filter_name=f"JIRA API ({FilterConfig.get_filter_config_id(jql, fields, access_token)})"

        filter_data = {
            "name": filter_name,
            "description": f"Filter created by jira_client Python API at {now()} for query {jql} and fields {fields}",
            "jql": jql,
            "favourite": True  # required to search existing filters not stored in the configuration yet
        }

        # URL für den CSV-Download
        url = f"{self.jira_server.get_hostname()}/rest/api/2/filter"

        response = self.user_context.create_session(self.jira_server).post(url, data=filter_data)

        if response.status_code == 400:
            error_response = response.json()
            if "filterName" in error_response["errors"] and "Filter with same name already exists" in error_response["errors"]["filterName"]:
                filter_found = self.find_favourite_filter_by_name(filter_name, access_token)
                self.set_columns(filter_found["id"], fields, access_token)
                columns = self.get_columns(filter_found["id"], access_token)
                return { **filter_found, "fields": fields,  "columns": columns, "mapping": alias_mapping }

        response.raise_for_status()
        jira_filter = response.json()
        self.set_columns(jira_filter["id"], fields, access_token)
        columns = self.get_columns(jira_filter["id"], access_token)

        return { **jira_filter, "fields": fields, "columns": columns, "mapping": alias_mapping }


    def find_favourite_filter_by_name(self, filter_name: str, access_token: str):
        # URL für den CSV-Download
        url = f"{self.jira_server.get_hostname()}/rest/api/2/filter/favourite"

        response = self.create_session().get(url)
        response.raise_for_status()

        favourite_filters = response.json()
        for favourite_filter in favourite_filters:
            if favourite_filter["name"] == filter_name:
                return favourite_filter

        return None

    def set_columns(self, filter_id: str, fields: List[str], access_token: str):

        # URL für den CSV-Download
        url = f"{self.jira_server.get_hostname()}/rest/api/2/filter/{filter_id}/columns"

        response = self.create_session().put(url, data={ "columns": [*fields, "issuekey" ] })
        print(response.text)
        response.raise_for_status()

    def get_columns(self, filter_id: str, access_token: str) -> Dict:

        # URL für den CSV-Download
        url = f"{self.jira_server.get_hostname()}/rest/api/2/filter/{filter_id}/columns"

        response = self.create_session().get(url)
        response.raise_for_status()

        return response.json()

    def get_filter(self, filter_id: str, use_cache=False) -> List[Dict]:

        filter_result = None
        print(f"get_filter: {use_cache}")

        if use_cache:
            filter_result = self.filter_cache.get_filter(filter_id)
            if filter_result:
                return filter_result["issues"]

        # URL für den CSV-Download
        url = f"{self.jira_server.get_hostname()}/sr/jira.issueviews:searchrequest-csv-current-fields/{filter_id}/SearchRequest-{filter_id}.csv"

        response = self.create_session().get(url)

        if response.status_code == 302 and "Location" in response.headers and response.headers["Location"].startswith("/jira/login.jsp"):
            raise JiraFastSearchClientRequestException(error_id=FILTER_NOT_FOUND_ERROR, status_code=403, message=f"Access denied for url {url}")

        if response.status_code != 200:
            raise JiraFastSearchClientRequestException(error_id=FILTER_UNKNOWN_ERROR, status_code=response.status_code, message=response.text)

        csv_content = response.text
        if "Error processing Search Request" in csv_content and "The saved filter you are trying to view no longer exists or you do not have access rights to view it." in csv_content:
            raise JiraFastSearchClientRequestException(error_id=FILTER_NOT_FOUND_ERROR, status_code=400, message="Filter not found")

        json = csv_to_json(csv_content)

        self.filter_cache.add_filter(filter_id, json)

        return json


def csv_to_json(csv_content: str) -> List:
    # Initialize a result list for storing the dictionaries
    result = []
    # Use the csv.reader to handle quoted fields and commas within fields
    reader = csv.reader(csv_content.strip().split('\n'))
    # Extract headers from the first row
    headers = next(reader)

    # Iterate through each subsequent row
    for row in reader:
        obj = {}
        # Iterate through each column and create objects
        for header, value in zip(headers, row):
            key = header.strip()
            value = value.strip()
            if value:
                # If the key already exists, append the value to a list
                if key in obj:
                    if isinstance(obj[key], list):
                        obj[key].append(value)
                    else:
                        obj[key] = [obj[key], value]
                # Otherwise, add the normal key-value pair
                else:
                    obj[key] = value
        # Append the dictionary to the result list
        result.append(obj)

    return result


def lowercase_keys(d):
    return {key.lower(): value for key, value in d.items()}

def unflatten_structure(issue):
    nested_issue = {}

    issue = lowercase_keys(issue)

    for key, value in issue.items():
        # Teile den Schlüssel bei jedem Leerzeichen
        keys = key.split()

        # Rekursive Einfügung der Schlüssel in die verschachtelte Struktur
        current = nested_issue
        for part in keys[:-1]:
            if part not in current:
                current[part] = {}
            elif isinstance(current[part], str):
                # Wenn der Schlüssel bereits ein Wert ist, ersetze den Wert durch ein verschachteltes Dict
                current[part] = {part: current[part]}
            current = current[part]

        # Füge den letzten Teil mit dem zugehörigen Wert hinzu
        if keys[-1] in current and isinstance(current[keys[-1]], dict):
            current[keys[-1]]["value"] = value
        else:
            current[keys[-1]] = value

    return nested_issue