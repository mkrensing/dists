import logging
from typing import List, Dict
from python_utils.timestamp import now

from python_utils.jira.base.user_context import JiraUserContext
from python_utils.jira.base.jira_server import JiraConnection
from python_utils.jira.commands.project import JiraProject
from python_utils.jira.caches.roadmap_cache import RoadmapCache

logger = logging.getLogger(__name__)

class JiraRoadmap:

    def __init__(self, jira_server: JiraConnection, cache_directory: str, user_context: JiraUserContext):
        self.jira_server = jira_server
        self.user_context = user_context
        self.roadmap_cache = RoadmapCache(filename=f"{cache_directory}/roadmap_cache.json")
        self.project_api = JiraProject(jira_server, cache_directory, user_context)

    def get_roadmap(self, project_id: str, plan_id: int, scenario_id: int, fix_version_filters: List[str]) -> (
            List[Dict[str, str]], str):

        roadmap = None
        if self.user_context.get_use_cache():
            roadmap = self.roadmap_cache.get_roadmap(project_id, plan_id, scenario_id)

        if not roadmap:
            roadmap = self.__get_roadmap_from_jira_backend(plan_id, scenario_id)
            self.roadmap_cache.add_roadmap(project_id, plan_id, scenario_id, roadmap["issues"])

        unreleased_versions = self.project_api.get_unreleased_versions(project_id)
        version_ids = self.get_matching_version_ids(unreleased_versions, fix_version_filters)
        roadmap_issues = roadmap["issues"]
        if version_ids:
            roadmap_issues = filter(
                lambda issue: has_fix_versions(issue, version_ids),
                roadmap_issues)

        roadmap_issues = sorted(roadmap_issues, key=lambda issue: issue["values"]["lexoRank"])
        issues = []
        for index, roadmap_issue in enumerate(roadmap_issues):
            issues.append(convert_roadmap_issue_to_issue(project_id, roadmap_issue))

        return {"issues": issues, "timestamp": roadmap["timestamp"]}

    def change_roadmap_issue_rank(self, plan_id: int, scenario_id: int, anchor_issue_id: int, issue_ids: List[int], operation="AFTER"):

        data = {"operations": [{"anchor": f"{anchor_issue_id}", "itemKeys": issue_ids, "operationType": f"{operation}"}], "planId": int(plan_id),
                "scenarioId": int(scenario_id)}
        session = self.user_context.create_session()
        response = session.post(f"{self.jira_server.get_hostname()}/rest/jpo/1.0/issues/rank", json=data,  allow_redirects=False)
        response.raise_for_status()
        return {"status": response.json()}


    def __get_roadmap_from_jira_backend(self, plan_id: int, scenario_id: int) -> Dict[str, str]:

        session = self.user_context.create_session()

        data = {"planId": int(plan_id), "scenarioId": int(scenario_id),
                "filter": {"includeCompleted": False, "performDependencyCompletion": False, "includeIssueLinks": True}}

        response = session.post(f"{self.jira_server.get_hostname()}/rest/jpo/1.0/backlog",json=data,allow_redirects=False)
        response.raise_for_status()

        roadmap = response.json()
        return {"issues": roadmap["issues"], "timestamp": now()}

    @staticmethod
    def get_matching_version_ids(versions: List[Dict[str, str]], version_filters: List[str]) -> List[str]:
        version_ids: List[int] = []
        for version in versions:
            for version_filter in version_filters:
                if version["name"].startswith(version_filter):
                    version_ids.append(str(version["id"]))

        return version_ids


def has_fix_versions(issue: Dict, fix_versions_filters: List[str]) -> bool:
    if not "fixVersions" in issue["values"]:
        return False

    for fix_version_filter in fix_versions_filters:
        if fix_version_filter in issue["values"]["fixVersions"]:
            return True

    return False

def convert_roadmap_issue_to_issue(project_id: str, roadmap_issue: Dict) -> Dict:
    return {"key": f"{project_id}-{roadmap_issue['issueKey']}",
            "id": roadmap_issue["id"],
            "summary": roadmap_issue["values"]["summary"],
            "labels": roadmap_issue["values"]["labels"] if "labels" in roadmap_issue["values"] else [],
            "issuetype": roadmap_issue["values"]["type"],
            "status": roadmap_issue["values"]["status"]
            }
