from typing import Dict
from flask import Blueprint

from python_utils.confluence.confluence_client import ConfluenceClient
from python_utils.flask.endpoint import response_json, response_text
from python_utils.env import inject_environment

@inject_environment({"CONFLUENCE_PAGEID_ALIASES": ""}, required=False)
def get_pageid_aliases(pageid_aliases: str) -> Dict[str, str]:
    aliases = {}
    for alias in pageid_aliases.split(","):
        alias_definition = alias.strip().split("=")
        if len(alias_definition) > 1:
            aliases[alias_definition[0]] = alias_definition[1]

    return aliases


@inject_environment({"CONFLUENCE_HOSTNAME": "", "CONFLUENCE_ACCESS_TOKEN": "", "CONFLUENCE_TEST_MODE": ""}, required=True)
def create_confluence_client(hostname: str, access_token: str, test_mode: str) -> ConfluenceClient:
    return ConfluenceClient(hostname=hostname, access_token=access_token, pageid_aliases=get_pageid_aliases(), test_mode=test_mode.lower() in ["true", "1"])


confluence_endpoint = Blueprint('confluence_endpoint', __name__, url_prefix='/rest/confluence')
confluence_client = create_confluence_client()


@confluence_endpoint.route('/config/<page_id>/<config_id>')
def get_board_config(page_id: str, config_id: str):
    try:
        config = confluence_client.get_config(page_id, config_id)

        return response_json(config)
    except Exception as e:
        return response_json({"error": str(e)}), 400


@confluence_endpoint.route('/file/<page_id>/<filename>')
def get_file(page_id: str, filename: str):
    try:
        config = confluence_client.get_file(page_id, filename)
        return response_json(config)
    except Exception as e:
        return response_json({"error": str(e)}), 400
