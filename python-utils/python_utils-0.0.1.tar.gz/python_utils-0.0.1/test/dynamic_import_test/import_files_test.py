from python_utils.dynamic_import import import_modules

modules = import_modules("**/endpoint/**/*")
