print(f"Endpoint loaded {__name__}")
