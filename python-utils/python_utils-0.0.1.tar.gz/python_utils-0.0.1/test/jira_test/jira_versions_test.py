from python_utils.jira.jira_api import JiraApi, JiraConnection

TEST_JIRA_ACCESS_TOKEN="info@krensing.com:::ATATT3xFfGF0AU5ka8z4GiF7EXR4aEcTzvygHPQUXVzp0kjrrV9l-ycGLRTsbNCxaYGHdWg1eBaqqDnhtUNMcZunPF_C0prNw7VIKzLnzTXnL8jamjL4Z_WZIHX3xO2j8Tj7u__UJugq0VeN1ose7CWz9n6DZgsM3Jt4v7M0AHOgqx1a-zrX8IU=509964F3"

jira_api = JiraApi(cache_directory="cache")
jira_server = JiraConnection("https://krensing.atlassian.net", verify_ssl=True)
versions_api = jira_api.versions(jira_server, TEST_JIRA_ACCESS_TOKEN)

versions = versions_api.get_versions("JT")
print(versions)