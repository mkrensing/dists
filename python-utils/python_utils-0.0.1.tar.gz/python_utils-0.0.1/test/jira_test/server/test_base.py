from python_utils.jira.commands.project import JiraProject
from python_utils.jira.jira_api import JiraApi, JiraConnection
from python_utils.env_loader import load_from_file
from python_utils.env import inject_environment

load_from_file("test/jira_test/server/local_env.yaml", ignore_not_found=False)

@inject_environment({ "JIRA_ACCESS_TOKEN" : "" }, required=True)
def get_jira_access_token(access_token: str) -> str:
    return access_token

@inject_environment({ "JIRA_SERVER_URL" : "" }, required=True)
def get_jira_server_url(jira_server_url: str) -> str:
    return jira_server_url

def create_jira_project_api() -> JiraProject:
    jira_api = JiraApi(cache_directory="../.cache")
    jira_server = JiraConnection(hostname=get_jira_server_url(), verify_ssl=True)
    return jira_api.project(jira_server, get_jira_access_token())