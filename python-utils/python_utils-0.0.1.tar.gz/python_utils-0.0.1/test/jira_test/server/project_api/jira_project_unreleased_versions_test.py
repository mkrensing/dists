from jira_test.server.test_base import create_jira_project_api

project_api = create_jira_project_api()

unreleased_versions = project_api.get_unreleased_versions("OCP")
print("UNRELEASED VERSIONS")
print(unreleased_versions)
print(len(unreleased_versions))

