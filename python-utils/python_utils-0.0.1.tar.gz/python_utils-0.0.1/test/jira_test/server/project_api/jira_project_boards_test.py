from jira_test.server.test_base import create_jira_project_api

project_api = create_jira_project_api()

boards = project_api.get_boards_for_project("DVSS", name_filter="DCS")
print("BOARDS")
print(boards)
print(len(boards))