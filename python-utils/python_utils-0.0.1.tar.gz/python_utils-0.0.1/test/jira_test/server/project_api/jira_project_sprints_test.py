from jira_test.server.test_base import create_jira_project_api

project_api = create_jira_project_api()

sprints = project_api.get_sprints_for_project("DVSS", name_filter="Sprint", activated_date="2024-01-01", force_reload=True)
print("SPRINTS")
print(sprints)
print(len(sprints))