from jira_test.server.test_base import create_jira_project_api

project_api = create_jira_project_api()

versions = project_api.get_versions("OCP")
print("VERIONS")
print(versions)
print(len(versions))

