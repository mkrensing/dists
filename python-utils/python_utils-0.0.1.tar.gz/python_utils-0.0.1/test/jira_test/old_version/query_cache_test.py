from python_utils.jira.jira_client import QueryCache, JiraPageResult

cache = QueryCache("cache")
cache.add_page(jql="project = TEST", page=JiraPageResult(0, 6, "2024-01-01", [{ "id": "TEST-0001" }, { "id": "TEST-0002" }]))
cache.add_page(jql="project = TEST", page=JiraPageResult(3, 6, "2024-01-01", [{ "id": "TEST-0003" }, { "id": "TEST-0004" }]))
cache.add_page(jql="project = TEST", page=JiraPageResult(5, 6, "2024-01-01", [{ "id": "TEST-0005" }, { "id": "TEST-0006" }]))

pages = cache.get_all_pages(jql="project = TEST", start_at=0)
print(f"page: {pages.__dict__()} {pages.get_issues()}")

page = cache.get_page(jql="project = TEST", start_at=3)
print(f"page: {page.__dict__()} {page.get_issues()}")

cache.remove_all_pages("project = TEST")
pages = cache.get_all_pages(jql="project = TEST", start_at=0)
print(f"page: {pages}")

cache.add_page(jql="project = FOO", page=JiraPageResult(0, 6, "2024-01-01", [{ "id": "TEST-0001" }, { "id": "TEST-0002" }]))
